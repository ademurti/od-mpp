<?php
namespace PHPMaker2020\mpp;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$branch_list = new branch_list();

// Run the page
$branch_list->run();

// Setup login status
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$branch_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$branch_list->isExport()) { ?>
<script>
var fbranchlist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fbranchlist = currentForm = new ew.Form("fbranchlist", "list");
	fbranchlist.formKeyCountName = '<?php echo $branch_list->FormKeyCountName ?>';
	loadjs.done("fbranchlist");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$branch_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($branch_list->TotalRecords > 0 && $branch_list->ExportOptions->visible()) { ?>
<?php $branch_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($branch_list->ImportOptions->visible()) { ?>
<?php $branch_list->ImportOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$branch_list->renderOtherOptions();
?>
<?php $branch_list->showPageHeader(); ?>
<?php
$branch_list->showMessage();
?>
<?php if ($branch_list->TotalRecords > 0 || $branch->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($branch_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> branch">
<?php if (!$branch_list->isExport()) { ?>
<div class="card-header ew-grid-upper-panel">
<?php if (!$branch_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $branch_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $branch_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
<form name="fbranchlist" id="fbranchlist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="branch">
<div id="gmp_branch" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($branch_list->TotalRecords > 0 || $branch_list->isGridEdit()) { ?>
<table id="tbl_branchlist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$branch->RowType = ROWTYPE_HEADER;

// Render list options
$branch_list->renderListOptions();

// Render list options (header, left)
$branch_list->ListOptions->render("header", "left");
?>
<?php if ($branch_list->Location->Visible) { // Location ?>
	<?php if ($branch_list->SortUrl($branch_list->Location) == "") { ?>
		<th data-name="Location" class="<?php echo $branch_list->Location->headerCellClass() ?>"><div id="elh_branch_Location" class="branch_Location"><div class="ew-table-header-caption"><?php echo $branch_list->Location->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Location" class="<?php echo $branch_list->Location->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $branch_list->SortUrl($branch_list->Location) ?>', 1);"><div id="elh_branch_Location" class="branch_Location">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $branch_list->Location->caption() ?></span><span class="ew-table-header-sort"><?php if ($branch_list->Location->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($branch_list->Location->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($branch_list->Branch->Visible) { // Branch ?>
	<?php if ($branch_list->SortUrl($branch_list->Branch) == "") { ?>
		<th data-name="Branch" class="<?php echo $branch_list->Branch->headerCellClass() ?>"><div id="elh_branch_Branch" class="branch_Branch"><div class="ew-table-header-caption"><?php echo $branch_list->Branch->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Branch" class="<?php echo $branch_list->Branch->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $branch_list->SortUrl($branch_list->Branch) ?>', 1);"><div id="elh_branch_Branch" class="branch_Branch">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $branch_list->Branch->caption() ?></span><span class="ew-table-header-sort"><?php if ($branch_list->Branch->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($branch_list->Branch->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($branch_list->Region->Visible) { // Region ?>
	<?php if ($branch_list->SortUrl($branch_list->Region) == "") { ?>
		<th data-name="Region" class="<?php echo $branch_list->Region->headerCellClass() ?>"><div id="elh_branch_Region" class="branch_Region"><div class="ew-table-header-caption"><?php echo $branch_list->Region->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Region" class="<?php echo $branch_list->Region->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $branch_list->SortUrl($branch_list->Region) ?>', 1);"><div id="elh_branch_Region" class="branch_Region">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $branch_list->Region->caption() ?></span><span class="ew-table-header-sort"><?php if ($branch_list->Region->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($branch_list->Region->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$branch_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($branch_list->ExportAll && $branch_list->isExport()) {
	$branch_list->StopRecord = $branch_list->TotalRecords;
} else {

	// Set the last record to display
	if ($branch_list->TotalRecords > $branch_list->StartRecord + $branch_list->DisplayRecords - 1)
		$branch_list->StopRecord = $branch_list->StartRecord + $branch_list->DisplayRecords - 1;
	else
		$branch_list->StopRecord = $branch_list->TotalRecords;
}
$branch_list->RecordCount = $branch_list->StartRecord - 1;
if ($branch_list->Recordset && !$branch_list->Recordset->EOF) {
	$branch_list->Recordset->moveFirst();
	$selectLimit = $branch_list->UseSelectLimit;
	if (!$selectLimit && $branch_list->StartRecord > 1)
		$branch_list->Recordset->move($branch_list->StartRecord - 1);
} elseif (!$branch->AllowAddDeleteRow && $branch_list->StopRecord == 0) {
	$branch_list->StopRecord = $branch->GridAddRowCount;
}

// Initialize aggregate
$branch->RowType = ROWTYPE_AGGREGATEINIT;
$branch->resetAttributes();
$branch_list->renderRow();
while ($branch_list->RecordCount < $branch_list->StopRecord) {
	$branch_list->RecordCount++;
	if ($branch_list->RecordCount >= $branch_list->StartRecord) {
		$branch_list->RowCount++;

		// Set up key count
		$branch_list->KeyCount = $branch_list->RowIndex;

		// Init row class and style
		$branch->resetAttributes();
		$branch->CssClass = "";
		if ($branch_list->isGridAdd()) {
		} else {
			$branch_list->loadRowValues($branch_list->Recordset); // Load row values
		}
		$branch->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$branch->RowAttrs->merge(["data-rowindex" => $branch_list->RowCount, "id" => "r" . $branch_list->RowCount . "_branch", "data-rowtype" => $branch->RowType]);

		// Render row
		$branch_list->renderRow();

		// Render list options
		$branch_list->renderListOptions();
?>
	<tr <?php echo $branch->rowAttributes() ?>>
<?php

// Render list options (body, left)
$branch_list->ListOptions->render("body", "left", $branch_list->RowCount);
?>
	<?php if ($branch_list->Location->Visible) { // Location ?>
		<td data-name="Location" <?php echo $branch_list->Location->cellAttributes() ?>>
<span id="el<?php echo $branch_list->RowCount ?>_branch_Location">
<span<?php echo $branch_list->Location->viewAttributes() ?>><?php echo $branch_list->Location->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($branch_list->Branch->Visible) { // Branch ?>
		<td data-name="Branch" <?php echo $branch_list->Branch->cellAttributes() ?>>
<span id="el<?php echo $branch_list->RowCount ?>_branch_Branch">
<span<?php echo $branch_list->Branch->viewAttributes() ?>><?php echo $branch_list->Branch->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($branch_list->Region->Visible) { // Region ?>
		<td data-name="Region" <?php echo $branch_list->Region->cellAttributes() ?>>
<span id="el<?php echo $branch_list->RowCount ?>_branch_Region">
<span<?php echo $branch_list->Region->viewAttributes() ?>><?php echo $branch_list->Region->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$branch_list->ListOptions->render("body", "right", $branch_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$branch_list->isGridAdd())
		$branch_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$branch->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($branch_list->Recordset)
	$branch_list->Recordset->Close();
?>
<?php if (!$branch_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$branch_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $branch_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $branch_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($branch_list->TotalRecords == 0 && !$branch->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $branch_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$branch_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$branch_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$branch_list->terminate();
?>