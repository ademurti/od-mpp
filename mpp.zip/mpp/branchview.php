<?php
namespace PHPMaker2020\mpp;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$branch_view = new branch_view();

// Run the page
$branch_view->run();

// Setup login status
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$branch_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$branch_view->isExport()) { ?>
<script>
var fbranchview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	fbranchview = currentForm = new ew.Form("fbranchview", "view");
	loadjs.done("fbranchview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$branch_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $branch_view->ExportOptions->render("body") ?>
<?php $branch_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $branch_view->showPageHeader(); ?>
<?php
$branch_view->showMessage();
?>
<?php if (!$branch_view->IsModal) { ?>
<?php if (!$branch_view->isExport()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $branch_view->Pager->render() ?>
<div class="clearfix"></div>
</form>
<?php } ?>
<?php } ?>
<form name="fbranchview" id="fbranchview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="branch">
<input type="hidden" name="modal" value="<?php echo (int)$branch_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($branch_view->Location->Visible) { // Location ?>
	<tr id="r_Location">
		<td class="<?php echo $branch_view->TableLeftColumnClass ?>"><span id="elh_branch_Location"><?php echo $branch_view->Location->caption() ?></span></td>
		<td data-name="Location" <?php echo $branch_view->Location->cellAttributes() ?>>
<span id="el_branch_Location">
<span<?php echo $branch_view->Location->viewAttributes() ?>><?php echo $branch_view->Location->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($branch_view->Branch->Visible) { // Branch ?>
	<tr id="r_Branch">
		<td class="<?php echo $branch_view->TableLeftColumnClass ?>"><span id="elh_branch_Branch"><?php echo $branch_view->Branch->caption() ?></span></td>
		<td data-name="Branch" <?php echo $branch_view->Branch->cellAttributes() ?>>
<span id="el_branch_Branch">
<span<?php echo $branch_view->Branch->viewAttributes() ?>><?php echo $branch_view->Branch->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($branch_view->Region->Visible) { // Region ?>
	<tr id="r_Region">
		<td class="<?php echo $branch_view->TableLeftColumnClass ?>"><span id="elh_branch_Region"><?php echo $branch_view->Region->caption() ?></span></td>
		<td data-name="Region" <?php echo $branch_view->Region->cellAttributes() ?>>
<span id="el_branch_Region">
<span<?php echo $branch_view->Region->viewAttributes() ?>><?php echo $branch_view->Region->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
<?php if (!$branch_view->IsModal) { ?>
<?php if (!$branch_view->isExport()) { ?>
<?php echo $branch_view->Pager->render() ?>
<div class="clearfix"></div>
<?php } ?>
<?php } ?>
</form>
<?php
$branch_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$branch_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$branch_view->terminate();
?>