<?php
namespace PHPMaker2020\mpp;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$level_delete = new level_delete();

// Run the page
$level_delete->run();

// Setup login status
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$level_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fleveldelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	fleveldelete = currentForm = new ew.Form("fleveldelete", "delete");
	loadjs.done("fleveldelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $level_delete->showPageHeader(); ?>
<?php
$level_delete->showMessage();
?>
<form name="fleveldelete" id="fleveldelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="level">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($level_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($level_delete->Level->Visible) { // Level ?>
		<th class="<?php echo $level_delete->Level->headerCellClass() ?>"><span id="elh_level_Level" class="level_Level"><?php echo $level_delete->Level->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$level_delete->RecordCount = 0;
$i = 0;
while (!$level_delete->Recordset->EOF) {
	$level_delete->RecordCount++;
	$level_delete->RowCount++;

	// Set row properties
	$level->resetAttributes();
	$level->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$level_delete->loadRowValues($level_delete->Recordset);

	// Render row
	$level_delete->renderRow();
?>
	<tr <?php echo $level->rowAttributes() ?>>
<?php if ($level_delete->Level->Visible) { // Level ?>
		<td <?php echo $level_delete->Level->cellAttributes() ?>>
<span id="el<?php echo $level_delete->RowCount ?>_level_Level" class="level_Level">
<span<?php echo $level_delete->Level->viewAttributes() ?>><?php echo $level_delete->Level->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$level_delete->Recordset->moveNext();
}
$level_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $level_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$level_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$level_delete->terminate();
?>