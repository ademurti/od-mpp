<?php
namespace PHPMaker2020\mpp;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$Branch_MPP_crosstab = new Branch_MPP_crosstab();

// Run the page
$Branch_MPP_crosstab->run();

// Setup login status
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$Branch_MPP_crosstab->Page_Render();
?>
<?php if (!$DashboardReport) { ?>
<?php include_once "header.php"; ?>
<?php } ?>
<?php if (!$Branch_MPP_crosstab->isExport() && !$Branch_MPP_crosstab->DrillDown && !$DashboardReport) { ?>
<script>
var fcrosstab, currentPageID;
loadjs.ready("head", function() {

	// Form object for search
	fcrosstab = currentForm = new ew.Form("fcrosstab", "crosstab");
	currentPageID = ew.PAGE_ID = "crosstab";

	// Validate function for search
	fcrosstab.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fcrosstab.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fcrosstab.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fcrosstab.lists["x_Status[]"] = <?php echo $Branch_MPP_crosstab->Status->Lookup->toClientList($Branch_MPP_crosstab) ?>;
	fcrosstab.lists["x_Status[]"].options = <?php echo JsonEncode($Branch_MPP_crosstab->Status->lookupOptions()) ?>;

	// Filters
	fcrosstab.filterList = <?php echo $Branch_MPP_crosstab->getFilterList() ?>;
	loadjs.done("fcrosstab");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<a id="top"></a>
<?php if ((!$Branch_MPP_crosstab->isExport() || $Branch_MPP_crosstab->isExport("print")) && !$DashboardReport) { ?>
<!-- Content Container -->
<div id="ew-report" class="ew-report container-fluid">
<?php } ?>
<?php if ($Branch_MPP_crosstab->ShowCurrentFilter) { ?>
<?php $Branch_MPP_crosstab->showFilterList() ?>
<?php } ?>
<div class="btn-toolbar ew-toolbar">
<?php
if (!$Branch_MPP_crosstab->DrillDownInPanel) {
	$Branch_MPP_crosstab->ExportOptions->render("body");
	$Branch_MPP_crosstab->SearchOptions->render("body");
	$Branch_MPP_crosstab->FilterOptions->render("body");
}
?>
</div>
<?php $Branch_MPP_crosstab->showPageHeader(); ?>
<?php
$Branch_MPP_crosstab->showMessage();
?>
<?php if ((!$Branch_MPP_crosstab->isExport() || $Branch_MPP_crosstab->isExport("print")) && !$DashboardReport) { ?>
<div class="row">
<?php } ?>
<?php if ((!$Branch_MPP_crosstab->isExport() || $Branch_MPP_crosstab->isExport("print")) && !$DashboardReport) { ?>
<!-- Center Container -->
<div id="ew-center" class="<?php echo $Branch_MPP_crosstab->CenterContentClass ?>">
<?php } ?>
<?php if ($Branch_MPP_crosstab->ShowDrillDownFilter) { ?>
<?php $Branch_MPP_crosstab->showDrillDownList() ?>
<?php } ?>
<!-- Crosstab report (begin) -->
<div id="report_crosstab">
<?php if (!$Branch_MPP_crosstab->isExport() && !$Branch_MPP_crosstab->DrillDown && !$DashboardReport) { ?>
<?php if (!$Branch_MPP_crosstab->isExport() && !$Branch_MPP->CurrentAction) { ?>
<form name="fcrosstab" id="fcrosstab" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fcrosstab-search-panel" class="<?php echo $Branch_MPP_crosstab->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="Branch_MPP">
	<div class="ew-extended-search">
<?php

// Render search row
$Branch_MPP->RowType = ROWTYPE_SEARCH;
$Branch_MPP->resetAttributes();
$Branch_MPP_crosstab->renderRow();
?>
<?php if ($Branch_MPP_crosstab->Status->Visible) { // Status ?>
	<?php
		$Branch_MPP_crosstab->SearchColumnCount++;
		if (($Branch_MPP_crosstab->SearchColumnCount - 1) % $Branch_MPP_crosstab->SearchFieldsPerRow == 0) {
			$Branch_MPP_crosstab->SearchRowCount++;
	?>
<div id="xsr_<?php echo $Branch_MPP_crosstab->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_Status" class="ew-cell form-group">
		<label class="ew-search-caption ew-label"><?php echo $Branch_MPP_crosstab->Status->caption() ?></label>
		<span id="el_Branch_MPP_Status" class="ew-search-field">
<div id="tp_x_Status" class="ew-template"><input type="checkbox" class="custom-control-input" data-table="Branch_MPP" data-field="x_Status" data-value-separator="<?php echo $Branch_MPP_crosstab->Status->displayValueSeparatorAttribute() ?>" name="x_Status[]" id="x_Status[]" value="{value}"<?php echo $Branch_MPP_crosstab->Status->editAttributes() ?>></div>
<div id="dsl_x_Status" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $Branch_MPP_crosstab->Status->checkBoxListHtml(FALSE, "x_Status[]") ?>
</div></div>
<?php echo $Branch_MPP_crosstab->Status->Lookup->getParamTag($Branch_MPP_crosstab, "p_x_Status") ?>
</span>
	</div>
	<?php if ($Branch_MPP_crosstab->SearchColumnCount % $Branch_MPP_crosstab->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
	<?php if ($Branch_MPP_crosstab->SearchColumnCount % $Branch_MPP_crosstab->SearchFieldsPerRow > 0) { ?>
</div>
	<?php } ?>
<div id="xsr_<?php echo $Branch_MPP_crosstab->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php
while ($Branch_MPP_crosstab->GroupCount <= count($Branch_MPP_crosstab->GroupRecords) && $Branch_MPP_crosstab->GroupCount <= $Branch_MPP_crosstab->DisplayGroups) {
?>
<?php

	// Show header
	if ($Branch_MPP_crosstab->ShowHeader) {
?>
<?php if ($Branch_MPP_crosstab->GroupCount > 1) { ?>
</tbody>
</table>
</div>
<!-- /.ew-grid-middle-panel -->
<!-- Report grid (end) -->
<?php if ($Branch_MPP_crosstab->TotalGroups > 0) { ?>
<?php if (!$Branch_MPP_crosstab->isExport() && !($Branch_MPP_crosstab->DrillDown && $Branch_MPP_crosstab->TotalGroups > 0)) { ?>
<!-- Bottom pager -->
<div class="card-footer ew-grid-lower-panel">
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $Branch_MPP_crosstab->Pager->render() ?>
</form>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php } ?>
</div>
<!-- /.ew-grid -->
<?php echo $Branch_MPP_crosstab->PageBreakContent ?>
<?php } ?>
<div class="<?php if (!$Branch_MPP_crosstab->isExport("word") && !$Branch_MPP_crosstab->isExport("excel")) { ?>card ew-card <?php } ?>ew-grid"<?php echo $Branch_MPP_crosstab->ReportTableStyle ?>>
<?php if (!$Branch_MPP_crosstab->isExport() && !($Branch_MPP_crosstab->DrillDown && $Branch_MPP_crosstab->TotalGroups > 0)) { ?>
<!-- Top pager -->
<div class="card-header ew-grid-upper-panel">
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $Branch_MPP_crosstab->Pager->render() ?>
</form>
<div class="clearfix"></div>
</div>
<?php } ?>
<!-- Report grid (begin) -->
<div id="gmp_Branch_MPP" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="<?php echo $Branch_MPP_crosstab->ReportTableClass ?>">
<thead>
	<!-- Table header -->
	<tr class="ew-table-header">
<?php if ($Branch_MPP_crosstab->GroupColumnCount > 0) { ?>
		<td class="ew-rpt-col-summary" colspan="<?php echo $Branch_MPP_crosstab->GroupColumnCount ?>"><div><?php echo $Branch_MPP_crosstab->renderSummaryCaptions() ?></div></td>
<?php } ?>
		<td class="ew-rpt-col-header" colspan="<?php echo @$Branch_MPP_crosstab->ColumnSpan ?>">
			<div class="ew-table-header-btn">
				<span class="ew-table-header-caption"><?php echo $Branch_MPP_crosstab->Status->caption() ?></span>
			</div>
		</td>
	</tr>
	<tr class="ew-table-header">
<?php if ($Branch_MPP_crosstab->Division->Visible) { ?>
	<td data-field="Division">
<?php if ($Branch_MPP_crosstab->sortUrl($Branch_MPP_crosstab->Division) == "") { ?>
		<div class="ew-table-header-btn Branch_MPP_Division">
			<span class="ew-table-header-caption"><?php echo $Branch_MPP_crosstab->Division->caption() ?></span>			
		</div>
<?php } else { ?>
		<div class="ew-table-header-btn ew-pointer Branch_MPP_Division" onclick="ew.sort(event, '<?php echo $Branch_MPP_crosstab->sortUrl($Branch_MPP_crosstab->Division) ?>', 1);">
			<span class="ew-table-header-caption"><?php echo $Branch_MPP_crosstab->Division->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Branch_MPP_crosstab->Division->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Branch_MPP_crosstab->Division->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span>
		</div>
<?php } ?>
	</td>
<?php } ?>
<?php if ($Branch_MPP_crosstab->Branch->Visible) { ?>
	<td data-field="Branch">
<?php if ($Branch_MPP_crosstab->sortUrl($Branch_MPP_crosstab->Branch) == "") { ?>
		<div class="ew-table-header-btn Branch_MPP_Branch">
			<span class="ew-table-header-caption"><?php echo $Branch_MPP_crosstab->Branch->caption() ?></span>			
		</div>
<?php } else { ?>
		<div class="ew-table-header-btn ew-pointer Branch_MPP_Branch" onclick="ew.sort(event, '<?php echo $Branch_MPP_crosstab->sortUrl($Branch_MPP_crosstab->Branch) ?>', 1);">
			<span class="ew-table-header-caption"><?php echo $Branch_MPP_crosstab->Branch->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Branch_MPP_crosstab->Branch->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Branch_MPP_crosstab->Branch->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span>
		</div>
<?php } ?>
	</td>
<?php } ?>
<?php if ($Branch_MPP_crosstab->Location->Visible) { ?>
	<td data-field="Location">
<?php if ($Branch_MPP_crosstab->sortUrl($Branch_MPP_crosstab->Location) == "") { ?>
		<div class="ew-table-header-btn Branch_MPP_Location">
			<span class="ew-table-header-caption"><?php echo $Branch_MPP_crosstab->Location->caption() ?></span>			
		</div>
<?php } else { ?>
		<div class="ew-table-header-btn ew-pointer Branch_MPP_Location" onclick="ew.sort(event, '<?php echo $Branch_MPP_crosstab->sortUrl($Branch_MPP_crosstab->Location) ?>', 1);">
			<span class="ew-table-header-caption"><?php echo $Branch_MPP_crosstab->Location->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Branch_MPP_crosstab->Location->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Branch_MPP_crosstab->Location->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span>
		</div>
<?php } ?>
	</td>
<?php } ?>
<!-- Dynamic columns begin -->
<?php
	$cntval = count($Branch_MPP_crosstab->Columns);
	for ($iy = 1; $iy < $cntval; $iy++) {
		if ($Branch_MPP_crosstab->Columns[$iy]->Visible) {
			$Branch_MPP_crosstab->SummaryCurrentValues[$iy-1] = $Branch_MPP_crosstab->Columns[$iy]->Caption;
			$Branch_MPP_crosstab->SummaryViewValues[$iy-1] = $Branch_MPP_crosstab->SummaryCurrentValues[$iy-1];
?>
		<td class="ew-table-header"<?php echo $Branch_MPP_crosstab->Status->cellAttributes() ?>><div<?php echo $Branch_MPP_crosstab->Status->viewAttributes() ?>><?php echo $Branch_MPP_crosstab->SummaryViewValues[$iy-1]; ?></div></td>
<?php
		}
	}
?>
<!-- Dynamic columns end -->
		<td class="ew-table-header"<?php echo $Branch_MPP_crosstab->Status->cellAttributes() ?>><div<?php echo $Branch_MPP_crosstab->Status->viewAttributes() ?>><?php echo $Branch_MPP_crosstab->renderSummaryCaptions() ?></div></td>
	</tr>
</thead>
<tbody>
<?php
		if ($Branch_MPP_crosstab->TotalGroups == 0)
			break; // Show header only
		$Branch_MPP_crosstab->ShowHeader = FALSE;
	} // End show header
?>
<?php

	// Build detail SQL
	$where = DetailFilterSql($Branch_MPP_crosstab->Division, $Branch_MPP_crosstab->getSqlFirstGroupField(), $Branch_MPP_crosstab->Division->groupValue(), $Branch_MPP_crosstab->Dbid);
	if ($Branch_MPP_crosstab->PageFirstGroupFilter != "") $Branch_MPP_crosstab->PageFirstGroupFilter .= " OR ";
	$Branch_MPP_crosstab->PageFirstGroupFilter .= $where;
	if ($Branch_MPP_crosstab->Filter != "")
		$where = "($Branch_MPP_crosstab->Filter) AND ($where)";
	$sql = BuildReportSql(str_replace("{DistinctColumnFields}", $Branch_MPP_crosstab->DistinctColumnFields, $Branch_MPP_crosstab->getSqlSelect()), $Branch_MPP_crosstab->getSqlWhere(), $Branch_MPP_crosstab->getSqlGroupBy(), "", $Branch_MPP_crosstab->getSqlOrderBy(), $where, $Branch_MPP_crosstab->Sort);
	$rs = $Branch_MPP_crosstab->getRecordset($sql);
	$Branch_MPP_crosstab->DetailRecords = $rs ? $rs->getRows() : [];
	$Branch_MPP_crosstab->DetailRecordCount = count($Branch_MPP_crosstab->DetailRecords);

	// Load detail records
	$Branch_MPP_crosstab->Division->Records = &$Branch_MPP_crosstab->DetailRecords;
	$Branch_MPP_crosstab->Division->LevelBreak = TRUE; // Set field level break
	$Branch_MPP_crosstab->Branch->getDistinctValues($Branch_MPP_crosstab->Division->Records);
	foreach ($Branch_MPP_crosstab->Branch->DistinctValues as $Branch) { // Load records for this distinct value
		$Branch_MPP_crosstab->Branch->setGroupValue($Branch); // Set group value
		$Branch_MPP_crosstab->Branch->getDistinctRecords($Branch_MPP_crosstab->Division->Records, $Branch_MPP_crosstab->Branch->groupValue());
		$Branch_MPP_crosstab->Branch->LevelBreak = TRUE; // Set field level break
	$Branch_MPP_crosstab->Location->getDistinctValues($Branch_MPP_crosstab->Branch->Records);
	foreach ($Branch_MPP_crosstab->Location->DistinctValues as $Location) { // Load records for this distinct value
		$Branch_MPP_crosstab->Location->setGroupValue($Location); // Set group value
		$Branch_MPP_crosstab->Location->getDistinctRecords($Branch_MPP_crosstab->Branch->Records, $Branch_MPP_crosstab->Location->groupValue());
		$Branch_MPP_crosstab->Location->LevelBreak = TRUE; // Set field level break
	foreach ($Branch_MPP_crosstab->Location->Records as $record) {
		$Branch_MPP_crosstab->RecordCount++;
		$Branch_MPP_crosstab->RecordIndex++;
		$Branch_MPP_crosstab->loadRowValues($record);

		// Render row
		$Branch_MPP_crosstab->resetAttributes();
		$Branch_MPP_crosstab->RowType = ROWTYPE_DETAIL;
		$Branch_MPP_crosstab->renderRow();
?>
	<tr<?php echo $Branch_MPP_crosstab->rowAttributes(); ?>>
<?php if ($Branch_MPP_crosstab->Division->Visible) { ?>
		<!-- Division -->
		<td data-field="Division"<?php echo $Branch_MPP_crosstab->Division->cellAttributes(); ?>><span<?php echo $Branch_MPP_crosstab->Division->viewAttributes() ?>><?php echo $Branch_MPP_crosstab->Division->GroupViewValue ?></span></td>
<?php } ?>
<?php if ($Branch_MPP_crosstab->Branch->Visible) { ?>
		<!-- Branch -->
		<td data-field="Branch"<?php echo $Branch_MPP_crosstab->Branch->cellAttributes(); ?>><span<?php echo $Branch_MPP_crosstab->Branch->viewAttributes() ?>><?php echo $Branch_MPP_crosstab->Branch->GroupViewValue ?></span></td>
<?php } ?>
<?php if ($Branch_MPP_crosstab->Location->Visible) { ?>
		<!-- Location -->
		<td data-field="Location"<?php echo $Branch_MPP_crosstab->Location->cellAttributes(); ?>><span<?php echo $Branch_MPP_crosstab->Location->viewAttributes() ?>><?php echo $Branch_MPP_crosstab->Location->GroupViewValue ?></span></td>
<?php } ?>
<!-- Dynamic columns begin -->
<?php
		$cntcol = count($Branch_MPP_crosstab->SummaryViewValues);
		for ($iy = 1; $iy <= $cntcol; $iy++) {
			$colShow = ($iy <= $Branch_MPP_crosstab->ColumnCount) ? $Branch_MPP_crosstab->Columns[$iy]->Visible : TRUE;
			$colDesc = ($iy <= $Branch_MPP_crosstab->ColumnCount) ? $Branch_MPP_crosstab->Columns[$iy]->Caption : $Language->phrase("Summary");
			if ($colShow) {
?>
		<!-- <?php echo $colDesc; ?> -->
		<td<?php echo $Branch_MPP_crosstab->summaryCellAttributes($iy-1) ?>><?php echo $Branch_MPP_crosstab->renderSummaryFields($iy-1) ?></td>
<?php
			}
		}
?>
<!-- Dynamic columns end -->
	</tr>
<?php
	}
	} // End group level 2
?>
<?php if ($Branch_MPP_crosstab->TotalGroups > 0) { ?>
<?php
	$Branch_MPP_crosstab->getSummaryValues($Branch_MPP_crosstab->Branch->Records); // Get crosstab summaries from records
	$Branch_MPP_crosstab->resetAttributes();
	$Branch_MPP_crosstab->RowType = ROWTYPE_TOTAL;
	$Branch_MPP_crosstab->RowTotalType = ROWTOTAL_GROUP;
	$Branch_MPP_crosstab->RowTotalSubType = ROWTOTAL_FOOTER;
	$Branch_MPP_crosstab->RowGroupLevel = 2;
	$Branch_MPP_crosstab->renderRow();
?>
	<!-- Summary Branch (level 2) -->
	<tr<?php echo $Branch_MPP_crosstab->rowAttributes(); ?>>
		<td data-field="Division"<?php echo $Branch_MPP_crosstab->Division->cellAttributes() ?>>&nbsp;</td>
		<td colspan="<?php echo ($Branch_MPP_crosstab->GroupColumnCount - 1) ?>"<?php echo $Branch_MPP_crosstab->Branch->cellAttributes() ?>><?php echo str_replace(["%v", "%c"], [$Branch_MPP_crosstab->Branch->GroupViewValue, $Branch_MPP_crosstab->Branch->caption()], $Language->phrase("CtbSumHead")) ?></td>
<!-- Dynamic columns begin -->
<?php
	$cntcol = count($Branch_MPP_crosstab->SummaryViewValues);
	for ($iy = 1; $iy <= $cntcol; $iy++) {
		$colShow = ($iy <= $Branch_MPP_crosstab->ColumnCount) ? $Branch_MPP_crosstab->Columns[$iy]->Visible : TRUE;
		$colDesc = ($iy <= $Branch_MPP_crosstab->ColumnCount) ? $Branch_MPP_crosstab->Columns[$iy]->Caption : $Language->phrase("Summary");
		if ($colShow) {
?>
		<!-- <?php echo $colDesc; ?> -->
		<td<?php echo $Branch_MPP_crosstab->summaryCellAttributes($iy-1) ?>><?php echo $Branch_MPP_crosstab->renderSummaryFields($iy-1) ?></td>
<?php
		}
	}
?>
<!-- Dynamic columns end -->
	</tr>
<?php } ?>
<?php
	} // End group level 1
?>
<?php if ($Branch_MPP_crosstab->TotalGroups > 0) { ?>
<?php
	$Branch_MPP_crosstab->getSummaryValues($Branch_MPP_crosstab->Division->Records); // Get crosstab summaries from records
	$Branch_MPP_crosstab->resetAttributes();
	$Branch_MPP_crosstab->RowType = ROWTYPE_TOTAL;
	$Branch_MPP_crosstab->RowTotalType = ROWTOTAL_GROUP;
	$Branch_MPP_crosstab->RowTotalSubType = ROWTOTAL_FOOTER;
	$Branch_MPP_crosstab->RowGroupLevel = 1;
	$Branch_MPP_crosstab->renderRow();
?>
	<!-- Summary Division (level 1) -->
	<tr<?php echo $Branch_MPP_crosstab->rowAttributes(); ?>>
		<td colspan="<?php echo ($Branch_MPP_crosstab->GroupColumnCount - 0) ?>"<?php echo $Branch_MPP_crosstab->Division->cellAttributes() ?>><?php echo str_replace(["%v", "%c"], [$Branch_MPP_crosstab->Division->GroupViewValue, $Branch_MPP_crosstab->Division->caption()], $Language->phrase("CtbSumHead")) ?></td>
<!-- Dynamic columns begin -->
<?php
	$cntcol = count($Branch_MPP_crosstab->SummaryViewValues);
	for ($iy = 1; $iy <= $cntcol; $iy++) {
		$colShow = ($iy <= $Branch_MPP_crosstab->ColumnCount) ? $Branch_MPP_crosstab->Columns[$iy]->Visible : TRUE;
		$colDesc = ($iy <= $Branch_MPP_crosstab->ColumnCount) ? $Branch_MPP_crosstab->Columns[$iy]->Caption : $Language->phrase("Summary");
		if ($colShow) {
?>
		<!-- <?php echo $colDesc; ?> -->
		<td<?php echo $Branch_MPP_crosstab->summaryCellAttributes($iy-1) ?>><?php echo $Branch_MPP_crosstab->renderSummaryFields($iy-1) ?></td>
<?php
		}
	}
?>
<!-- Dynamic columns end -->
	</tr>
<?php } ?>
<?php
?>
<?php

	// Next group
	$Branch_MPP_crosstab->loadGroupRowValues();

	// Show header if page break
	if ($Branch_MPP_crosstab->isExport())
		$Branch_MPP_crosstab->ShowHeader = ($Branch_MPP_crosstab->ExportPageBreakCount == 0) ? FALSE : ($Branch_MPP_crosstab->GroupCount % $Branch_MPP_crosstab->ExportPageBreakCount == 0);

	// Page_Breaking server event
	if ($Branch_MPP_crosstab->ShowHeader)
		$Branch_MPP_crosstab->Page_Breaking($Branch_MPP_crosstab->ShowHeader, $Branch_MPP_crosstab->PageBreakContent);
	$Branch_MPP_crosstab->GroupCount++;
} // End while
?>
<?php if ($Branch_MPP_crosstab->TotalGroups > 0) { ?>
</tbody>
<tfoot>
<?php if (($Branch_MPP_crosstab->StopGroup - $Branch_MPP_crosstab->StartGroup + 1) != $Branch_MPP_crosstab->TotalGroups) { ?>
<?php
	$Branch_MPP_crosstab->resetAttributes();
	$Branch_MPP_crosstab->RowType = ROWTYPE_TOTAL;
	$Branch_MPP_crosstab->RowTotalType = ROWTOTAL_PAGE;
	$Branch_MPP_crosstab->RowAttrs["class"] = "ew-rpt-page-summary";
	$Branch_MPP_crosstab->renderRow();
?>
	<!-- Page Summary -->
	<tr<?php echo $Branch_MPP_crosstab->rowAttributes(); ?>>
<?php if ($Branch_MPP_crosstab->GroupColumnCount > 0) { ?>
	<td colspan="<?php echo $Branch_MPP_crosstab->GroupColumnCount ?>"><?php echo $Branch_MPP_crosstab->renderSummaryCaptions("page") ?></td>
<?php } ?>
<!-- Dynamic columns begin -->
<?php
	$cntcol = count($Branch_MPP_crosstab->SummaryViewValues);
	for ($iy = 1; $iy <= $cntcol; $iy++) {
		$colShow = ($iy <= $Branch_MPP_crosstab->ColumnCount) ? $Branch_MPP_crosstab->Columns[$iy]->Visible : TRUE;
		$colDesc = ($iy <= $Branch_MPP_crosstab->ColumnCount) ? $Branch_MPP_crosstab->Columns[$iy]->Caption : $Language->phrase("Summary");
		if ($colShow) {
?>
		<!-- <?php echo $colDesc; ?> -->
		<td<?php echo $Branch_MPP_crosstab->summaryCellAttributes($iy-1) ?>><?php echo $Branch_MPP_crosstab->renderSummaryFields($iy-1) ?></td>
<?php
		}
	}
?>
<!-- Dynamic columns end -->
	</tr>
<?php } ?>
<?php
	$Branch_MPP_crosstab->resetAttributes();
	$Branch_MPP_crosstab->RowType = ROWTYPE_TOTAL;
	$Branch_MPP_crosstab->RowTotalType = ROWTOTAL_GRAND;
	$Branch_MPP_crosstab->RowAttrs["class"] = "ew-rpt-grand-summary";
	$Branch_MPP_crosstab->renderRow();
?>
	<!-- Grand Total -->
	<tr<?php echo $Branch_MPP_crosstab->rowAttributes(); ?>>
<?php if ($Branch_MPP_crosstab->GroupColumnCount > 0) { ?>
	<td colspan="<?php echo $Branch_MPP_crosstab->GroupColumnCount ?>"><?php echo $Branch_MPP_crosstab->renderSummaryCaptions("grand") ?></td>
<?php } ?>
<!-- Dynamic columns begin -->
<?php
	$cntcol = count($Branch_MPP_crosstab->SummaryViewValues);
	for ($iy = 1; $iy <= $cntcol; $iy++) {
		$colShow = ($iy <= $Branch_MPP_crosstab->ColumnCount) ? $Branch_MPP_crosstab->Columns[$iy]->Visible : TRUE;
		$colDesc = ($iy <= $Branch_MPP_crosstab->ColumnCount) ? $Branch_MPP_crosstab->Columns[$iy]->Caption : $Language->phrase("Summary");
		if ($colShow) {
?>
		<!-- <?php echo $colDesc; ?> -->
		<td<?php echo $Branch_MPP_crosstab->summaryCellAttributes($iy-1) ?>><?php echo $Branch_MPP_crosstab->renderSummaryFields($iy-1) ?></td>
<?php
		}
	}
?>
<!-- Dynamic columns end -->
	</tr>
</tfoot>
</table>
</div>
<!-- /.ew-grid-middle-panel -->
<!-- Report grid (end) -->
<?php if ($Branch_MPP_crosstab->TotalGroups > 0) { ?>
<?php if (!$Branch_MPP_crosstab->isExport() && !($Branch_MPP_crosstab->DrillDown && $Branch_MPP_crosstab->TotalGroups > 0)) { ?>
<!-- Bottom pager -->
<div class="card-footer ew-grid-lower-panel">
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $Branch_MPP_crosstab->Pager->render() ?>
</form>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php } ?>
</div>
<!-- /.ew-grid -->
<?php } ?>
</div>
<!-- /#report-crosstab -->
<!-- Crosstab report (end) -->
<?php if ((!$Branch_MPP_crosstab->isExport() || $Branch_MPP_crosstab->isExport("print")) && !$DashboardReport) { ?>
</div>
<!-- /#ew-center -->
<?php } ?>
<?php if ((!$Branch_MPP_crosstab->isExport() || $Branch_MPP_crosstab->isExport("print")) && !$DashboardReport) { ?>
</div>
<!-- /.row -->
<?php } ?>
<?php if ((!$Branch_MPP_crosstab->isExport() || $Branch_MPP_crosstab->isExport("print")) && !$DashboardReport) { ?>
</div>
<!-- /.ew-report -->
<?php } ?>
<?php
$Branch_MPP_crosstab->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$Branch_MPP_crosstab->isExport() && !$Branch_MPP_crosstab->DrillDown && !$DashboardReport) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php if (!$DashboardReport) { ?>
<?php include_once "footer.php"; ?>
<?php } ?>
<?php
$Branch_MPP_crosstab->terminate();
?>