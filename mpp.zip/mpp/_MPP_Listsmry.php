<?php
namespace PHPMaker2020\mpp;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$_MPP_List_summary = new _MPP_List_summary();

// Run the page
$_MPP_List_summary->run();

// Setup login status
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$_MPP_List_summary->Page_Render();
?>
<?php if (!$DashboardReport) { ?>
<?php include_once "header.php"; ?>
<?php } ?>
<?php if (!$_MPP_List_summary->isExport() && !$_MPP_List_summary->DrillDown && !$DashboardReport) { ?>
<script>
var fsummary, currentPageID;
loadjs.ready("head", function() {

	// Form object for search
	fsummary = currentForm = new ew.Form("fsummary", "summary");
	currentPageID = ew.PAGE_ID = "summary";

	// Validate function for search
	fsummary.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fsummary.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fsummary.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fsummary.lists["x_Position"] = <?php echo $_MPP_List_summary->Position->Lookup->toClientList($_MPP_List_summary) ?>;
	fsummary.lists["x_Position"].options = <?php echo JsonEncode($_MPP_List_summary->Position->lookupOptions()) ?>;
	fsummary.lists["x_Location"] = <?php echo $_MPP_List_summary->Location->Lookup->toClientList($_MPP_List_summary) ?>;
	fsummary.lists["x_Location"].options = <?php echo JsonEncode($_MPP_List_summary->Location->lookupOptions()) ?>;
	fsummary.lists["x_Branch"] = <?php echo $_MPP_List_summary->Branch->Lookup->toClientList($_MPP_List_summary) ?>;
	fsummary.lists["x_Branch"].options = <?php echo JsonEncode($_MPP_List_summary->Branch->lookupOptions()) ?>;
	fsummary.lists["x_Status[]"] = <?php echo $_MPP_List_summary->Status->Lookup->toClientList($_MPP_List_summary) ?>;
	fsummary.lists["x_Status[]"].options = <?php echo JsonEncode($_MPP_List_summary->Status->lookupOptions()) ?>;
	fsummary.lists["x_Group[]"] = <?php echo $_MPP_List_summary->Group->Lookup->toClientList($_MPP_List_summary) ?>;
	fsummary.lists["x_Group[]"].options = <?php echo JsonEncode($_MPP_List_summary->Group->lookupOptions()) ?>;

	// Filters
	fsummary.filterList = <?php echo $_MPP_List_summary->getFilterList() ?>;
	loadjs.done("fsummary");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<a id="top"></a>
<?php if ((!$_MPP_List_summary->isExport() || $_MPP_List_summary->isExport("print")) && !$DashboardReport) { ?>
<!-- Content Container -->
<div id="ew-report" class="ew-report container-fluid">
<?php } ?>
<?php if ($_MPP_List_summary->ShowCurrentFilter) { ?>
<?php $_MPP_List_summary->showFilterList() ?>
<?php } ?>
<div class="btn-toolbar ew-toolbar">
<?php
if (!$_MPP_List_summary->DrillDownInPanel) {
	$_MPP_List_summary->ExportOptions->render("body");
	$_MPP_List_summary->SearchOptions->render("body");
	$_MPP_List_summary->FilterOptions->render("body");
}
?>
</div>
<?php $_MPP_List_summary->showPageHeader(); ?>
<?php
$_MPP_List_summary->showMessage();
?>
<?php if ((!$_MPP_List_summary->isExport() || $_MPP_List_summary->isExport("print")) && !$DashboardReport) { ?>
<div class="row">
<?php } ?>
<?php if ((!$_MPP_List_summary->isExport() || $_MPP_List_summary->isExport("print")) && !$DashboardReport) { ?>
<!-- Center Container -->
<div id="ew-center" class="<?php echo $_MPP_List_summary->CenterContentClass ?>">
<?php } ?>
<?php if ($_MPP_List_summary->ShowDrillDownFilter) { ?>
<?php $_MPP_List_summary->showDrillDownList() ?>
<?php } ?>
<!-- Summary report (begin) -->
<div id="report_summary">
<?php if (!$_MPP_List_summary->isExport() && !$_MPP_List_summary->DrillDown && !$DashboardReport) { ?>
<?php if (!$_MPP_List_summary->isExport() && !$_MPP_List->CurrentAction) { ?>
<form name="fsummary" id="fsummary" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fsummary-search-panel" class="<?php echo $_MPP_List_summary->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="_MPP_List">
	<div class="ew-extended-search">
<?php

// Render search row
$_MPP_List->RowType = ROWTYPE_SEARCH;
$_MPP_List->resetAttributes();
$_MPP_List_summary->renderRow();
?>
<?php if ($_MPP_List_summary->Position->Visible) { // Position ?>
	<?php
		$_MPP_List_summary->SearchColumnCount++;
		if (($_MPP_List_summary->SearchColumnCount - 1) % $_MPP_List_summary->SearchFieldsPerRow == 0) {
			$_MPP_List_summary->SearchRowCount++;
	?>
<div id="xsr_<?php echo $_MPP_List_summary->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_Position" class="ew-cell form-group">
		<label for="x_Position" class="ew-search-caption ew-label"><?php echo $_MPP_List_summary->Position->caption() ?></label>
		<span id="el__MPP_List_Position" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="_MPP_List" data-field="x_Position" data-value-separator="<?php echo $_MPP_List_summary->Position->displayValueSeparatorAttribute() ?>" id="x_Position" name="x_Position"<?php echo $_MPP_List_summary->Position->editAttributes() ?>>
			<?php echo $_MPP_List_summary->Position->selectOptionListHtml("x_Position") ?>
		</select>
</div>
<?php echo $_MPP_List_summary->Position->Lookup->getParamTag($_MPP_List_summary, "p_x_Position") ?>
</span>
	</div>
	<?php if ($_MPP_List_summary->SearchColumnCount % $_MPP_List_summary->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($_MPP_List_summary->Location->Visible) { // Location ?>
	<?php
		$_MPP_List_summary->SearchColumnCount++;
		if (($_MPP_List_summary->SearchColumnCount - 1) % $_MPP_List_summary->SearchFieldsPerRow == 0) {
			$_MPP_List_summary->SearchRowCount++;
	?>
<div id="xsr_<?php echo $_MPP_List_summary->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_Location" class="ew-cell form-group">
		<label for="x_Location" class="ew-search-caption ew-label"><?php echo $_MPP_List_summary->Location->caption() ?></label>
		<span id="el__MPP_List_Location" class="ew-search-field">
<?php $_MPP_List_summary->Location->EditAttrs->prepend("onchange", "ew.updateOptions.call(this);"); ?>
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="_MPP_List" data-field="x_Location" data-value-separator="<?php echo $_MPP_List_summary->Location->displayValueSeparatorAttribute() ?>" id="x_Location" name="x_Location"<?php echo $_MPP_List_summary->Location->editAttributes() ?>>
			<?php echo $_MPP_List_summary->Location->selectOptionListHtml("x_Location") ?>
		</select>
</div>
<?php echo $_MPP_List_summary->Location->Lookup->getParamTag($_MPP_List_summary, "p_x_Location") ?>
</span>
	</div>
	<?php if ($_MPP_List_summary->SearchColumnCount % $_MPP_List_summary->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($_MPP_List_summary->Branch->Visible) { // Branch ?>
	<?php
		$_MPP_List_summary->SearchColumnCount++;
		if (($_MPP_List_summary->SearchColumnCount - 1) % $_MPP_List_summary->SearchFieldsPerRow == 0) {
			$_MPP_List_summary->SearchRowCount++;
	?>
<div id="xsr_<?php echo $_MPP_List_summary->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_Branch" class="ew-cell form-group">
		<label for="x_Branch" class="ew-search-caption ew-label"><?php echo $_MPP_List_summary->Branch->caption() ?></label>
		<span id="el__MPP_List_Branch" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="_MPP_List" data-field="x_Branch" data-value-separator="<?php echo $_MPP_List_summary->Branch->displayValueSeparatorAttribute() ?>" id="x_Branch" name="x_Branch"<?php echo $_MPP_List_summary->Branch->editAttributes() ?>>
			<?php echo $_MPP_List_summary->Branch->selectOptionListHtml("x_Branch") ?>
		</select>
</div>
<?php echo $_MPP_List_summary->Branch->Lookup->getParamTag($_MPP_List_summary, "p_x_Branch") ?>
</span>
	</div>
	<?php if ($_MPP_List_summary->SearchColumnCount % $_MPP_List_summary->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($_MPP_List_summary->Status->Visible) { // Status ?>
	<?php
		$_MPP_List_summary->SearchColumnCount++;
		if (($_MPP_List_summary->SearchColumnCount - 1) % $_MPP_List_summary->SearchFieldsPerRow == 0) {
			$_MPP_List_summary->SearchRowCount++;
	?>
<div id="xsr_<?php echo $_MPP_List_summary->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_Status" class="ew-cell form-group">
		<label class="ew-search-caption ew-label"><?php echo $_MPP_List_summary->Status->caption() ?></label>
		<span id="el__MPP_List_Status" class="ew-search-field">
<div id="tp_x_Status" class="ew-template"><input type="checkbox" class="custom-control-input" data-table="_MPP_List" data-field="x_Status" data-value-separator="<?php echo $_MPP_List_summary->Status->displayValueSeparatorAttribute() ?>" name="x_Status[]" id="x_Status[]" value="{value}"<?php echo $_MPP_List_summary->Status->editAttributes() ?>></div>
<div id="dsl_x_Status" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $_MPP_List_summary->Status->checkBoxListHtml(FALSE, "x_Status[]") ?>
</div></div>
<?php echo $_MPP_List_summary->Status->Lookup->getParamTag($_MPP_List_summary, "p_x_Status") ?>
</span>
	</div>
	<?php if ($_MPP_List_summary->SearchColumnCount % $_MPP_List_summary->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($_MPP_List_summary->Group->Visible) { // Group ?>
	<?php
		$_MPP_List_summary->SearchColumnCount++;
		if (($_MPP_List_summary->SearchColumnCount - 1) % $_MPP_List_summary->SearchFieldsPerRow == 0) {
			$_MPP_List_summary->SearchRowCount++;
	?>
<div id="xsr_<?php echo $_MPP_List_summary->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_Group" class="ew-cell form-group">
		<label class="ew-search-caption ew-label"><?php echo $_MPP_List_summary->Group->caption() ?></label>
		<span id="el__MPP_List_Group" class="ew-search-field">
<div id="tp_x_Group" class="ew-template"><input type="checkbox" class="custom-control-input" data-table="_MPP_List" data-field="x_Group" data-value-separator="<?php echo $_MPP_List_summary->Group->displayValueSeparatorAttribute() ?>" name="x_Group[]" id="x_Group[]" value="{value}"<?php echo $_MPP_List_summary->Group->editAttributes() ?>></div>
<div id="dsl_x_Group" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $_MPP_List_summary->Group->checkBoxListHtml(FALSE, "x_Group[]") ?>
</div></div>
<?php echo $_MPP_List_summary->Group->Lookup->getParamTag($_MPP_List_summary, "p_x_Group") ?>
</span>
	</div>
	<?php if ($_MPP_List_summary->SearchColumnCount % $_MPP_List_summary->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
	<?php if ($_MPP_List_summary->SearchColumnCount % $_MPP_List_summary->SearchFieldsPerRow > 0) { ?>
</div>
	<?php } ?>
<div id="xsr_<?php echo $_MPP_List_summary->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php
while ($_MPP_List_summary->GroupCount <= count($_MPP_List_summary->GroupRecords) && $_MPP_List_summary->GroupCount <= $_MPP_List_summary->DisplayGroups) {
?>
<?php

	// Show header
	if ($_MPP_List_summary->ShowHeader) {
?>
<?php if ($_MPP_List_summary->GroupCount > 1) { ?>
</tbody>
</table>
</div>
<!-- /.ew-grid-middle-panel -->
<!-- Report grid (end) -->
<?php if ($_MPP_List_summary->TotalGroups > 0) { ?>
<?php if (!$_MPP_List_summary->isExport() && !($_MPP_List_summary->DrillDown && $_MPP_List_summary->TotalGroups > 0)) { ?>
<!-- Bottom pager -->
<div class="card-footer ew-grid-lower-panel">
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $_MPP_List_summary->Pager->render() ?>
</form>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php } ?>
</div>
<!-- /.ew-grid -->
<?php echo $_MPP_List_summary->PageBreakContent ?>
<?php } ?>
<div class="<?php if (!$_MPP_List_summary->isExport("word") && !$_MPP_List_summary->isExport("excel")) { ?>card ew-card <?php } ?>ew-grid"<?php echo $_MPP_List_summary->ReportTableStyle ?>>
<?php if (!$_MPP_List_summary->isExport() && !($_MPP_List_summary->DrillDown && $_MPP_List_summary->TotalGroups > 0)) { ?>
<!-- Top pager -->
<div class="card-header ew-grid-upper-panel">
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $_MPP_List_summary->Pager->render() ?>
</form>
<div class="clearfix"></div>
</div>
<?php } ?>
<!-- Report grid (begin) -->
<div id="gmp__MPP_List" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="<?php echo $_MPP_List_summary->ReportTableClass ?>">
<thead>
	<!-- Table header -->
	<tr class="ew-table-header">
<?php if ($_MPP_List_summary->Period->Visible) { ?>
	<?php if ($_MPP_List_summary->Period->ShowGroupHeaderAsRow) { ?>
	<th data-name="Period">&nbsp;</th>
	<?php } else { ?>
		<?php if ($_MPP_List_summary->sortUrl($_MPP_List_summary->Period) == "") { ?>
	<th data-name="Period" class="<?php echo $_MPP_List_summary->Period->headerCellClass() ?>"><div class="_MPP_List_Period"><div class="ew-table-header-caption"><?php echo $_MPP_List_summary->Period->caption() ?></div></div></th>
		<?php } else { ?>
	<th data-name="Period" class="<?php echo $_MPP_List_summary->Period->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $_MPP_List_summary->sortUrl($_MPP_List_summary->Period) ?>', 1);"><div class="_MPP_List_Period">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $_MPP_List_summary->Period->caption() ?></span><span class="ew-table-header-sort"><?php if ($_MPP_List_summary->Period->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($_MPP_List_summary->Period->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
		<?php } ?>
	<?php } ?>
<?php } ?>
<?php if ($_MPP_List_summary->Position->Visible) { ?>
	<?php if ($_MPP_List_summary->Position->ShowGroupHeaderAsRow) { ?>
	<th data-name="Position">&nbsp;</th>
	<?php } else { ?>
		<?php if ($_MPP_List_summary->sortUrl($_MPP_List_summary->Position) == "") { ?>
	<th data-name="Position" class="<?php echo $_MPP_List_summary->Position->headerCellClass() ?>"><div class="_MPP_List_Position"><div class="ew-table-header-caption"><?php echo $_MPP_List_summary->Position->caption() ?></div></div></th>
		<?php } else { ?>
	<th data-name="Position" class="<?php echo $_MPP_List_summary->Position->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $_MPP_List_summary->sortUrl($_MPP_List_summary->Position) ?>', 1);"><div class="_MPP_List_Position">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $_MPP_List_summary->Position->caption() ?></span><span class="ew-table-header-sort"><?php if ($_MPP_List_summary->Position->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($_MPP_List_summary->Position->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
		<?php } ?>
	<?php } ?>
<?php } ?>
<?php if ($_MPP_List_summary->Location->Visible) { ?>
	<?php if ($_MPP_List_summary->Location->ShowGroupHeaderAsRow) { ?>
	<th data-name="Location">&nbsp;</th>
	<?php } else { ?>
		<?php if ($_MPP_List_summary->sortUrl($_MPP_List_summary->Location) == "") { ?>
	<th data-name="Location" class="<?php echo $_MPP_List_summary->Location->headerCellClass() ?>"><div class="_MPP_List_Location"><div class="ew-table-header-caption"><?php echo $_MPP_List_summary->Location->caption() ?></div></div></th>
		<?php } else { ?>
	<th data-name="Location" class="<?php echo $_MPP_List_summary->Location->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $_MPP_List_summary->sortUrl($_MPP_List_summary->Location) ?>', 1);"><div class="_MPP_List_Location">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $_MPP_List_summary->Location->caption() ?></span><span class="ew-table-header-sort"><?php if ($_MPP_List_summary->Location->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($_MPP_List_summary->Location->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
		<?php } ?>
	<?php } ?>
<?php } ?>
<?php if ($_MPP_List_summary->Branch->Visible) { ?>
	<?php if ($_MPP_List_summary->Branch->ShowGroupHeaderAsRow) { ?>
	<th data-name="Branch">&nbsp;</th>
	<?php } else { ?>
		<?php if ($_MPP_List_summary->sortUrl($_MPP_List_summary->Branch) == "") { ?>
	<th data-name="Branch" class="<?php echo $_MPP_List_summary->Branch->headerCellClass() ?>"><div class="_MPP_List_Branch"><div class="ew-table-header-caption"><?php echo $_MPP_List_summary->Branch->caption() ?></div></div></th>
		<?php } else { ?>
	<th data-name="Branch" class="<?php echo $_MPP_List_summary->Branch->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $_MPP_List_summary->sortUrl($_MPP_List_summary->Branch) ?>', 1);"><div class="_MPP_List_Branch">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $_MPP_List_summary->Branch->caption() ?></span><span class="ew-table-header-sort"><?php if ($_MPP_List_summary->Branch->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($_MPP_List_summary->Branch->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
		<?php } ?>
	<?php } ?>
<?php } ?>
<?php if ($_MPP_List_summary->Status->Visible) { ?>
	<?php if ($_MPP_List_summary->Status->ShowGroupHeaderAsRow) { ?>
	<th data-name="Status">&nbsp;</th>
	<?php } else { ?>
		<?php if ($_MPP_List_summary->sortUrl($_MPP_List_summary->Status) == "") { ?>
	<th data-name="Status" class="<?php echo $_MPP_List_summary->Status->headerCellClass() ?>"><div class="_MPP_List_Status"><div class="ew-table-header-caption"><?php echo $_MPP_List_summary->Status->caption() ?></div></div></th>
		<?php } else { ?>
	<th data-name="Status" class="<?php echo $_MPP_List_summary->Status->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $_MPP_List_summary->sortUrl($_MPP_List_summary->Status) ?>', 1);"><div class="_MPP_List_Status">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $_MPP_List_summary->Status->caption() ?></span><span class="ew-table-header-sort"><?php if ($_MPP_List_summary->Status->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($_MPP_List_summary->Status->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
		<?php } ?>
	<?php } ?>
<?php } ?>
<?php if ($_MPP_List_summary->Group->Visible) { ?>
	<?php if ($_MPP_List_summary->Group->ShowGroupHeaderAsRow) { ?>
	<th data-name="Group">&nbsp;</th>
	<?php } else { ?>
		<?php if ($_MPP_List_summary->sortUrl($_MPP_List_summary->Group) == "") { ?>
	<th data-name="Group" class="<?php echo $_MPP_List_summary->Group->headerCellClass() ?>"><div class="_MPP_List_Group"><div class="ew-table-header-caption"><?php echo $_MPP_List_summary->Group->caption() ?></div></div></th>
		<?php } else { ?>
	<th data-name="Group" class="<?php echo $_MPP_List_summary->Group->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $_MPP_List_summary->sortUrl($_MPP_List_summary->Group) ?>', 1);"><div class="_MPP_List_Group">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $_MPP_List_summary->Group->caption() ?></span><span class="ew-table-header-sort"><?php if ($_MPP_List_summary->Group->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($_MPP_List_summary->Group->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
		<?php } ?>
	<?php } ?>
<?php } ?>
<?php if ($_MPP_List_summary->Division->Visible) { ?>
	<?php if ($_MPP_List_summary->sortUrl($_MPP_List_summary->Division) == "") { ?>
	<th data-name="Division" class="<?php echo $_MPP_List_summary->Division->headerCellClass() ?>"><div class="_MPP_List_Division"><div class="ew-table-header-caption"><?php echo $_MPP_List_summary->Division->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="Division" class="<?php echo $_MPP_List_summary->Division->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $_MPP_List_summary->sortUrl($_MPP_List_summary->Division) ?>', 1);"><div class="_MPP_List_Division">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $_MPP_List_summary->Division->caption() ?></span><span class="ew-table-header-sort"><?php if ($_MPP_List_summary->Division->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($_MPP_List_summary->Division->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($_MPP_List_summary->Sum28mpp_Amount29->Visible) { ?>
	<?php if ($_MPP_List_summary->sortUrl($_MPP_List_summary->Sum28mpp_Amount29) == "") { ?>
	<th data-name="Sum28mpp_Amount29" class="<?php echo $_MPP_List_summary->Sum28mpp_Amount29->headerCellClass() ?>"><div class="_MPP_List_Sum28mpp_Amount29"><div class="ew-table-header-caption"><?php echo $_MPP_List_summary->Sum28mpp_Amount29->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="Sum28mpp_Amount29" class="<?php echo $_MPP_List_summary->Sum28mpp_Amount29->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $_MPP_List_summary->sortUrl($_MPP_List_summary->Sum28mpp_Amount29) ?>', 1);"><div class="_MPP_List_Sum28mpp_Amount29">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $_MPP_List_summary->Sum28mpp_Amount29->caption() ?></span><span class="ew-table-header-sort"><?php if ($_MPP_List_summary->Sum28mpp_Amount29->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($_MPP_List_summary->Sum28mpp_Amount29->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
	</tr>
</thead>
<tbody>
<?php
		if ($_MPP_List_summary->TotalGroups == 0)
			break; // Show header only
		$_MPP_List_summary->ShowHeader = FALSE;
	} // End show header
?>
<?php

	// Build detail SQL
	$where = DetailFilterSql($_MPP_List_summary->Period, $_MPP_List_summary->getSqlFirstGroupField(), $_MPP_List_summary->Period->groupValue(), $_MPP_List_summary->Dbid);
	if ($_MPP_List_summary->PageFirstGroupFilter != "") $_MPP_List_summary->PageFirstGroupFilter .= " OR ";
	$_MPP_List_summary->PageFirstGroupFilter .= $where;
	if ($_MPP_List_summary->Filter != "")
		$where = "($_MPP_List_summary->Filter) AND ($where)";
	$sql = BuildReportSql($_MPP_List_summary->getSqlSelect(), $_MPP_List_summary->getSqlWhere(), $_MPP_List_summary->getSqlGroupBy(), $_MPP_List_summary->getSqlHaving(), $_MPP_List_summary->getSqlOrderBy(), $where, $_MPP_List_summary->Sort);
	$rs = $_MPP_List_summary->getRecordset($sql);
	$_MPP_List_summary->DetailRecords = $rs ? $rs->getRows() : [];
	$_MPP_List_summary->DetailRecordCount = count($_MPP_List_summary->DetailRecords);

	// Load detail records
	$_MPP_List_summary->Period->Records = &$_MPP_List_summary->DetailRecords;
	$_MPP_List_summary->Period->LevelBreak = TRUE; // Set field level break
		$_MPP_List_summary->GroupCounter[1] = $_MPP_List_summary->GroupCount;
		$_MPP_List_summary->Period->getCnt($_MPP_List_summary->Period->Records); // Get record count
?>
<?php if ($_MPP_List_summary->Period->Visible && $_MPP_List_summary->Period->ShowGroupHeaderAsRow) { ?>
<?php

		// Render header row
		$_MPP_List_summary->resetAttributes();
		$_MPP_List_summary->RowType = ROWTYPE_TOTAL;
		$_MPP_List_summary->RowTotalType = ROWTOTAL_GROUP;
		$_MPP_List_summary->RowTotalSubType = ROWTOTAL_HEADER;
		$_MPP_List_summary->RowGroupLevel = 1;
		$_MPP_List_summary->renderRow();
?>
	<tr<?php echo $_MPP_List_summary->rowAttributes(); ?>>
<?php if ($_MPP_List_summary->Period->Visible) { ?>
		<td data-field="Period"<?php echo $_MPP_List_summary->Period->cellAttributes(); ?>><span class="ew-group-toggle icon-collapse"></span></td>
<?php } ?>
		<td data-field="Period" colspan="<?php echo ($Page->GroupColumnCount + $Page->DetailColumnCount - 1) ?>"<?php echo $_MPP_List_summary->Period->cellAttributes() ?>>
<?php if ($_MPP_List_summary->sortUrl($_MPP_List_summary->Period) == "") { ?>
		<span class="ew-summary-caption _MPP_List_Period"><span class="ew-table-header-caption"><?php echo $_MPP_List_summary->Period->caption() ?></span></span>
<?php } else { ?>
		<span class="ew-table-header-btn ew-pointer ew-summary-caption _MPP_List_Period" onclick="ew.sort(event, '<?php echo $_MPP_List_summary->sortUrl($_MPP_List_summary->Period) ?>', 1);">
			<span class="ew-table-header-caption"><?php echo $_MPP_List_summary->Period->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($_MPP_List_summary->Period->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($_MPP_List_summary->Period->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span>
		</span>
<?php } ?>
		<?php echo $Language->phrase("SummaryColon") ?><span<?php echo $_MPP_List_summary->Period->viewAttributes() ?>><?php echo $_MPP_List_summary->Period->GroupViewValue ?></span>
		<span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($_MPP_List_summary->Period->Count, 0); ?></span>)</span>
		</td>
	</tr>
<?php } ?>
<?php
	$_MPP_List_summary->Position->getDistinctValues($_MPP_List_summary->Period->Records);
	$_MPP_List_summary->setGroupCount(count($_MPP_List_summary->Position->DistinctValues), $_MPP_List_summary->GroupCounter[1]);
	$_MPP_List_summary->GroupCounter[2] = 0; // Init group count index
	foreach ($_MPP_List_summary->Position->DistinctValues as $Position) { // Load records for this distinct value
		$_MPP_List_summary->Position->setGroupValue($Position); // Set group value
		$_MPP_List_summary->Position->getDistinctRecords($_MPP_List_summary->Period->Records, $_MPP_List_summary->Position->groupValue());
		$_MPP_List_summary->Position->LevelBreak = TRUE; // Set field level break
		$_MPP_List_summary->GroupCounter[2]++;
		$_MPP_List_summary->Position->getCnt($_MPP_List_summary->Position->Records); // Get record count
?>
<?php if ($_MPP_List_summary->Position->Visible && $_MPP_List_summary->Position->ShowGroupHeaderAsRow) { ?>
<?php

		// Render header row
		$_MPP_List_summary->Position->setDbValue($Position); // Set current value for Position
		$_MPP_List_summary->resetAttributes();
		$_MPP_List_summary->RowType = ROWTYPE_TOTAL;
		$_MPP_List_summary->RowTotalType = ROWTOTAL_GROUP;
		$_MPP_List_summary->RowTotalSubType = ROWTOTAL_HEADER;
		$_MPP_List_summary->RowGroupLevel = 2;
		$_MPP_List_summary->renderRow();
?>
	<tr<?php echo $_MPP_List_summary->rowAttributes(); ?>>
<?php if ($_MPP_List_summary->Period->Visible) { ?>
		<td data-field="Period"<?php echo $_MPP_List_summary->Period->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($_MPP_List_summary->Position->Visible) { ?>
		<td data-field="Position"<?php echo $_MPP_List_summary->Position->cellAttributes(); ?>><span class="ew-group-toggle icon-collapse"></span></td>
<?php } ?>
		<td data-field="Position" colspan="<?php echo ($Page->GroupColumnCount + $Page->DetailColumnCount - 2) ?>"<?php echo $_MPP_List_summary->Position->cellAttributes() ?>>
<?php if ($_MPP_List_summary->sortUrl($_MPP_List_summary->Position) == "") { ?>
		<span class="ew-summary-caption _MPP_List_Position"><span class="ew-table-header-caption"><?php echo $_MPP_List_summary->Position->caption() ?></span></span>
<?php } else { ?>
		<span class="ew-table-header-btn ew-pointer ew-summary-caption _MPP_List_Position" onclick="ew.sort(event, '<?php echo $_MPP_List_summary->sortUrl($_MPP_List_summary->Position) ?>', 1);">
			<span class="ew-table-header-caption"><?php echo $_MPP_List_summary->Position->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($_MPP_List_summary->Position->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($_MPP_List_summary->Position->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span>
		</span>
<?php } ?>
		<?php echo $Language->phrase("SummaryColon") ?><span<?php echo $_MPP_List_summary->Position->viewAttributes() ?>><?php echo $_MPP_List_summary->Position->GroupViewValue ?></span>
		<span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($_MPP_List_summary->Position->Count, 0); ?></span>)</span>
		</td>
	</tr>
<?php } ?>
<?php
	$_MPP_List_summary->Location->getDistinctValues($_MPP_List_summary->Position->Records);
	$_MPP_List_summary->setGroupCount(count($_MPP_List_summary->Location->DistinctValues), $_MPP_List_summary->GroupCounter[1], $_MPP_List_summary->GroupCounter[2]);
	$_MPP_List_summary->GroupCounter[3] = 0; // Init group count index
	foreach ($_MPP_List_summary->Location->DistinctValues as $Location) { // Load records for this distinct value
		$_MPP_List_summary->Location->setGroupValue($Location); // Set group value
		$_MPP_List_summary->Location->getDistinctRecords($_MPP_List_summary->Position->Records, $_MPP_List_summary->Location->groupValue());
		$_MPP_List_summary->Location->LevelBreak = TRUE; // Set field level break
		$_MPP_List_summary->GroupCounter[3]++;
		$_MPP_List_summary->Location->getCnt($_MPP_List_summary->Location->Records); // Get record count
?>
<?php if ($_MPP_List_summary->Location->Visible && $_MPP_List_summary->Location->ShowGroupHeaderAsRow) { ?>
<?php

		// Render header row
		$_MPP_List_summary->Location->setDbValue($Location); // Set current value for Location
		$_MPP_List_summary->resetAttributes();
		$_MPP_List_summary->RowType = ROWTYPE_TOTAL;
		$_MPP_List_summary->RowTotalType = ROWTOTAL_GROUP;
		$_MPP_List_summary->RowTotalSubType = ROWTOTAL_HEADER;
		$_MPP_List_summary->RowGroupLevel = 3;
		$_MPP_List_summary->renderRow();
?>
	<tr<?php echo $_MPP_List_summary->rowAttributes(); ?>>
<?php if ($_MPP_List_summary->Period->Visible) { ?>
		<td data-field="Period"<?php echo $_MPP_List_summary->Period->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($_MPP_List_summary->Position->Visible) { ?>
		<td data-field="Position"<?php echo $_MPP_List_summary->Position->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($_MPP_List_summary->Location->Visible) { ?>
		<td data-field="Location"<?php echo $_MPP_List_summary->Location->cellAttributes(); ?>><span class="ew-group-toggle icon-collapse"></span></td>
<?php } ?>
		<td data-field="Location" colspan="<?php echo ($Page->GroupColumnCount + $Page->DetailColumnCount - 3) ?>"<?php echo $_MPP_List_summary->Location->cellAttributes() ?>>
<?php if ($_MPP_List_summary->sortUrl($_MPP_List_summary->Location) == "") { ?>
		<span class="ew-summary-caption _MPP_List_Location"><span class="ew-table-header-caption"><?php echo $_MPP_List_summary->Location->caption() ?></span></span>
<?php } else { ?>
		<span class="ew-table-header-btn ew-pointer ew-summary-caption _MPP_List_Location" onclick="ew.sort(event, '<?php echo $_MPP_List_summary->sortUrl($_MPP_List_summary->Location) ?>', 1);">
			<span class="ew-table-header-caption"><?php echo $_MPP_List_summary->Location->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($_MPP_List_summary->Location->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($_MPP_List_summary->Location->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span>
		</span>
<?php } ?>
		<?php echo $Language->phrase("SummaryColon") ?><span<?php echo $_MPP_List_summary->Location->viewAttributes() ?>><?php echo $_MPP_List_summary->Location->GroupViewValue ?></span>
		<span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($_MPP_List_summary->Location->Count, 0); ?></span>)</span>
		</td>
	</tr>
<?php } ?>
<?php
	$_MPP_List_summary->Branch->getDistinctValues($_MPP_List_summary->Location->Records);
	$_MPP_List_summary->setGroupCount(count($_MPP_List_summary->Branch->DistinctValues), $_MPP_List_summary->GroupCounter[1], $_MPP_List_summary->GroupCounter[2], $_MPP_List_summary->GroupCounter[3]);
	$_MPP_List_summary->GroupCounter[4] = 0; // Init group count index
	foreach ($_MPP_List_summary->Branch->DistinctValues as $Branch) { // Load records for this distinct value
		$_MPP_List_summary->Branch->setGroupValue($Branch); // Set group value
		$_MPP_List_summary->Branch->getDistinctRecords($_MPP_List_summary->Location->Records, $_MPP_List_summary->Branch->groupValue());
		$_MPP_List_summary->Branch->LevelBreak = TRUE; // Set field level break
		$_MPP_List_summary->GroupCounter[4]++;
		$_MPP_List_summary->Branch->getCnt($_MPP_List_summary->Branch->Records); // Get record count
?>
<?php if ($_MPP_List_summary->Branch->Visible && $_MPP_List_summary->Branch->ShowGroupHeaderAsRow) { ?>
<?php

		// Render header row
		$_MPP_List_summary->Branch->setDbValue($Branch); // Set current value for Branch
		$_MPP_List_summary->resetAttributes();
		$_MPP_List_summary->RowType = ROWTYPE_TOTAL;
		$_MPP_List_summary->RowTotalType = ROWTOTAL_GROUP;
		$_MPP_List_summary->RowTotalSubType = ROWTOTAL_HEADER;
		$_MPP_List_summary->RowGroupLevel = 4;
		$_MPP_List_summary->renderRow();
?>
	<tr<?php echo $_MPP_List_summary->rowAttributes(); ?>>
<?php if ($_MPP_List_summary->Period->Visible) { ?>
		<td data-field="Period"<?php echo $_MPP_List_summary->Period->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($_MPP_List_summary->Position->Visible) { ?>
		<td data-field="Position"<?php echo $_MPP_List_summary->Position->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($_MPP_List_summary->Location->Visible) { ?>
		<td data-field="Location"<?php echo $_MPP_List_summary->Location->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($_MPP_List_summary->Branch->Visible) { ?>
		<td data-field="Branch"<?php echo $_MPP_List_summary->Branch->cellAttributes(); ?>><span class="ew-group-toggle icon-collapse"></span></td>
<?php } ?>
		<td data-field="Branch" colspan="<?php echo ($Page->GroupColumnCount + $Page->DetailColumnCount - 4) ?>"<?php echo $_MPP_List_summary->Branch->cellAttributes() ?>>
<?php if ($_MPP_List_summary->sortUrl($_MPP_List_summary->Branch) == "") { ?>
		<span class="ew-summary-caption _MPP_List_Branch"><span class="ew-table-header-caption"><?php echo $_MPP_List_summary->Branch->caption() ?></span></span>
<?php } else { ?>
		<span class="ew-table-header-btn ew-pointer ew-summary-caption _MPP_List_Branch" onclick="ew.sort(event, '<?php echo $_MPP_List_summary->sortUrl($_MPP_List_summary->Branch) ?>', 1);">
			<span class="ew-table-header-caption"><?php echo $_MPP_List_summary->Branch->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($_MPP_List_summary->Branch->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($_MPP_List_summary->Branch->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span>
		</span>
<?php } ?>
		<?php echo $Language->phrase("SummaryColon") ?><span<?php echo $_MPP_List_summary->Branch->viewAttributes() ?>><?php echo $_MPP_List_summary->Branch->GroupViewValue ?></span>
		<span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($_MPP_List_summary->Branch->Count, 0); ?></span>)</span>
		</td>
	</tr>
<?php } ?>
<?php
	$_MPP_List_summary->Status->getDistinctValues($_MPP_List_summary->Branch->Records);
	$_MPP_List_summary->setGroupCount(count($_MPP_List_summary->Status->DistinctValues), $_MPP_List_summary->GroupCounter[1], $_MPP_List_summary->GroupCounter[2], $_MPP_List_summary->GroupCounter[3], $_MPP_List_summary->GroupCounter[4]);
	$_MPP_List_summary->GroupCounter[5] = 0; // Init group count index
	foreach ($_MPP_List_summary->Status->DistinctValues as $Status) { // Load records for this distinct value
		$_MPP_List_summary->Status->setGroupValue($Status); // Set group value
		$_MPP_List_summary->Status->getDistinctRecords($_MPP_List_summary->Branch->Records, $_MPP_List_summary->Status->groupValue());
		$_MPP_List_summary->Status->LevelBreak = TRUE; // Set field level break
		$_MPP_List_summary->GroupCounter[5]++;
		$_MPP_List_summary->Status->getCnt($_MPP_List_summary->Status->Records); // Get record count
?>
<?php if ($_MPP_List_summary->Status->Visible && $_MPP_List_summary->Status->ShowGroupHeaderAsRow) { ?>
<?php

		// Render header row
		$_MPP_List_summary->Status->setDbValue($Status); // Set current value for Status
		$_MPP_List_summary->resetAttributes();
		$_MPP_List_summary->RowType = ROWTYPE_TOTAL;
		$_MPP_List_summary->RowTotalType = ROWTOTAL_GROUP;
		$_MPP_List_summary->RowTotalSubType = ROWTOTAL_HEADER;
		$_MPP_List_summary->RowGroupLevel = 5;
		$_MPP_List_summary->renderRow();
?>
	<tr<?php echo $_MPP_List_summary->rowAttributes(); ?>>
<?php if ($_MPP_List_summary->Period->Visible) { ?>
		<td data-field="Period"<?php echo $_MPP_List_summary->Period->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($_MPP_List_summary->Position->Visible) { ?>
		<td data-field="Position"<?php echo $_MPP_List_summary->Position->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($_MPP_List_summary->Location->Visible) { ?>
		<td data-field="Location"<?php echo $_MPP_List_summary->Location->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($_MPP_List_summary->Branch->Visible) { ?>
		<td data-field="Branch"<?php echo $_MPP_List_summary->Branch->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($_MPP_List_summary->Status->Visible) { ?>
		<td data-field="Status"<?php echo $_MPP_List_summary->Status->cellAttributes(); ?>><span class="ew-group-toggle icon-collapse"></span></td>
<?php } ?>
		<td data-field="Status" colspan="<?php echo ($Page->GroupColumnCount + $Page->DetailColumnCount - 5) ?>"<?php echo $_MPP_List_summary->Status->cellAttributes() ?>>
<?php if ($_MPP_List_summary->sortUrl($_MPP_List_summary->Status) == "") { ?>
		<span class="ew-summary-caption _MPP_List_Status"><span class="ew-table-header-caption"><?php echo $_MPP_List_summary->Status->caption() ?></span></span>
<?php } else { ?>
		<span class="ew-table-header-btn ew-pointer ew-summary-caption _MPP_List_Status" onclick="ew.sort(event, '<?php echo $_MPP_List_summary->sortUrl($_MPP_List_summary->Status) ?>', 1);">
			<span class="ew-table-header-caption"><?php echo $_MPP_List_summary->Status->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($_MPP_List_summary->Status->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($_MPP_List_summary->Status->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span>
		</span>
<?php } ?>
		<?php echo $Language->phrase("SummaryColon") ?><span<?php echo $_MPP_List_summary->Status->viewAttributes() ?>><?php echo $_MPP_List_summary->Status->GroupViewValue ?></span>
		<span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($_MPP_List_summary->Status->Count, 0); ?></span>)</span>
		</td>
	</tr>
<?php } ?>
<?php
	$_MPP_List_summary->Group->getDistinctValues($_MPP_List_summary->Status->Records);
	$_MPP_List_summary->setGroupCount(count($_MPP_List_summary->Group->DistinctValues), $_MPP_List_summary->GroupCounter[1], $_MPP_List_summary->GroupCounter[2], $_MPP_List_summary->GroupCounter[3], $_MPP_List_summary->GroupCounter[4], $_MPP_List_summary->GroupCounter[5]);
	$_MPP_List_summary->GroupCounter[6] = 0; // Init group count index
	foreach ($_MPP_List_summary->Group->DistinctValues as $Group) { // Load records for this distinct value
		$_MPP_List_summary->Group->setGroupValue($Group); // Set group value
		$_MPP_List_summary->Group->getDistinctRecords($_MPP_List_summary->Status->Records, $_MPP_List_summary->Group->groupValue());
		$_MPP_List_summary->Group->LevelBreak = TRUE; // Set field level break
		$_MPP_List_summary->GroupCounter[6]++;
		$_MPP_List_summary->Group->getCnt($_MPP_List_summary->Group->Records); // Get record count
		$_MPP_List_summary->setGroupCount($_MPP_List_summary->Group->Count, $_MPP_List_summary->GroupCounter[1], $_MPP_List_summary->GroupCounter[2], $_MPP_List_summary->GroupCounter[3], $_MPP_List_summary->GroupCounter[4], $_MPP_List_summary->GroupCounter[5], $_MPP_List_summary->GroupCounter[6]);
?>
<?php if ($_MPP_List_summary->Group->Visible && $_MPP_List_summary->Group->ShowGroupHeaderAsRow) { ?>
<?php

		// Render header row
		$_MPP_List_summary->Group->setDbValue($Group); // Set current value for Group
		$_MPP_List_summary->resetAttributes();
		$_MPP_List_summary->RowType = ROWTYPE_TOTAL;
		$_MPP_List_summary->RowTotalType = ROWTOTAL_GROUP;
		$_MPP_List_summary->RowTotalSubType = ROWTOTAL_HEADER;
		$_MPP_List_summary->RowGroupLevel = 6;
		$_MPP_List_summary->renderRow();
?>
	<tr<?php echo $_MPP_List_summary->rowAttributes(); ?>>
<?php if ($_MPP_List_summary->Period->Visible) { ?>
		<td data-field="Period"<?php echo $_MPP_List_summary->Period->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($_MPP_List_summary->Position->Visible) { ?>
		<td data-field="Position"<?php echo $_MPP_List_summary->Position->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($_MPP_List_summary->Location->Visible) { ?>
		<td data-field="Location"<?php echo $_MPP_List_summary->Location->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($_MPP_List_summary->Branch->Visible) { ?>
		<td data-field="Branch"<?php echo $_MPP_List_summary->Branch->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($_MPP_List_summary->Status->Visible) { ?>
		<td data-field="Status"<?php echo $_MPP_List_summary->Status->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($_MPP_List_summary->Group->Visible) { ?>
		<td data-field="Group"<?php echo $_MPP_List_summary->Group->cellAttributes(); ?>><span class="ew-group-toggle icon-collapse"></span></td>
<?php } ?>
		<td data-field="Group" colspan="<?php echo ($Page->GroupColumnCount + $Page->DetailColumnCount - 6) ?>"<?php echo $_MPP_List_summary->Group->cellAttributes() ?>>
<?php if ($_MPP_List_summary->sortUrl($_MPP_List_summary->Group) == "") { ?>
		<span class="ew-summary-caption _MPP_List_Group"><span class="ew-table-header-caption"><?php echo $_MPP_List_summary->Group->caption() ?></span></span>
<?php } else { ?>
		<span class="ew-table-header-btn ew-pointer ew-summary-caption _MPP_List_Group" onclick="ew.sort(event, '<?php echo $_MPP_List_summary->sortUrl($_MPP_List_summary->Group) ?>', 1);">
			<span class="ew-table-header-caption"><?php echo $_MPP_List_summary->Group->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($_MPP_List_summary->Group->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($_MPP_List_summary->Group->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span>
		</span>
<?php } ?>
		<?php echo $Language->phrase("SummaryColon") ?><span<?php echo $_MPP_List_summary->Group->viewAttributes() ?>><?php echo $_MPP_List_summary->Group->GroupViewValue ?></span>
		<span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($_MPP_List_summary->Group->Count, 0); ?></span>)</span>
		</td>
	</tr>
<?php } ?>
<?php
	$_MPP_List_summary->RecordCount = 0; // Reset record count
	foreach ($_MPP_List_summary->Group->Records as $record) {
		$_MPP_List_summary->RecordCount++;
		$_MPP_List_summary->RecordIndex++;
		$_MPP_List_summary->loadRowValues($record);
?>
<?php

		// Render detail row
		$_MPP_List_summary->resetAttributes();
		$_MPP_List_summary->RowType = ROWTYPE_DETAIL;
		$_MPP_List_summary->renderRow();
?>
	<tr<?php echo $_MPP_List_summary->rowAttributes(); ?>>
<?php if ($_MPP_List_summary->Period->Visible) { ?>
	<?php if ($_MPP_List_summary->Period->ShowGroupHeaderAsRow) { ?>
		<td data-field="Period"<?php echo $_MPP_List_summary->Period->cellAttributes(); ?>>&nbsp;</td>
	<?php } else { ?>
		<td data-field="Period"<?php echo $_MPP_List_summary->Period->cellAttributes(); ?>><span<?php echo $_MPP_List_summary->Period->viewAttributes() ?>><?php echo $_MPP_List_summary->Period->GroupViewValue ?></span></td>
	<?php } ?>
<?php } ?>
<?php if ($_MPP_List_summary->Position->Visible) { ?>
	<?php if ($_MPP_List_summary->Position->ShowGroupHeaderAsRow) { ?>
		<td data-field="Position"<?php echo $_MPP_List_summary->Position->cellAttributes(); ?>>&nbsp;</td>
	<?php } else { ?>
		<td data-field="Position"<?php echo $_MPP_List_summary->Position->cellAttributes(); ?>><span<?php echo $_MPP_List_summary->Position->viewAttributes() ?>><?php echo $_MPP_List_summary->Position->GroupViewValue ?></span></td>
	<?php } ?>
<?php } ?>
<?php if ($_MPP_List_summary->Location->Visible) { ?>
	<?php if ($_MPP_List_summary->Location->ShowGroupHeaderAsRow) { ?>
		<td data-field="Location"<?php echo $_MPP_List_summary->Location->cellAttributes(); ?>>&nbsp;</td>
	<?php } else { ?>
		<td data-field="Location"<?php echo $_MPP_List_summary->Location->cellAttributes(); ?>><span<?php echo $_MPP_List_summary->Location->viewAttributes() ?>><?php echo $_MPP_List_summary->Location->GroupViewValue ?></span></td>
	<?php } ?>
<?php } ?>
<?php if ($_MPP_List_summary->Branch->Visible) { ?>
	<?php if ($_MPP_List_summary->Branch->ShowGroupHeaderAsRow) { ?>
		<td data-field="Branch"<?php echo $_MPP_List_summary->Branch->cellAttributes(); ?>>&nbsp;</td>
	<?php } else { ?>
		<td data-field="Branch"<?php echo $_MPP_List_summary->Branch->cellAttributes(); ?>><span<?php echo $_MPP_List_summary->Branch->viewAttributes() ?>><?php echo $_MPP_List_summary->Branch->GroupViewValue ?></span></td>
	<?php } ?>
<?php } ?>
<?php if ($_MPP_List_summary->Status->Visible) { ?>
	<?php if ($_MPP_List_summary->Status->ShowGroupHeaderAsRow) { ?>
		<td data-field="Status"<?php echo $_MPP_List_summary->Status->cellAttributes(); ?>>&nbsp;</td>
	<?php } else { ?>
		<td data-field="Status"<?php echo $_MPP_List_summary->Status->cellAttributes(); ?>><span<?php echo $_MPP_List_summary->Status->viewAttributes() ?>><?php echo $_MPP_List_summary->Status->GroupViewValue ?></span></td>
	<?php } ?>
<?php } ?>
<?php if ($_MPP_List_summary->Group->Visible) { ?>
	<?php if ($_MPP_List_summary->Group->ShowGroupHeaderAsRow) { ?>
		<td data-field="Group"<?php echo $_MPP_List_summary->Group->cellAttributes(); ?>>&nbsp;</td>
	<?php } else { ?>
		<td data-field="Group"<?php echo $_MPP_List_summary->Group->cellAttributes(); ?>><span<?php echo $_MPP_List_summary->Group->viewAttributes() ?>><?php echo $_MPP_List_summary->Group->GroupViewValue ?></span></td>
	<?php } ?>
<?php } ?>
<?php if ($_MPP_List_summary->Division->Visible) { ?>
		<td data-field="Division"<?php echo $_MPP_List_summary->Division->cellAttributes() ?>>
<span<?php echo $_MPP_List_summary->Division->viewAttributes() ?>><?php echo $_MPP_List_summary->Division->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($_MPP_List_summary->Sum28mpp_Amount29->Visible) { ?>
		<td data-field="Sum28mpp_Amount29"<?php echo $_MPP_List_summary->Sum28mpp_Amount29->cellAttributes() ?>>
<span<?php echo $_MPP_List_summary->Sum28mpp_Amount29->viewAttributes() ?>><?php echo $_MPP_List_summary->Sum28mpp_Amount29->getViewValue() ?></span>
</td>
<?php } ?>
	</tr>
<?php
	}
	} // End group level 5
	} // End group level 4
	} // End group level 3
	} // End group level 2
	} // End group level 1
?>
<?php

	// Next group
	$_MPP_List_summary->loadGroupRowValues();

	// Show header if page break
	if ($_MPP_List_summary->isExport())
		$_MPP_List_summary->ShowHeader = ($_MPP_List_summary->ExportPageBreakCount == 0) ? FALSE : ($_MPP_List_summary->GroupCount % $_MPP_List_summary->ExportPageBreakCount == 0);

	// Page_Breaking server event
	if ($_MPP_List_summary->ShowHeader)
		$_MPP_List_summary->Page_Breaking($_MPP_List_summary->ShowHeader, $_MPP_List_summary->PageBreakContent);
	$_MPP_List_summary->GroupCount++;
} // End while
?>
<?php if ($_MPP_List_summary->TotalGroups > 0) { ?>
</tbody>
<tfoot>
<?php if (($_MPP_List_summary->StopGroup - $_MPP_List_summary->StartGroup + 1) != $_MPP_List_summary->TotalGroups) { ?>
<?php
	$_MPP_List_summary->resetAttributes();
	$_MPP_List_summary->RowType = ROWTYPE_TOTAL;
	$_MPP_List_summary->RowTotalType = ROWTOTAL_PAGE;
	$_MPP_List_summary->RowTotalSubType = ROWTOTAL_FOOTER;
	$_MPP_List_summary->RowAttrs["class"] = "ew-rpt-page-summary";
	$_MPP_List_summary->renderRow();
?>
<?php if ($_MPP_List_summary->Period->ShowCompactSummaryFooter) { ?>
	<tr<?php echo $_MPP_List_summary->rowAttributes(); ?>><td colspan="<?php echo ($_MPP_List_summary->GroupColumnCount + $_MPP_List_summary->DetailColumnCount) ?>"><?php echo $Language->phrase("RptPageSummary") ?> <span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($_MPP_List_summary->PageTotalCount, 0); ?></span>)</span></td></tr>
	<tr<?php echo $_MPP_List_summary->rowAttributes(); ?>>
<?php if ($_MPP_List_summary->GroupColumnCount > 0) { ?>
		<td colspan="<?php echo $_MPP_List_summary->GroupColumnCount ?>" class="ew-rpt-grp-aggregate">&nbsp;</td>
<?php } ?>
<?php if ($_MPP_List_summary->Division->Visible) { ?>
		<td data-field="Division"<?php echo $_MPP_List_summary->Division->cellAttributes() ?>></td>
<?php } ?>
<?php if ($_MPP_List_summary->Sum28mpp_Amount29->Visible) { ?>
		<td data-field="Sum28mpp_Amount29"<?php echo $_MPP_List_summary->Sum28mpp_Amount29->cellAttributes() ?>><span class="ew-aggregate-caption"><?php echo $Language->phrase("RptSum") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><span<?php echo $_MPP_List_summary->Sum28mpp_Amount29->viewAttributes() ?>><?php echo $_MPP_List_summary->Sum28mpp_Amount29->SumViewValue ?></span></span></td>
<?php } ?>
	</tr>
<?php } else { ?>
	<tr<?php echo $_MPP_List_summary->rowAttributes(); ?>><td colspan="<?php echo ($_MPP_List_summary->GroupColumnCount + $_MPP_List_summary->DetailColumnCount) ?>"><?php echo $Language->phrase("RptPageSummary") ?> <span class="ew-summary-count">(<?php echo FormatNumber($_MPP_List_summary->PageTotalCount, 0); ?><?php echo $Language->phrase("RptDtlRec") ?>)</span></td></tr>
	<tr<?php echo $_MPP_List_summary->rowAttributes(); ?>>
<?php if ($_MPP_List_summary->GroupColumnCount > 0) { ?>
		<td colspan="<?php echo $_MPP_List_summary->GroupColumnCount ?>" class="ew-rpt-grp-aggregate"><?php echo $Language->phrase("RptSum") ?></td>
<?php } ?>
<?php if ($_MPP_List_summary->Division->Visible) { ?>
		<td data-field="Division"<?php echo $_MPP_List_summary->Division->cellAttributes() ?>>&nbsp;</td>
<?php } ?>
<?php if ($_MPP_List_summary->Sum28mpp_Amount29->Visible) { ?>
		<td data-field="Sum28mpp_Amount29"<?php echo $_MPP_List_summary->Sum28mpp_Amount29->cellAttributes() ?>>
<span<?php echo $_MPP_List_summary->Sum28mpp_Amount29->viewAttributes() ?>><?php echo $_MPP_List_summary->Sum28mpp_Amount29->SumViewValue ?></span>
</td>
<?php } ?>
	</tr>
<?php } ?>
<?php } ?>
<?php
	$_MPP_List_summary->resetAttributes();
	$_MPP_List_summary->RowType = ROWTYPE_TOTAL;
	$_MPP_List_summary->RowTotalType = ROWTOTAL_GRAND;
	$_MPP_List_summary->RowTotalSubType = ROWTOTAL_FOOTER;
	$_MPP_List_summary->RowAttrs["class"] = "ew-rpt-grand-summary";
	$_MPP_List_summary->renderRow();
?>
<?php if ($_MPP_List_summary->Period->ShowCompactSummaryFooter) { ?>
	<tr<?php echo $_MPP_List_summary->rowAttributes() ?>><td colspan="<?php echo ($_MPP_List_summary->GroupColumnCount + $_MPP_List_summary->DetailColumnCount) ?>"><?php echo $Language->phrase("RptGrandSummary") ?> <span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($_MPP_List_summary->TotalCount, 0); ?></span>)</span></td></tr>
	<tr<?php echo $_MPP_List_summary->rowAttributes() ?>>
<?php if ($_MPP_List_summary->GroupColumnCount > 0) { ?>
		<td colspan="<?php echo $_MPP_List_summary->GroupColumnCount ?>" class="ew-rpt-grp-aggregate">&nbsp;</td>
<?php } ?>
<?php if ($_MPP_List_summary->Division->Visible) { ?>
		<td data-field="Division"<?php echo $_MPP_List_summary->Division->cellAttributes() ?>></td>
<?php } ?>
<?php if ($_MPP_List_summary->Sum28mpp_Amount29->Visible) { ?>
		<td data-field="Sum28mpp_Amount29"<?php echo $_MPP_List_summary->Sum28mpp_Amount29->cellAttributes() ?>><span class="ew-aggregate-caption"><?php echo $Language->phrase("RptSum") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><span<?php echo $_MPP_List_summary->Sum28mpp_Amount29->viewAttributes() ?>><?php echo $_MPP_List_summary->Sum28mpp_Amount29->SumViewValue ?></span></span></td>
<?php } ?>
	</tr>
<?php } else { ?>
	<tr<?php echo $_MPP_List_summary->rowAttributes() ?>><td colspan="<?php echo ($_MPP_List_summary->GroupColumnCount + $_MPP_List_summary->DetailColumnCount) ?>"><?php echo $Language->phrase("RptGrandSummary") ?> <span class="ew-summary-count">(<?php echo FormatNumber($_MPP_List_summary->TotalCount, 0); ?><?php echo $Language->phrase("RptDtlRec") ?>)</span></td></tr>
	<tr<?php echo $_MPP_List_summary->rowAttributes() ?>>
<?php if ($_MPP_List_summary->GroupColumnCount > 0) { ?>
		<td colspan="<?php echo $_MPP_List_summary->GroupColumnCount ?>" class="ew-rpt-grp-aggregate"><?php echo $Language->phrase("RptSum") ?></td>
<?php } ?>
<?php if ($_MPP_List_summary->Division->Visible) { ?>
		<td data-field="Division"<?php echo $_MPP_List_summary->Division->cellAttributes() ?>>&nbsp;</td>
<?php } ?>
<?php if ($_MPP_List_summary->Sum28mpp_Amount29->Visible) { ?>
		<td data-field="Sum28mpp_Amount29"<?php echo $_MPP_List_summary->Sum28mpp_Amount29->cellAttributes() ?>>
<span<?php echo $_MPP_List_summary->Sum28mpp_Amount29->viewAttributes() ?>><?php echo $_MPP_List_summary->Sum28mpp_Amount29->SumViewValue ?></span>
</td>
<?php } ?>
	</tr>
<?php } ?>
</tfoot>
</table>
</div>
<!-- /.ew-grid-middle-panel -->
<!-- Report grid (end) -->
<?php if ($_MPP_List_summary->TotalGroups > 0) { ?>
<?php if (!$_MPP_List_summary->isExport() && !($_MPP_List_summary->DrillDown && $_MPP_List_summary->TotalGroups > 0)) { ?>
<!-- Bottom pager -->
<div class="card-footer ew-grid-lower-panel">
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $_MPP_List_summary->Pager->render() ?>
</form>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php } ?>
</div>
<!-- /.ew-grid -->
<?php } ?>
</div>
<!-- /#report-summary -->
<!-- Summary report (end) -->
<?php if ((!$_MPP_List_summary->isExport() || $_MPP_List_summary->isExport("print")) && !$DashboardReport) { ?>
</div>
<!-- /#ew-center -->
<?php } ?>
<?php if ((!$_MPP_List_summary->isExport() || $_MPP_List_summary->isExport("print")) && !$DashboardReport) { ?>
</div>
<!-- /.row -->
<?php } ?>
<?php if ((!$_MPP_List_summary->isExport() || $_MPP_List_summary->isExport("print")) && !$DashboardReport) { ?>
</div>
<!-- /.ew-report -->
<?php } ?>
<?php
$_MPP_List_summary->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$_MPP_List_summary->isExport() && !$_MPP_List_summary->DrillDown && !$DashboardReport) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php if (!$DashboardReport) { ?>
<?php include_once "footer.php"; ?>
<?php } ?>
<?php
$_MPP_List_summary->terminate();
?>