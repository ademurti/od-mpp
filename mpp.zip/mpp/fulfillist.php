<?php
namespace PHPMaker2020\mpp;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$fulfil_list = new fulfil_list();

// Run the page
$fulfil_list->run();

// Setup login status
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$fulfil_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$fulfil_list->isExport()) { ?>
<script>
var ffulfillist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	ffulfillist = currentForm = new ew.Form("ffulfillist", "list");
	ffulfillist.formKeyCountName = '<?php echo $fulfil_list->FormKeyCountName ?>';
	loadjs.done("ffulfillist");
});
var ffulfillistsrch;
loadjs.ready("head", function() {

	// Form object for search
	ffulfillistsrch = currentSearchForm = new ew.Form("ffulfillistsrch");

	// Dynamic selection lists
	// Filters

	ffulfillistsrch.filterList = <?php echo $fulfil_list->getFilterList() ?>;
	loadjs.done("ffulfillistsrch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$fulfil_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($fulfil_list->TotalRecords > 0 && $fulfil_list->ExportOptions->visible()) { ?>
<?php $fulfil_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($fulfil_list->ImportOptions->visible()) { ?>
<?php $fulfil_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($fulfil_list->SearchOptions->visible()) { ?>
<?php $fulfil_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($fulfil_list->FilterOptions->visible()) { ?>
<?php $fulfil_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$fulfil_list->renderOtherOptions();
?>
<?php if (!$fulfil_list->isExport() && !$fulfil->CurrentAction) { ?>
<form name="ffulfillistsrch" id="ffulfillistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="ffulfillistsrch-search-panel" class="<?php echo $fulfil_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="fulfil">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $fulfil_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($fulfil_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($fulfil_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $fulfil_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($fulfil_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($fulfil_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($fulfil_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($fulfil_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php $fulfil_list->showPageHeader(); ?>
<?php
$fulfil_list->showMessage();
?>
<?php if ($fulfil_list->TotalRecords > 0 || $fulfil->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($fulfil_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> fulfil">
<?php if (!$fulfil_list->isExport()) { ?>
<div class="card-header ew-grid-upper-panel">
<?php if (!$fulfil_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $fulfil_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $fulfil_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
<form name="ffulfillist" id="ffulfillist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="fulfil">
<div id="gmp_fulfil" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($fulfil_list->TotalRecords > 0 || $fulfil_list->isGridEdit()) { ?>
<table id="tbl_fulfillist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$fulfil->RowType = ROWTYPE_HEADER;

// Render list options
$fulfil_list->renderListOptions();

// Render list options (header, left)
$fulfil_list->ListOptions->render("header", "left");
?>
<?php if ($fulfil_list->Position->Visible) { // Position ?>
	<?php if ($fulfil_list->SortUrl($fulfil_list->Position) == "") { ?>
		<th data-name="Position" class="<?php echo $fulfil_list->Position->headerCellClass() ?>"><div id="elh_fulfil_Position" class="fulfil_Position"><div class="ew-table-header-caption"><?php echo $fulfil_list->Position->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Position" class="<?php echo $fulfil_list->Position->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $fulfil_list->SortUrl($fulfil_list->Position) ?>', 1);"><div id="elh_fulfil_Position" class="fulfil_Position">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $fulfil_list->Position->caption() ?></span><span class="ew-table-header-sort"><?php if ($fulfil_list->Position->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($fulfil_list->Position->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($fulfil_list->Branch->Visible) { // Branch ?>
	<?php if ($fulfil_list->SortUrl($fulfil_list->Branch) == "") { ?>
		<th data-name="Branch" class="<?php echo $fulfil_list->Branch->headerCellClass() ?>"><div id="elh_fulfil_Branch" class="fulfil_Branch"><div class="ew-table-header-caption"><?php echo $fulfil_list->Branch->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Branch" class="<?php echo $fulfil_list->Branch->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $fulfil_list->SortUrl($fulfil_list->Branch) ?>', 1);"><div id="elh_fulfil_Branch" class="fulfil_Branch">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $fulfil_list->Branch->caption() ?></span><span class="ew-table-header-sort"><?php if ($fulfil_list->Branch->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($fulfil_list->Branch->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($fulfil_list->Status->Visible) { // Status ?>
	<?php if ($fulfil_list->SortUrl($fulfil_list->Status) == "") { ?>
		<th data-name="Status" class="<?php echo $fulfil_list->Status->headerCellClass() ?>"><div id="elh_fulfil_Status" class="fulfil_Status"><div class="ew-table-header-caption"><?php echo $fulfil_list->Status->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Status" class="<?php echo $fulfil_list->Status->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $fulfil_list->SortUrl($fulfil_list->Status) ?>', 1);"><div id="elh_fulfil_Status" class="fulfil_Status">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $fulfil_list->Status->caption() ?></span><span class="ew-table-header-sort"><?php if ($fulfil_list->Status->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($fulfil_list->Status->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($fulfil_list->MPP->Visible) { // MPP ?>
	<?php if ($fulfil_list->SortUrl($fulfil_list->MPP) == "") { ?>
		<th data-name="MPP" class="<?php echo $fulfil_list->MPP->headerCellClass() ?>"><div id="elh_fulfil_MPP" class="fulfil_MPP"><div class="ew-table-header-caption"><?php echo $fulfil_list->MPP->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="MPP" class="<?php echo $fulfil_list->MPP->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $fulfil_list->SortUrl($fulfil_list->MPP) ?>', 1);"><div id="elh_fulfil_MPP" class="fulfil_MPP">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $fulfil_list->MPP->caption() ?></span><span class="ew-table-header-sort"><?php if ($fulfil_list->MPP->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($fulfil_list->MPP->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($fulfil_list->Current->Visible) { // Current ?>
	<?php if ($fulfil_list->SortUrl($fulfil_list->Current) == "") { ?>
		<th data-name="Current" class="<?php echo $fulfil_list->Current->headerCellClass() ?>"><div id="elh_fulfil_Current" class="fulfil_Current"><div class="ew-table-header-caption"><?php echo $fulfil_list->Current->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Current" class="<?php echo $fulfil_list->Current->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $fulfil_list->SortUrl($fulfil_list->Current) ?>', 1);"><div id="elh_fulfil_Current" class="fulfil_Current">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $fulfil_list->Current->caption() ?></span><span class="ew-table-header-sort"><?php if ($fulfil_list->Current->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($fulfil_list->Current->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($fulfil_list->Lack->Visible) { // Lack ?>
	<?php if ($fulfil_list->SortUrl($fulfil_list->Lack) == "") { ?>
		<th data-name="Lack" class="<?php echo $fulfil_list->Lack->headerCellClass() ?>"><div id="elh_fulfil_Lack" class="fulfil_Lack"><div class="ew-table-header-caption"><?php echo $fulfil_list->Lack->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Lack" class="<?php echo $fulfil_list->Lack->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $fulfil_list->SortUrl($fulfil_list->Lack) ?>', 1);"><div id="elh_fulfil_Lack" class="fulfil_Lack">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $fulfil_list->Lack->caption() ?></span><span class="ew-table-header-sort"><?php if ($fulfil_list->Lack->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($fulfil_list->Lack->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$fulfil_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($fulfil_list->ExportAll && $fulfil_list->isExport()) {
	$fulfil_list->StopRecord = $fulfil_list->TotalRecords;
} else {

	// Set the last record to display
	if ($fulfil_list->TotalRecords > $fulfil_list->StartRecord + $fulfil_list->DisplayRecords - 1)
		$fulfil_list->StopRecord = $fulfil_list->StartRecord + $fulfil_list->DisplayRecords - 1;
	else
		$fulfil_list->StopRecord = $fulfil_list->TotalRecords;
}
$fulfil_list->RecordCount = $fulfil_list->StartRecord - 1;
if ($fulfil_list->Recordset && !$fulfil_list->Recordset->EOF) {
	$fulfil_list->Recordset->moveFirst();
	$selectLimit = $fulfil_list->UseSelectLimit;
	if (!$selectLimit && $fulfil_list->StartRecord > 1)
		$fulfil_list->Recordset->move($fulfil_list->StartRecord - 1);
} elseif (!$fulfil->AllowAddDeleteRow && $fulfil_list->StopRecord == 0) {
	$fulfil_list->StopRecord = $fulfil->GridAddRowCount;
}

// Initialize aggregate
$fulfil->RowType = ROWTYPE_AGGREGATEINIT;
$fulfil->resetAttributes();
$fulfil_list->renderRow();
while ($fulfil_list->RecordCount < $fulfil_list->StopRecord) {
	$fulfil_list->RecordCount++;
	if ($fulfil_list->RecordCount >= $fulfil_list->StartRecord) {
		$fulfil_list->RowCount++;

		// Set up key count
		$fulfil_list->KeyCount = $fulfil_list->RowIndex;

		// Init row class and style
		$fulfil->resetAttributes();
		$fulfil->CssClass = "";
		if ($fulfil_list->isGridAdd()) {
		} else {
			$fulfil_list->loadRowValues($fulfil_list->Recordset); // Load row values
		}
		$fulfil->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$fulfil->RowAttrs->merge(["data-rowindex" => $fulfil_list->RowCount, "id" => "r" . $fulfil_list->RowCount . "_fulfil", "data-rowtype" => $fulfil->RowType]);

		// Render row
		$fulfil_list->renderRow();

		// Render list options
		$fulfil_list->renderListOptions();
?>
	<tr <?php echo $fulfil->rowAttributes() ?>>
<?php

// Render list options (body, left)
$fulfil_list->ListOptions->render("body", "left", $fulfil_list->RowCount);
?>
	<?php if ($fulfil_list->Position->Visible) { // Position ?>
		<td data-name="Position" <?php echo $fulfil_list->Position->cellAttributes() ?>>
<span id="el<?php echo $fulfil_list->RowCount ?>_fulfil_Position">
<span<?php echo $fulfil_list->Position->viewAttributes() ?>><?php echo $fulfil_list->Position->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($fulfil_list->Branch->Visible) { // Branch ?>
		<td data-name="Branch" <?php echo $fulfil_list->Branch->cellAttributes() ?>>
<span id="el<?php echo $fulfil_list->RowCount ?>_fulfil_Branch">
<span<?php echo $fulfil_list->Branch->viewAttributes() ?>><?php echo $fulfil_list->Branch->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($fulfil_list->Status->Visible) { // Status ?>
		<td data-name="Status" <?php echo $fulfil_list->Status->cellAttributes() ?>>
<span id="el<?php echo $fulfil_list->RowCount ?>_fulfil_Status">
<span<?php echo $fulfil_list->Status->viewAttributes() ?>><?php echo $fulfil_list->Status->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($fulfil_list->MPP->Visible) { // MPP ?>
		<td data-name="MPP" <?php echo $fulfil_list->MPP->cellAttributes() ?>>
<span id="el<?php echo $fulfil_list->RowCount ?>_fulfil_MPP">
<span<?php echo $fulfil_list->MPP->viewAttributes() ?>><?php echo $fulfil_list->MPP->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($fulfil_list->Current->Visible) { // Current ?>
		<td data-name="Current" <?php echo $fulfil_list->Current->cellAttributes() ?>>
<span id="el<?php echo $fulfil_list->RowCount ?>_fulfil_Current">
<span<?php echo $fulfil_list->Current->viewAttributes() ?>><?php echo $fulfil_list->Current->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($fulfil_list->Lack->Visible) { // Lack ?>
		<td data-name="Lack" <?php echo $fulfil_list->Lack->cellAttributes() ?>>
<span id="el<?php echo $fulfil_list->RowCount ?>_fulfil_Lack">
<span<?php echo $fulfil_list->Lack->viewAttributes() ?>><?php echo $fulfil_list->Lack->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$fulfil_list->ListOptions->render("body", "right", $fulfil_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$fulfil_list->isGridAdd())
		$fulfil_list->Recordset->moveNext();
}
?>
</tbody>
<?php

// Render aggregate row
$fulfil->RowType = ROWTYPE_AGGREGATE;
$fulfil->resetAttributes();
$fulfil_list->renderRow();
?>
<?php if ($fulfil_list->TotalRecords > 0 && !$fulfil_list->isGridAdd() && !$fulfil_list->isGridEdit()) { ?>
<tfoot><!-- Table footer -->
	<tr class="ew-table-footer">
<?php

// Render list options
$fulfil_list->renderListOptions();

// Render list options (footer, left)
$fulfil_list->ListOptions->render("footer", "left");
?>
	<?php if ($fulfil_list->Position->Visible) { // Position ?>
		<td data-name="Position" class="<?php echo $fulfil_list->Position->footerCellClass() ?>"><span id="elf_fulfil_Position" class="fulfil_Position">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($fulfil_list->Branch->Visible) { // Branch ?>
		<td data-name="Branch" class="<?php echo $fulfil_list->Branch->footerCellClass() ?>"><span id="elf_fulfil_Branch" class="fulfil_Branch">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($fulfil_list->Status->Visible) { // Status ?>
		<td data-name="Status" class="<?php echo $fulfil_list->Status->footerCellClass() ?>"><span id="elf_fulfil_Status" class="fulfil_Status">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($fulfil_list->MPP->Visible) { // MPP ?>
		<td data-name="MPP" class="<?php echo $fulfil_list->MPP->footerCellClass() ?>"><span id="elf_fulfil_MPP" class="fulfil_MPP">
		<span class="ew-aggregate"><?php echo $Language->phrase("TOTAL") ?></span><span class="ew-aggregate-value">
		<?php echo $fulfil_list->MPP->ViewValue ?></span>
		</span></td>
	<?php } ?>
	<?php if ($fulfil_list->Current->Visible) { // Current ?>
		<td data-name="Current" class="<?php echo $fulfil_list->Current->footerCellClass() ?>"><span id="elf_fulfil_Current" class="fulfil_Current">
		<span class="ew-aggregate"><?php echo $Language->phrase("TOTAL") ?></span><span class="ew-aggregate-value">
		<?php echo $fulfil_list->Current->ViewValue ?></span>
		</span></td>
	<?php } ?>
	<?php if ($fulfil_list->Lack->Visible) { // Lack ?>
		<td data-name="Lack" class="<?php echo $fulfil_list->Lack->footerCellClass() ?>"><span id="elf_fulfil_Lack" class="fulfil_Lack">
		<span class="ew-aggregate"><?php echo $Language->phrase("TOTAL") ?></span><span class="ew-aggregate-value">
		<?php echo $fulfil_list->Lack->ViewValue ?></span>
		</span></td>
	<?php } ?>
<?php

// Render list options (footer, right)
$fulfil_list->ListOptions->render("footer", "right");
?>
	</tr>
</tfoot>
<?php } ?>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$fulfil->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($fulfil_list->Recordset)
	$fulfil_list->Recordset->Close();
?>
<?php if (!$fulfil_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$fulfil_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $fulfil_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $fulfil_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($fulfil_list->TotalRecords == 0 && !$fulfil->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $fulfil_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$fulfil_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$fulfil_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$fulfil_list->terminate();
?>