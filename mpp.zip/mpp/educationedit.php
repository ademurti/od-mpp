<?php
namespace PHPMaker2020\mpp;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$education_edit = new education_edit();

// Run the page
$education_edit->run();

// Setup login status
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$education_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var feducationedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	feducationedit = currentForm = new ew.Form("feducationedit", "edit");

	// Validate form
	feducationedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "F")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($education_edit->Education->Required) { ?>
				elm = this.getElements("x" + infix + "_Education");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $education_edit->Education->caption(), $education_edit->Education->RequiredErrorMessage)) ?>");
			<?php } ?>

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	feducationedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	feducationedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("feducationedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $education_edit->showPageHeader(); ?>
<?php
$education_edit->showMessage();
?>
<?php if (!$education_edit->IsModal) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $education_edit->Pager->render() ?>
<div class="clearfix"></div>
</form>
<?php } ?>
<form name="feducationedit" id="feducationedit" class="<?php echo $education_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="education">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$education_edit->IsModal ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($education_edit->Education->Visible) { // Education ?>
	<div id="r_Education" class="form-group row">
		<label id="elh_education_Education" for="x_Education" class="<?php echo $education_edit->LeftColumnClass ?>"><?php echo $education_edit->Education->caption() ?><?php echo $education_edit->Education->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $education_edit->RightColumnClass ?>"><div <?php echo $education_edit->Education->cellAttributes() ?>>
<span id="el_education_Education">
<input type="text" data-table="education" data-field="x_Education" name="x_Education" id="x_Education" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($education_edit->Education->getPlaceHolder()) ?>" value="<?php echo $education_edit->Education->EditValue ?>"<?php echo $education_edit->Education->editAttributes() ?>>
</span>
<?php echo $education_edit->Education->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
	<input type="hidden" data-table="education" data-field="x_eduID" name="x_eduID" id="x_eduID" value="<?php echo HtmlEncode($education_edit->eduID->CurrentValue) ?>">
<?php if (!$education_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $education_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $education_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
<?php if (!$education_edit->IsModal) { ?>
<?php echo $education_edit->Pager->render() ?>
<div class="clearfix"></div>
<?php } ?>
</form>
<?php
$education_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$education_edit->terminate();
?>