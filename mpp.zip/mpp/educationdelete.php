<?php
namespace PHPMaker2020\mpp;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$education_delete = new education_delete();

// Run the page
$education_delete->run();

// Setup login status
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$education_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var feducationdelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	feducationdelete = currentForm = new ew.Form("feducationdelete", "delete");
	loadjs.done("feducationdelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $education_delete->showPageHeader(); ?>
<?php
$education_delete->showMessage();
?>
<form name="feducationdelete" id="feducationdelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="education">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($education_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($education_delete->Education->Visible) { // Education ?>
		<th class="<?php echo $education_delete->Education->headerCellClass() ?>"><span id="elh_education_Education" class="education_Education"><?php echo $education_delete->Education->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$education_delete->RecordCount = 0;
$i = 0;
while (!$education_delete->Recordset->EOF) {
	$education_delete->RecordCount++;
	$education_delete->RowCount++;

	// Set row properties
	$education->resetAttributes();
	$education->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$education_delete->loadRowValues($education_delete->Recordset);

	// Render row
	$education_delete->renderRow();
?>
	<tr <?php echo $education->rowAttributes() ?>>
<?php if ($education_delete->Education->Visible) { // Education ?>
		<td <?php echo $education_delete->Education->cellAttributes() ?>>
<span id="el<?php echo $education_delete->RowCount ?>_education_Education" class="education_Education">
<span<?php echo $education_delete->Education->viewAttributes() ?>><?php echo $education_delete->Education->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$education_delete->Recordset->moveNext();
}
$education_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $education_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$education_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$education_delete->terminate();
?>