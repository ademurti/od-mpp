<?php
namespace PHPMaker2020\mpp;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$employee_add = new employee_add();

// Run the page
$employee_add->run();

// Setup login status
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$employee_add->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var femployeeadd, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "add";
	femployeeadd = currentForm = new ew.Form("femployeeadd", "add");

	// Validate form
	femployeeadd.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "F")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($employee_add->Location->Required) { ?>
				elm = this.getElements("x" + infix + "_Location");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $employee_add->Location->caption(), $employee_add->Location->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($employee_add->Branch->Required) { ?>
				elm = this.getElements("x" + infix + "_Branch");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $employee_add->Branch->caption(), $employee_add->Branch->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($employee_add->Position->Required) { ?>
				elm = this.getElements("x" + infix + "_Position");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $employee_add->Position->caption(), $employee_add->Position->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($employee_add->Status->Required) { ?>
				elm = this.getElements("x" + infix + "_Status");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $employee_add->Status->caption(), $employee_add->Status->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($employee_add->Name->Required) { ?>
				elm = this.getElements("x" + infix + "_Name");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $employee_add->Name->caption(), $employee_add->Name->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($employee_add->Education->Required) { ?>
				elm = this.getElements("x" + infix + "_Education");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $employee_add->Education->caption(), $employee_add->Education->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($employee_add->Join->Required) { ?>
				elm = this.getElements("x" + infix + "_Join");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $employee_add->Join->caption(), $employee_add->Join->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_Join");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($employee_add->Join->errorMessage()) ?>");
			<?php if ($employee_add->Resign->Required) { ?>
				elm = this.getElements("x" + infix + "_Resign");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $employee_add->Resign->caption(), $employee_add->Resign->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_Resign");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($employee_add->Resign->errorMessage()) ?>");
			<?php if ($employee_add->Product->Required) { ?>
				elm = this.getElements("x" + infix + "_Product[]");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $employee_add->Product->caption(), $employee_add->Product->RequiredErrorMessage)) ?>");
			<?php } ?>

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	femployeeadd.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	femployeeadd.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	femployeeadd.lists["x_Location"] = <?php echo $employee_add->Location->Lookup->toClientList($employee_add) ?>;
	femployeeadd.lists["x_Location"].options = <?php echo JsonEncode($employee_add->Location->lookupOptions()) ?>;
	femployeeadd.lists["x_Branch"] = <?php echo $employee_add->Branch->Lookup->toClientList($employee_add) ?>;
	femployeeadd.lists["x_Branch"].options = <?php echo JsonEncode($employee_add->Branch->lookupOptions()) ?>;
	femployeeadd.lists["x_Position"] = <?php echo $employee_add->Position->Lookup->toClientList($employee_add) ?>;
	femployeeadd.lists["x_Position"].options = <?php echo JsonEncode($employee_add->Position->lookupOptions()) ?>;
	femployeeadd.lists["x_Status"] = <?php echo $employee_add->Status->Lookup->toClientList($employee_add) ?>;
	femployeeadd.lists["x_Status"].options = <?php echo JsonEncode($employee_add->Status->lookupOptions()) ?>;
	femployeeadd.lists["x_Education"] = <?php echo $employee_add->Education->Lookup->toClientList($employee_add) ?>;
	femployeeadd.lists["x_Education"].options = <?php echo JsonEncode($employee_add->Education->lookupOptions()) ?>;
	femployeeadd.lists["x_Product[]"] = <?php echo $employee_add->Product->Lookup->toClientList($employee_add) ?>;
	femployeeadd.lists["x_Product[]"].options = <?php echo JsonEncode($employee_add->Product->lookupOptions()) ?>;
	loadjs.done("femployeeadd");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $employee_add->showPageHeader(); ?>
<?php
$employee_add->showMessage();
?>
<form name="femployeeadd" id="femployeeadd" class="<?php echo $employee_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="employee">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$employee_add->IsModal ?>">
<div class="ew-add-div"><!-- page* -->
<?php if ($employee_add->Location->Visible) { // Location ?>
	<div id="r_Location" class="form-group row">
		<label id="elh_employee_Location" for="x_Location" class="<?php echo $employee_add->LeftColumnClass ?>"><?php echo $employee_add->Location->caption() ?><?php echo $employee_add->Location->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $employee_add->RightColumnClass ?>"><div <?php echo $employee_add->Location->cellAttributes() ?>>
<span id="el_employee_Location">
<?php $employee_add->Location->EditAttrs->prepend("onchange", "ew.updateOptions.call(this);"); ?>
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="employee" data-field="x_Location" data-value-separator="<?php echo $employee_add->Location->displayValueSeparatorAttribute() ?>" id="x_Location" name="x_Location"<?php echo $employee_add->Location->editAttributes() ?>>
			<?php echo $employee_add->Location->selectOptionListHtml("x_Location") ?>
		</select>
	<div class="input-group-append"><button type="button" class="btn btn-default ew-add-opt-btn" id="aol_x_Location" title="<?php echo HtmlTitle($Language->phrase("AddLink")) . "&nbsp;" . $employee_add->Location->caption() ?>" data-title="<?php echo $employee_add->Location->caption() ?>" onclick="ew.addOptionDialogShow({lnk:this,el:'x_Location',url:'mppaddopt.php'});"><i class="fas fa-plus ew-icon"></i></button></div>
</div>
<?php echo $employee_add->Location->Lookup->getParamTag($employee_add, "p_x_Location") ?>
</span>
<?php echo $employee_add->Location->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($employee_add->Branch->Visible) { // Branch ?>
	<div id="r_Branch" class="form-group row">
		<label id="elh_employee_Branch" for="x_Branch" class="<?php echo $employee_add->LeftColumnClass ?>"><?php echo $employee_add->Branch->caption() ?><?php echo $employee_add->Branch->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $employee_add->RightColumnClass ?>"><div <?php echo $employee_add->Branch->cellAttributes() ?>>
<span id="el_employee_Branch">
<?php $employee_add->Branch->EditAttrs->prepend("onchange", "ew.updateOptions.call(this);"); ?>
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="employee" data-field="x_Branch" data-value-separator="<?php echo $employee_add->Branch->displayValueSeparatorAttribute() ?>" id="x_Branch" name="x_Branch"<?php echo $employee_add->Branch->editAttributes() ?>>
			<?php echo $employee_add->Branch->selectOptionListHtml("x_Branch") ?>
		</select>
</div>
<?php echo $employee_add->Branch->Lookup->getParamTag($employee_add, "p_x_Branch") ?>
</span>
<?php echo $employee_add->Branch->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($employee_add->Position->Visible) { // Position ?>
	<div id="r_Position" class="form-group row">
		<label id="elh_employee_Position" for="x_Position" class="<?php echo $employee_add->LeftColumnClass ?>"><?php echo $employee_add->Position->caption() ?><?php echo $employee_add->Position->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $employee_add->RightColumnClass ?>"><div <?php echo $employee_add->Position->cellAttributes() ?>>
<span id="el_employee_Position">
<?php $employee_add->Position->EditAttrs->prepend("onchange", "ew.updateOptions.call(this);"); ?>
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="employee" data-field="x_Position" data-value-separator="<?php echo $employee_add->Position->displayValueSeparatorAttribute() ?>" id="x_Position" name="x_Position"<?php echo $employee_add->Position->editAttributes() ?>>
			<?php echo $employee_add->Position->selectOptionListHtml("x_Position") ?>
		</select>
</div>
<?php echo $employee_add->Position->Lookup->getParamTag($employee_add, "p_x_Position") ?>
</span>
<?php echo $employee_add->Position->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($employee_add->Status->Visible) { // Status ?>
	<div id="r_Status" class="form-group row">
		<label id="elh_employee_Status" for="x_Status" class="<?php echo $employee_add->LeftColumnClass ?>"><?php echo $employee_add->Status->caption() ?><?php echo $employee_add->Status->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $employee_add->RightColumnClass ?>"><div <?php echo $employee_add->Status->cellAttributes() ?>>
<span id="el_employee_Status">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="employee" data-field="x_Status" data-value-separator="<?php echo $employee_add->Status->displayValueSeparatorAttribute() ?>" id="x_Status" name="x_Status"<?php echo $employee_add->Status->editAttributes() ?>>
			<?php echo $employee_add->Status->selectOptionListHtml("x_Status") ?>
		</select>
</div>
<?php echo $employee_add->Status->Lookup->getParamTag($employee_add, "p_x_Status") ?>
</span>
<?php echo $employee_add->Status->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($employee_add->Name->Visible) { // Name ?>
	<div id="r_Name" class="form-group row">
		<label id="elh_employee_Name" for="x_Name" class="<?php echo $employee_add->LeftColumnClass ?>"><?php echo $employee_add->Name->caption() ?><?php echo $employee_add->Name->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $employee_add->RightColumnClass ?>"><div <?php echo $employee_add->Name->cellAttributes() ?>>
<span id="el_employee_Name">
<input type="text" data-table="employee" data-field="x_Name" name="x_Name" id="x_Name" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($employee_add->Name->getPlaceHolder()) ?>" value="<?php echo $employee_add->Name->EditValue ?>"<?php echo $employee_add->Name->editAttributes() ?>>
</span>
<?php echo $employee_add->Name->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($employee_add->Education->Visible) { // Education ?>
	<div id="r_Education" class="form-group row">
		<label id="elh_employee_Education" class="<?php echo $employee_add->LeftColumnClass ?>"><?php echo $employee_add->Education->caption() ?><?php echo $employee_add->Education->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $employee_add->RightColumnClass ?>"><div <?php echo $employee_add->Education->cellAttributes() ?>>
<span id="el_employee_Education">
<div id="tp_x_Education" class="ew-template"><input type="radio" class="custom-control-input" data-table="employee" data-field="x_Education" data-value-separator="<?php echo $employee_add->Education->displayValueSeparatorAttribute() ?>" name="x_Education" id="x_Education" value="{value}"<?php echo $employee_add->Education->editAttributes() ?>></div>
<div id="dsl_x_Education" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $employee_add->Education->radioButtonListHtml(FALSE, "x_Education") ?>
</div></div>
<?php echo $employee_add->Education->Lookup->getParamTag($employee_add, "p_x_Education") ?>
</span>
<?php echo $employee_add->Education->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($employee_add->Join->Visible) { // Join ?>
	<div id="r_Join" class="form-group row">
		<label id="elh_employee_Join" for="x_Join" class="<?php echo $employee_add->LeftColumnClass ?>"><?php echo $employee_add->Join->caption() ?><?php echo $employee_add->Join->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $employee_add->RightColumnClass ?>"><div <?php echo $employee_add->Join->cellAttributes() ?>>
<span id="el_employee_Join">
<input type="text" data-table="employee" data-field="x_Join" name="x_Join" id="x_Join" maxlength="10" placeholder="<?php echo HtmlEncode($employee_add->Join->getPlaceHolder()) ?>" value="<?php echo $employee_add->Join->EditValue ?>"<?php echo $employee_add->Join->editAttributes() ?>>
<?php if (!$employee_add->Join->ReadOnly && !$employee_add->Join->Disabled && !isset($employee_add->Join->EditAttrs["readonly"]) && !isset($employee_add->Join->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["femployeeadd", "datetimepicker"], function() {
	ew.createDateTimePicker("femployeeadd", "x_Join", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $employee_add->Join->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($employee_add->Resign->Visible) { // Resign ?>
	<div id="r_Resign" class="form-group row">
		<label id="elh_employee_Resign" for="x_Resign" class="<?php echo $employee_add->LeftColumnClass ?>"><?php echo $employee_add->Resign->caption() ?><?php echo $employee_add->Resign->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $employee_add->RightColumnClass ?>"><div <?php echo $employee_add->Resign->cellAttributes() ?>>
<span id="el_employee_Resign">
<input type="text" data-table="employee" data-field="x_Resign" name="x_Resign" id="x_Resign" maxlength="10" placeholder="<?php echo HtmlEncode($employee_add->Resign->getPlaceHolder()) ?>" value="<?php echo $employee_add->Resign->EditValue ?>"<?php echo $employee_add->Resign->editAttributes() ?>>
<?php if (!$employee_add->Resign->ReadOnly && !$employee_add->Resign->Disabled && !isset($employee_add->Resign->EditAttrs["readonly"]) && !isset($employee_add->Resign->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["femployeeadd", "datetimepicker"], function() {
	ew.createDateTimePicker("femployeeadd", "x_Resign", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $employee_add->Resign->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($employee_add->Product->Visible) { // Product ?>
	<div id="r_Product" class="form-group row">
		<label id="elh_employee_Product" class="<?php echo $employee_add->LeftColumnClass ?>"><?php echo $employee_add->Product->caption() ?><?php echo $employee_add->Product->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $employee_add->RightColumnClass ?>"><div <?php echo $employee_add->Product->cellAttributes() ?>>
<span id="el_employee_Product">
<div id="tp_x_Product" class="ew-template"><input type="checkbox" class="custom-control-input" data-table="employee" data-field="x_Product" data-value-separator="<?php echo $employee_add->Product->displayValueSeparatorAttribute() ?>" name="x_Product[]" id="x_Product[]" value="{value}"<?php echo $employee_add->Product->editAttributes() ?>></div>
<div id="dsl_x_Product" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $employee_add->Product->checkBoxListHtml(FALSE, "x_Product[]") ?>
</div></div>
<?php echo $employee_add->Product->Lookup->getParamTag($employee_add, "p_x_Product") ?>
</span>
<?php echo $employee_add->Product->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$employee_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $employee_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $employee_add->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$employee_add->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$employee_add->terminate();
?>