<?php
namespace PHPMaker2020\mpp;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$Fulfilment_summary = new Fulfilment_summary();

// Run the page
$Fulfilment_summary->run();

// Setup login status
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$Fulfilment_summary->Page_Render();
?>
<?php if (!$DashboardReport) { ?>
<?php include_once "header.php"; ?>
<?php } ?>
<?php if (!$Fulfilment_summary->isExport() && !$Fulfilment_summary->DrillDown && !$DashboardReport) { ?>
<script>
var fsummary, currentPageID;
loadjs.ready("head", function() {

	// Form object for search
	fsummary = currentForm = new ew.Form("fsummary", "summary");
	currentPageID = ew.PAGE_ID = "summary";

	// Validate function for search
	fsummary.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fsummary.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fsummary.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fsummary.lists["x_Position"] = <?php echo $Fulfilment_summary->Position->Lookup->toClientList($Fulfilment_summary) ?>;
	fsummary.lists["x_Position"].options = <?php echo JsonEncode($Fulfilment_summary->Position->lookupOptions()) ?>;
	fsummary.lists["x_Branch"] = <?php echo $Fulfilment_summary->Branch->Lookup->toClientList($Fulfilment_summary) ?>;
	fsummary.lists["x_Branch"].options = <?php echo JsonEncode($Fulfilment_summary->Branch->lookupOptions()) ?>;
	fsummary.lists["x_Status[]"] = <?php echo $Fulfilment_summary->Status->Lookup->toClientList($Fulfilment_summary) ?>;
	fsummary.lists["x_Status[]"].options = <?php echo JsonEncode($Fulfilment_summary->Status->lookupOptions()) ?>;

	// Filters
	fsummary.filterList = <?php echo $Fulfilment_summary->getFilterList() ?>;
	loadjs.done("fsummary");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<a id="top"></a>
<?php if ((!$Fulfilment_summary->isExport() || $Fulfilment_summary->isExport("print")) && !$DashboardReport) { ?>
<!-- Content Container -->
<div id="ew-report" class="ew-report container-fluid">
<?php } ?>
<?php if ($Fulfilment_summary->ShowCurrentFilter) { ?>
<?php $Fulfilment_summary->showFilterList() ?>
<?php } ?>
<div class="btn-toolbar ew-toolbar">
<?php
if (!$Fulfilment_summary->DrillDownInPanel) {
	$Fulfilment_summary->ExportOptions->render("body");
	$Fulfilment_summary->SearchOptions->render("body");
	$Fulfilment_summary->FilterOptions->render("body");
}
?>
</div>
<?php $Fulfilment_summary->showPageHeader(); ?>
<?php
$Fulfilment_summary->showMessage();
?>
<?php if ((!$Fulfilment_summary->isExport() || $Fulfilment_summary->isExport("print")) && !$DashboardReport) { ?>
<div class="row">
<?php } ?>
<?php if ((!$Fulfilment_summary->isExport() || $Fulfilment_summary->isExport("print")) && !$DashboardReport) { ?>
<!-- Center Container -->
<div id="ew-center" class="<?php echo $Fulfilment_summary->CenterContentClass ?>">
<?php } ?>
<?php if ($Fulfilment_summary->ShowDrillDownFilter) { ?>
<?php $Fulfilment_summary->showDrillDownList() ?>
<?php } ?>
<!-- Summary report (begin) -->
<div id="report_summary">
<?php if (!$Fulfilment_summary->isExport() && !$Fulfilment_summary->DrillDown && !$DashboardReport) { ?>
<?php if (!$Fulfilment_summary->isExport() && !$Fulfilment->CurrentAction) { ?>
<form name="fsummary" id="fsummary" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fsummary-search-panel" class="<?php echo $Fulfilment_summary->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="Fulfilment">
	<div class="ew-extended-search">
<?php

// Render search row
$Fulfilment->RowType = ROWTYPE_SEARCH;
$Fulfilment->resetAttributes();
$Fulfilment_summary->renderRow();
?>
<?php if ($Fulfilment_summary->Position->Visible) { // Position ?>
	<?php
		$Fulfilment_summary->SearchColumnCount++;
		if (($Fulfilment_summary->SearchColumnCount - 1) % $Fulfilment_summary->SearchFieldsPerRow == 0) {
			$Fulfilment_summary->SearchRowCount++;
	?>
<div id="xsr_<?php echo $Fulfilment_summary->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_Position" class="ew-cell form-group">
		<label for="x_Position" class="ew-search-caption ew-label"><?php echo $Fulfilment_summary->Position->caption() ?></label>
		<span id="el_Fulfilment_Position" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="Fulfilment" data-field="x_Position" data-value-separator="<?php echo $Fulfilment_summary->Position->displayValueSeparatorAttribute() ?>" id="x_Position" name="x_Position"<?php echo $Fulfilment_summary->Position->editAttributes() ?>>
			<?php echo $Fulfilment_summary->Position->selectOptionListHtml("x_Position") ?>
		</select>
</div>
<?php echo $Fulfilment_summary->Position->Lookup->getParamTag($Fulfilment_summary, "p_x_Position") ?>
</span>
	</div>
	<?php if ($Fulfilment_summary->SearchColumnCount % $Fulfilment_summary->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($Fulfilment_summary->Branch->Visible) { // Branch ?>
	<?php
		$Fulfilment_summary->SearchColumnCount++;
		if (($Fulfilment_summary->SearchColumnCount - 1) % $Fulfilment_summary->SearchFieldsPerRow == 0) {
			$Fulfilment_summary->SearchRowCount++;
	?>
<div id="xsr_<?php echo $Fulfilment_summary->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_Branch" class="ew-cell form-group">
		<label for="x_Branch" class="ew-search-caption ew-label"><?php echo $Fulfilment_summary->Branch->caption() ?></label>
		<span id="el_Fulfilment_Branch" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="Fulfilment" data-field="x_Branch" data-value-separator="<?php echo $Fulfilment_summary->Branch->displayValueSeparatorAttribute() ?>" id="x_Branch" name="x_Branch"<?php echo $Fulfilment_summary->Branch->editAttributes() ?>>
			<?php echo $Fulfilment_summary->Branch->selectOptionListHtml("x_Branch") ?>
		</select>
</div>
<?php echo $Fulfilment_summary->Branch->Lookup->getParamTag($Fulfilment_summary, "p_x_Branch") ?>
</span>
	</div>
	<?php if ($Fulfilment_summary->SearchColumnCount % $Fulfilment_summary->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($Fulfilment_summary->Status->Visible) { // Status ?>
	<?php
		$Fulfilment_summary->SearchColumnCount++;
		if (($Fulfilment_summary->SearchColumnCount - 1) % $Fulfilment_summary->SearchFieldsPerRow == 0) {
			$Fulfilment_summary->SearchRowCount++;
	?>
<div id="xsr_<?php echo $Fulfilment_summary->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_Status" class="ew-cell form-group">
		<label class="ew-search-caption ew-label"><?php echo $Fulfilment_summary->Status->caption() ?></label>
		<span id="el_Fulfilment_Status" class="ew-search-field">
<div id="tp_x_Status" class="ew-template"><input type="checkbox" class="custom-control-input" data-table="Fulfilment" data-field="x_Status" data-value-separator="<?php echo $Fulfilment_summary->Status->displayValueSeparatorAttribute() ?>" name="x_Status[]" id="x_Status[]" value="{value}"<?php echo $Fulfilment_summary->Status->editAttributes() ?>></div>
<div id="dsl_x_Status" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $Fulfilment_summary->Status->checkBoxListHtml(FALSE, "x_Status[]") ?>
</div></div>
<?php echo $Fulfilment_summary->Status->Lookup->getParamTag($Fulfilment_summary, "p_x_Status") ?>
</span>
	</div>
	<?php if ($Fulfilment_summary->SearchColumnCount % $Fulfilment_summary->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
	<?php if ($Fulfilment_summary->SearchColumnCount % $Fulfilment_summary->SearchFieldsPerRow > 0) { ?>
</div>
	<?php } ?>
<div id="xsr_<?php echo $Fulfilment_summary->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php
while ($Fulfilment_summary->GroupCount <= count($Fulfilment_summary->GroupRecords) && $Fulfilment_summary->GroupCount <= $Fulfilment_summary->DisplayGroups) {
?>
<?php

	// Show header
	if ($Fulfilment_summary->ShowHeader) {
?>
<?php if ($Fulfilment_summary->GroupCount > 1) { ?>
</tbody>
</table>
</div>
<!-- /.ew-grid-middle-panel -->
<!-- Report grid (end) -->
<?php if ($Fulfilment_summary->TotalGroups > 0) { ?>
<?php if (!$Fulfilment_summary->isExport() && !($Fulfilment_summary->DrillDown && $Fulfilment_summary->TotalGroups > 0)) { ?>
<!-- Bottom pager -->
<div class="card-footer ew-grid-lower-panel">
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $Fulfilment_summary->Pager->render() ?>
</form>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php } ?>
</div>
<!-- /.ew-grid -->
<?php echo $Fulfilment_summary->PageBreakContent ?>
<?php } ?>
<div class="<?php if (!$Fulfilment_summary->isExport("word") && !$Fulfilment_summary->isExport("excel")) { ?>card ew-card <?php } ?>ew-grid"<?php echo $Fulfilment_summary->ReportTableStyle ?>>
<?php if (!$Fulfilment_summary->isExport() && !($Fulfilment_summary->DrillDown && $Fulfilment_summary->TotalGroups > 0)) { ?>
<!-- Top pager -->
<div class="card-header ew-grid-upper-panel">
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $Fulfilment_summary->Pager->render() ?>
</form>
<div class="clearfix"></div>
</div>
<?php } ?>
<!-- Report grid (begin) -->
<div id="gmp_Fulfilment" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="<?php echo $Fulfilment_summary->ReportTableClass ?>">
<thead>
	<!-- Table header -->
	<tr class="ew-table-header">
<?php if ($Fulfilment_summary->Branch->Visible) { ?>
	<?php if ($Fulfilment_summary->Branch->ShowGroupHeaderAsRow) { ?>
	<th data-name="Branch">&nbsp;</th>
	<?php } else { ?>
		<?php if ($Fulfilment_summary->sortUrl($Fulfilment_summary->Branch) == "") { ?>
	<th data-name="Branch" class="<?php echo $Fulfilment_summary->Branch->headerCellClass() ?>"><div class="Fulfilment_Branch"><div class="ew-table-header-caption"><?php echo $Fulfilment_summary->Branch->caption() ?></div></div></th>
		<?php } else { ?>
	<th data-name="Branch" class="<?php echo $Fulfilment_summary->Branch->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Fulfilment_summary->sortUrl($Fulfilment_summary->Branch) ?>', 1);"><div class="Fulfilment_Branch">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Fulfilment_summary->Branch->caption() ?></span><span class="ew-table-header-sort"><?php if ($Fulfilment_summary->Branch->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Fulfilment_summary->Branch->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
		<?php } ?>
	<?php } ?>
<?php } ?>
<?php if ($Fulfilment_summary->Position->Visible) { ?>
	<?php if ($Fulfilment_summary->Position->ShowGroupHeaderAsRow) { ?>
	<th data-name="Position">&nbsp;</th>
	<?php } else { ?>
		<?php if ($Fulfilment_summary->sortUrl($Fulfilment_summary->Position) == "") { ?>
	<th data-name="Position" class="<?php echo $Fulfilment_summary->Position->headerCellClass() ?>"><div class="Fulfilment_Position"><div class="ew-table-header-caption"><?php echo $Fulfilment_summary->Position->caption() ?></div></div></th>
		<?php } else { ?>
	<th data-name="Position" class="<?php echo $Fulfilment_summary->Position->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Fulfilment_summary->sortUrl($Fulfilment_summary->Position) ?>', 1);"><div class="Fulfilment_Position">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Fulfilment_summary->Position->caption() ?></span><span class="ew-table-header-sort"><?php if ($Fulfilment_summary->Position->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Fulfilment_summary->Position->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
		<?php } ?>
	<?php } ?>
<?php } ?>
<?php if ($Fulfilment_summary->Status->Visible) { ?>
	<?php if ($Fulfilment_summary->Status->ShowGroupHeaderAsRow) { ?>
	<th data-name="Status">&nbsp;</th>
	<?php } else { ?>
		<?php if ($Fulfilment_summary->sortUrl($Fulfilment_summary->Status) == "") { ?>
	<th data-name="Status" class="<?php echo $Fulfilment_summary->Status->headerCellClass() ?>"><div class="Fulfilment_Status"><div class="ew-table-header-caption"><?php echo $Fulfilment_summary->Status->caption() ?></div></div></th>
		<?php } else { ?>
	<th data-name="Status" class="<?php echo $Fulfilment_summary->Status->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Fulfilment_summary->sortUrl($Fulfilment_summary->Status) ?>', 1);"><div class="Fulfilment_Status">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Fulfilment_summary->Status->caption() ?></span><span class="ew-table-header-sort"><?php if ($Fulfilment_summary->Status->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Fulfilment_summary->Status->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
		<?php } ?>
	<?php } ?>
<?php } ?>
<?php if ($Fulfilment_summary->MPP->Visible) { ?>
	<?php if ($Fulfilment_summary->sortUrl($Fulfilment_summary->MPP) == "") { ?>
	<th data-name="MPP" class="<?php echo $Fulfilment_summary->MPP->headerCellClass() ?>"><div class="Fulfilment_MPP"><div class="ew-table-header-caption"><?php echo $Fulfilment_summary->MPP->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="MPP" class="<?php echo $Fulfilment_summary->MPP->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Fulfilment_summary->sortUrl($Fulfilment_summary->MPP) ?>', 1);"><div class="Fulfilment_MPP">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Fulfilment_summary->MPP->caption() ?></span><span class="ew-table-header-sort"><?php if ($Fulfilment_summary->MPP->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Fulfilment_summary->MPP->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($Fulfilment_summary->Current->Visible) { ?>
	<?php if ($Fulfilment_summary->sortUrl($Fulfilment_summary->Current) == "") { ?>
	<th data-name="Current" class="<?php echo $Fulfilment_summary->Current->headerCellClass() ?>"><div class="Fulfilment_Current"><div class="ew-table-header-caption"><?php echo $Fulfilment_summary->Current->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="Current" class="<?php echo $Fulfilment_summary->Current->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Fulfilment_summary->sortUrl($Fulfilment_summary->Current) ?>', 1);"><div class="Fulfilment_Current">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Fulfilment_summary->Current->caption() ?></span><span class="ew-table-header-sort"><?php if ($Fulfilment_summary->Current->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Fulfilment_summary->Current->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($Fulfilment_summary->Lack->Visible) { ?>
	<?php if ($Fulfilment_summary->sortUrl($Fulfilment_summary->Lack) == "") { ?>
	<th data-name="Lack" class="<?php echo $Fulfilment_summary->Lack->headerCellClass() ?>"><div class="Fulfilment_Lack"><div class="ew-table-header-caption"><?php echo $Fulfilment_summary->Lack->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="Lack" class="<?php echo $Fulfilment_summary->Lack->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Fulfilment_summary->sortUrl($Fulfilment_summary->Lack) ?>', 1);"><div class="Fulfilment_Lack">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Fulfilment_summary->Lack->caption() ?></span><span class="ew-table-header-sort"><?php if ($Fulfilment_summary->Lack->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Fulfilment_summary->Lack->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
	</tr>
</thead>
<tbody>
<?php
		if ($Fulfilment_summary->TotalGroups == 0)
			break; // Show header only
		$Fulfilment_summary->ShowHeader = FALSE;
	} // End show header
?>
<?php

	// Build detail SQL
	$where = DetailFilterSql($Fulfilment_summary->Branch, $Fulfilment_summary->getSqlFirstGroupField(), $Fulfilment_summary->Branch->groupValue(), $Fulfilment_summary->Dbid);
	if ($Fulfilment_summary->PageFirstGroupFilter != "") $Fulfilment_summary->PageFirstGroupFilter .= " OR ";
	$Fulfilment_summary->PageFirstGroupFilter .= $where;
	if ($Fulfilment_summary->Filter != "")
		$where = "($Fulfilment_summary->Filter) AND ($where)";
	$sql = BuildReportSql($Fulfilment_summary->getSqlSelect(), $Fulfilment_summary->getSqlWhere(), $Fulfilment_summary->getSqlGroupBy(), $Fulfilment_summary->getSqlHaving(), $Fulfilment_summary->getSqlOrderBy(), $where, $Fulfilment_summary->Sort);
	$rs = $Fulfilment_summary->getRecordset($sql);
	$Fulfilment_summary->DetailRecords = $rs ? $rs->getRows() : [];
	$Fulfilment_summary->DetailRecordCount = count($Fulfilment_summary->DetailRecords);

	// Load detail records
	$Fulfilment_summary->Branch->Records = &$Fulfilment_summary->DetailRecords;
	$Fulfilment_summary->Branch->LevelBreak = TRUE; // Set field level break
		$Fulfilment_summary->GroupCounter[1] = $Fulfilment_summary->GroupCount;
		$Fulfilment_summary->Branch->getCnt($Fulfilment_summary->Branch->Records); // Get record count
?>
<?php if ($Fulfilment_summary->Branch->Visible && $Fulfilment_summary->Branch->ShowGroupHeaderAsRow) { ?>
<?php

		// Render header row
		$Fulfilment_summary->resetAttributes();
		$Fulfilment_summary->RowType = ROWTYPE_TOTAL;
		$Fulfilment_summary->RowTotalType = ROWTOTAL_GROUP;
		$Fulfilment_summary->RowTotalSubType = ROWTOTAL_HEADER;
		$Fulfilment_summary->RowGroupLevel = 1;
		$Fulfilment_summary->renderRow();
?>
	<tr<?php echo $Fulfilment_summary->rowAttributes(); ?>>
<?php if ($Fulfilment_summary->Branch->Visible) { ?>
		<td data-field="Branch"<?php echo $Fulfilment_summary->Branch->cellAttributes(); ?>><span class="ew-group-toggle icon-collapse"></span></td>
<?php } ?>
		<td data-field="Branch" colspan="<?php echo ($Page->GroupColumnCount + $Page->DetailColumnCount - 1) ?>"<?php echo $Fulfilment_summary->Branch->cellAttributes() ?>>
<?php if ($Fulfilment_summary->sortUrl($Fulfilment_summary->Branch) == "") { ?>
		<span class="ew-summary-caption Fulfilment_Branch"><span class="ew-table-header-caption"><?php echo $Fulfilment_summary->Branch->caption() ?></span></span>
<?php } else { ?>
		<span class="ew-table-header-btn ew-pointer ew-summary-caption Fulfilment_Branch" onclick="ew.sort(event, '<?php echo $Fulfilment_summary->sortUrl($Fulfilment_summary->Branch) ?>', 1);">
			<span class="ew-table-header-caption"><?php echo $Fulfilment_summary->Branch->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Fulfilment_summary->Branch->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Fulfilment_summary->Branch->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span>
		</span>
<?php } ?>
		<?php echo $Language->phrase("SummaryColon") ?><span<?php echo $Fulfilment_summary->Branch->viewAttributes() ?>><?php echo $Fulfilment_summary->Branch->GroupViewValue ?></span>
		<span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($Fulfilment_summary->Branch->Count, 0); ?></span>)</span>
		</td>
	</tr>
<?php } ?>
<?php
	$Fulfilment_summary->Position->getDistinctValues($Fulfilment_summary->Branch->Records);
	$Fulfilment_summary->setGroupCount(count($Fulfilment_summary->Position->DistinctValues), $Fulfilment_summary->GroupCounter[1]);
	$Fulfilment_summary->GroupCounter[2] = 0; // Init group count index
	foreach ($Fulfilment_summary->Position->DistinctValues as $Position) { // Load records for this distinct value
		$Fulfilment_summary->Position->setGroupValue($Position); // Set group value
		$Fulfilment_summary->Position->getDistinctRecords($Fulfilment_summary->Branch->Records, $Fulfilment_summary->Position->groupValue());
		$Fulfilment_summary->Position->LevelBreak = TRUE; // Set field level break
		$Fulfilment_summary->GroupCounter[2]++;
		$Fulfilment_summary->Position->getCnt($Fulfilment_summary->Position->Records); // Get record count
?>
<?php if ($Fulfilment_summary->Position->Visible && $Fulfilment_summary->Position->ShowGroupHeaderAsRow) { ?>
<?php

		// Render header row
		$Fulfilment_summary->Position->setDbValue($Position); // Set current value for Position
		$Fulfilment_summary->resetAttributes();
		$Fulfilment_summary->RowType = ROWTYPE_TOTAL;
		$Fulfilment_summary->RowTotalType = ROWTOTAL_GROUP;
		$Fulfilment_summary->RowTotalSubType = ROWTOTAL_HEADER;
		$Fulfilment_summary->RowGroupLevel = 2;
		$Fulfilment_summary->renderRow();
?>
	<tr<?php echo $Fulfilment_summary->rowAttributes(); ?>>
<?php if ($Fulfilment_summary->Branch->Visible) { ?>
		<td data-field="Branch"<?php echo $Fulfilment_summary->Branch->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($Fulfilment_summary->Position->Visible) { ?>
		<td data-field="Position"<?php echo $Fulfilment_summary->Position->cellAttributes(); ?>><span class="ew-group-toggle icon-collapse"></span></td>
<?php } ?>
		<td data-field="Position" colspan="<?php echo ($Page->GroupColumnCount + $Page->DetailColumnCount - 2) ?>"<?php echo $Fulfilment_summary->Position->cellAttributes() ?>>
<?php if ($Fulfilment_summary->sortUrl($Fulfilment_summary->Position) == "") { ?>
		<span class="ew-summary-caption Fulfilment_Position"><span class="ew-table-header-caption"><?php echo $Fulfilment_summary->Position->caption() ?></span></span>
<?php } else { ?>
		<span class="ew-table-header-btn ew-pointer ew-summary-caption Fulfilment_Position" onclick="ew.sort(event, '<?php echo $Fulfilment_summary->sortUrl($Fulfilment_summary->Position) ?>', 1);">
			<span class="ew-table-header-caption"><?php echo $Fulfilment_summary->Position->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Fulfilment_summary->Position->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Fulfilment_summary->Position->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span>
		</span>
<?php } ?>
		<?php echo $Language->phrase("SummaryColon") ?><span<?php echo $Fulfilment_summary->Position->viewAttributes() ?>><?php echo $Fulfilment_summary->Position->GroupViewValue ?></span>
		<span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($Fulfilment_summary->Position->Count, 0); ?></span>)</span>
		</td>
	</tr>
<?php } ?>
<?php
	$Fulfilment_summary->Status->getDistinctValues($Fulfilment_summary->Position->Records);
	$Fulfilment_summary->setGroupCount(count($Fulfilment_summary->Status->DistinctValues), $Fulfilment_summary->GroupCounter[1], $Fulfilment_summary->GroupCounter[2]);
	$Fulfilment_summary->GroupCounter[3] = 0; // Init group count index
	foreach ($Fulfilment_summary->Status->DistinctValues as $Status) { // Load records for this distinct value
		$Fulfilment_summary->Status->setGroupValue($Status); // Set group value
		$Fulfilment_summary->Status->getDistinctRecords($Fulfilment_summary->Position->Records, $Fulfilment_summary->Status->groupValue());
		$Fulfilment_summary->Status->LevelBreak = TRUE; // Set field level break
		$Fulfilment_summary->GroupCounter[3]++;
		$Fulfilment_summary->Status->getCnt($Fulfilment_summary->Status->Records); // Get record count
		$Fulfilment_summary->setGroupCount($Fulfilment_summary->Status->Count, $Fulfilment_summary->GroupCounter[1], $Fulfilment_summary->GroupCounter[2], $Fulfilment_summary->GroupCounter[3]);
?>
<?php if ($Fulfilment_summary->Status->Visible && $Fulfilment_summary->Status->ShowGroupHeaderAsRow) { ?>
<?php

		// Render header row
		$Fulfilment_summary->Status->setDbValue($Status); // Set current value for Status
		$Fulfilment_summary->resetAttributes();
		$Fulfilment_summary->RowType = ROWTYPE_TOTAL;
		$Fulfilment_summary->RowTotalType = ROWTOTAL_GROUP;
		$Fulfilment_summary->RowTotalSubType = ROWTOTAL_HEADER;
		$Fulfilment_summary->RowGroupLevel = 3;
		$Fulfilment_summary->renderRow();
?>
	<tr<?php echo $Fulfilment_summary->rowAttributes(); ?>>
<?php if ($Fulfilment_summary->Branch->Visible) { ?>
		<td data-field="Branch"<?php echo $Fulfilment_summary->Branch->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($Fulfilment_summary->Position->Visible) { ?>
		<td data-field="Position"<?php echo $Fulfilment_summary->Position->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($Fulfilment_summary->Status->Visible) { ?>
		<td data-field="Status"<?php echo $Fulfilment_summary->Status->cellAttributes(); ?>><span class="ew-group-toggle icon-collapse"></span></td>
<?php } ?>
		<td data-field="Status" colspan="<?php echo ($Page->GroupColumnCount + $Page->DetailColumnCount - 3) ?>"<?php echo $Fulfilment_summary->Status->cellAttributes() ?>>
<?php if ($Fulfilment_summary->sortUrl($Fulfilment_summary->Status) == "") { ?>
		<span class="ew-summary-caption Fulfilment_Status"><span class="ew-table-header-caption"><?php echo $Fulfilment_summary->Status->caption() ?></span></span>
<?php } else { ?>
		<span class="ew-table-header-btn ew-pointer ew-summary-caption Fulfilment_Status" onclick="ew.sort(event, '<?php echo $Fulfilment_summary->sortUrl($Fulfilment_summary->Status) ?>', 1);">
			<span class="ew-table-header-caption"><?php echo $Fulfilment_summary->Status->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Fulfilment_summary->Status->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Fulfilment_summary->Status->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span>
		</span>
<?php } ?>
		<?php echo $Language->phrase("SummaryColon") ?><span<?php echo $Fulfilment_summary->Status->viewAttributes() ?>><?php echo $Fulfilment_summary->Status->GroupViewValue ?></span>
		<span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($Fulfilment_summary->Status->Count, 0); ?></span>)</span>
		</td>
	</tr>
<?php } ?>
<?php
	$Fulfilment_summary->RecordCount = 0; // Reset record count
	foreach ($Fulfilment_summary->Status->Records as $record) {
		$Fulfilment_summary->RecordCount++;
		$Fulfilment_summary->RecordIndex++;
		$Fulfilment_summary->loadRowValues($record);
?>
<?php

		// Render detail row
		$Fulfilment_summary->resetAttributes();
		$Fulfilment_summary->RowType = ROWTYPE_DETAIL;
		$Fulfilment_summary->renderRow();
?>
	<tr<?php echo $Fulfilment_summary->rowAttributes(); ?>>
<?php if ($Fulfilment_summary->Branch->Visible) { ?>
	<?php if ($Fulfilment_summary->Branch->ShowGroupHeaderAsRow) { ?>
		<td data-field="Branch"<?php echo $Fulfilment_summary->Branch->cellAttributes(); ?>>&nbsp;</td>
	<?php } else { ?>
		<td data-field="Branch"<?php echo $Fulfilment_summary->Branch->cellAttributes(); ?>><span<?php echo $Fulfilment_summary->Branch->viewAttributes() ?>><?php echo $Fulfilment_summary->Branch->GroupViewValue ?></span></td>
	<?php } ?>
<?php } ?>
<?php if ($Fulfilment_summary->Position->Visible) { ?>
	<?php if ($Fulfilment_summary->Position->ShowGroupHeaderAsRow) { ?>
		<td data-field="Position"<?php echo $Fulfilment_summary->Position->cellAttributes(); ?>>&nbsp;</td>
	<?php } else { ?>
		<td data-field="Position"<?php echo $Fulfilment_summary->Position->cellAttributes(); ?>><span<?php echo $Fulfilment_summary->Position->viewAttributes() ?>><?php echo $Fulfilment_summary->Position->GroupViewValue ?></span></td>
	<?php } ?>
<?php } ?>
<?php if ($Fulfilment_summary->Status->Visible) { ?>
	<?php if ($Fulfilment_summary->Status->ShowGroupHeaderAsRow) { ?>
		<td data-field="Status"<?php echo $Fulfilment_summary->Status->cellAttributes(); ?>>&nbsp;</td>
	<?php } else { ?>
		<td data-field="Status"<?php echo $Fulfilment_summary->Status->cellAttributes(); ?>><span<?php echo $Fulfilment_summary->Status->viewAttributes() ?>><?php echo $Fulfilment_summary->Status->GroupViewValue ?></span></td>
	<?php } ?>
<?php } ?>
<?php if ($Fulfilment_summary->MPP->Visible) { ?>
		<td data-field="MPP"<?php echo $Fulfilment_summary->MPP->cellAttributes() ?>>
<span<?php echo $Fulfilment_summary->MPP->viewAttributes() ?>><?php echo $Fulfilment_summary->MPP->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($Fulfilment_summary->Current->Visible) { ?>
		<td data-field="Current"<?php echo $Fulfilment_summary->Current->cellAttributes() ?>>
<span<?php echo $Fulfilment_summary->Current->viewAttributes() ?>><?php if ($Fulfilment_summary->Current->linkAttributes() != "") { ?>
<a<?php echo $Fulfilment_summary->Current->linkAttributes() ?>><?php echo $Fulfilment_summary->Current->getViewValue() ?></a>
<?php } else { ?>
<?php echo $Fulfilment_summary->Current->getViewValue() ?>
<?php } ?></span>
</td>
<?php } ?>
<?php if ($Fulfilment_summary->Lack->Visible) { ?>
		<td data-field="Lack"<?php echo $Fulfilment_summary->Lack->cellAttributes() ?>>
<span<?php echo $Fulfilment_summary->Lack->viewAttributes() ?>><?php echo $Fulfilment_summary->Lack->getViewValue() ?></span>
</td>
<?php } ?>
	</tr>
<?php
	}
	} // End group level 2
	} // End group level 1
?>
<?php if ($Fulfilment_summary->TotalGroups > 0) { ?>
<?php
	$Fulfilment_summary->MPP->getSum($Fulfilment_summary->Branch->Records); // Get Sum
	$Fulfilment_summary->Current->getSum($Fulfilment_summary->Branch->Records); // Get Sum
	$Fulfilment_summary->Lack->getSum($Fulfilment_summary->Branch->Records); // Get Sum
	$Fulfilment_summary->resetAttributes();
	$Fulfilment_summary->RowType = ROWTYPE_TOTAL;
	$Fulfilment_summary->RowTotalType = ROWTOTAL_GROUP;
	$Fulfilment_summary->RowTotalSubType = ROWTOTAL_FOOTER;
	$Fulfilment_summary->RowGroupLevel = 1;
	$Fulfilment_summary->renderRow();
?>
<?php if ($Fulfilment_summary->Branch->ShowCompactSummaryFooter) { ?>
	<tr<?php echo $Fulfilment_summary->rowAttributes(); ?>>
<?php if ($Fulfilment_summary->Branch->Visible) { ?>
		<td data-field="Branch"<?php echo $Fulfilment_summary->Branch->cellAttributes() ?>>
	<?php if ($Fulfilment_summary->Branch->ShowGroupHeaderAsRow) { ?>
		&nbsp;
	<?php } elseif ($Fulfilment_summary->RowGroupLevel != 1) { ?>
		&nbsp;
	<?php } else { ?>
		<span class="ew-summary-count"><span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($Fulfilment_summary->Branch->Count, 0); ?></span></span>
	<?php } ?>
		</td>
<?php } ?>
<?php if ($Fulfilment_summary->Position->Visible) { ?>
		<td data-field="Position"<?php echo $Fulfilment_summary->Branch->cellAttributes() ?>>
	<?php if ($Fulfilment_summary->Position->ShowGroupHeaderAsRow) { ?>
		&nbsp;
	<?php } elseif ($Fulfilment_summary->RowGroupLevel != 2) { ?>
		&nbsp;
	<?php } else { ?>
		<span class="ew-summary-count"><span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($Fulfilment_summary->Position->Count, 0); ?></span></span>
	<?php } ?>
		</td>
<?php } ?>
<?php if ($Fulfilment_summary->Status->Visible) { ?>
		<td data-field="Status"<?php echo $Fulfilment_summary->Branch->cellAttributes() ?>>
	<?php if ($Fulfilment_summary->Status->ShowGroupHeaderAsRow) { ?>
		&nbsp;
	<?php } elseif ($Fulfilment_summary->RowGroupLevel != 3) { ?>
		&nbsp;
	<?php } else { ?>
		<span class="ew-summary-count"><span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($Fulfilment_summary->Status->Count, 0); ?></span></span>
	<?php } ?>
		</td>
<?php } ?>
<?php if ($Fulfilment_summary->MPP->Visible) { ?>
		<td data-field="MPP"<?php echo $Fulfilment_summary->Branch->cellAttributes() ?>><span class="ew-aggregate-caption"><?php echo $Language->phrase("RptSum") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><span<?php echo $Fulfilment_summary->MPP->viewAttributes() ?>><?php echo $Fulfilment_summary->MPP->SumViewValue ?></span></span></td>
<?php } ?>
<?php if ($Fulfilment_summary->Current->Visible) { ?>
		<td data-field="Current"<?php echo $Fulfilment_summary->Branch->cellAttributes() ?>><span class="ew-aggregate-caption"><?php echo $Language->phrase("RptSum") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><span<?php echo $Fulfilment_summary->Current->viewAttributes() ?>><?php if ($Fulfilment_summary->Current->linkAttributes() != "") { ?><a<?php echo $Fulfilment_summary->Current->linkAttributes() ?>><?php echo $Fulfilment_summary->Current->SumViewValue ?></a><?php } else { ?><?php echo $Fulfilment_summary->Current->SumViewValue ?><?php } ?></span></span></td>
<?php } ?>
<?php if ($Fulfilment_summary->Lack->Visible) { ?>
		<td data-field="Lack"<?php echo $Fulfilment_summary->Branch->cellAttributes() ?>><span class="ew-aggregate-caption"><?php echo $Language->phrase("RptSum") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><span<?php echo $Fulfilment_summary->Lack->viewAttributes() ?>><?php echo $Fulfilment_summary->Lack->SumViewValue ?></span></span></td>
<?php } ?>
	</tr>
<?php } else { ?>
	<tr<?php echo $Fulfilment_summary->rowAttributes(); ?>>
<?php if ($Fulfilment_summary->GroupColumnCount + $Fulfilment_summary->DetailColumnCount > 0) { ?>
		<td colspan="<?php echo ($Fulfilment_summary->GroupColumnCount + $Fulfilment_summary->DetailColumnCount) ?>"<?php echo $Fulfilment_summary->Branch->cellAttributes() ?>><?php echo str_replace(["%v", "%c"], [$Fulfilment_summary->Branch->GroupViewValue, $Fulfilment_summary->Branch->caption()], $Language->phrase("RptSumHead")) ?> <span class="ew-dir-ltr">(<?php echo FormatNumber($Fulfilment_summary->Branch->Count, 0); ?><?php echo $Language->phrase("RptDtlRec") ?>)</span></td>
<?php } ?>
	</tr>
	<tr<?php echo $Fulfilment_summary->rowAttributes(); ?>>
<?php if ($Fulfilment_summary->GroupColumnCount > 0) { ?>
		<td colspan="<?php echo ($Fulfilment_summary->GroupColumnCount - 0) ?>"<?php echo $Fulfilment_summary->Branch->cellAttributes() ?>><?php echo $Language->phrase("RptSum") ?></td>
<?php } ?>
<?php if ($Fulfilment_summary->MPP->Visible) { ?>
		<td data-field="MPP"<?php echo $Fulfilment_summary->MPP->cellAttributes() ?>>
<span<?php echo $Fulfilment_summary->MPP->viewAttributes() ?>><?php echo $Fulfilment_summary->MPP->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Fulfilment_summary->Current->Visible) { ?>
		<td data-field="Current"<?php echo $Fulfilment_summary->Current->cellAttributes() ?>>
<span<?php echo $Fulfilment_summary->Current->viewAttributes() ?>><?php if ($Fulfilment_summary->Current->linkAttributes() != "") { ?>
<a<?php echo $Fulfilment_summary->Current->linkAttributes() ?>><?php echo $Fulfilment_summary->Current->SumViewValue ?></a>
<?php } else { ?>
<?php echo $Fulfilment_summary->Current->SumViewValue ?>
<?php } ?></span>
</td>
<?php } ?>
<?php if ($Fulfilment_summary->Lack->Visible) { ?>
		<td data-field="Lack"<?php echo $Fulfilment_summary->Lack->cellAttributes() ?>>
<span<?php echo $Fulfilment_summary->Lack->viewAttributes() ?>><?php echo $Fulfilment_summary->Lack->SumViewValue ?></span>
</td>
<?php } ?>
	</tr>
<?php } ?>
<?php } ?>
<?php
?>
<?php

	// Next group
	$Fulfilment_summary->loadGroupRowValues();

	// Show header if page break
	if ($Fulfilment_summary->isExport())
		$Fulfilment_summary->ShowHeader = ($Fulfilment_summary->ExportPageBreakCount == 0) ? FALSE : ($Fulfilment_summary->GroupCount % $Fulfilment_summary->ExportPageBreakCount == 0);

	// Page_Breaking server event
	if ($Fulfilment_summary->ShowHeader)
		$Fulfilment_summary->Page_Breaking($Fulfilment_summary->ShowHeader, $Fulfilment_summary->PageBreakContent);
	$Fulfilment_summary->GroupCount++;
} // End while
?>
<?php if ($Fulfilment_summary->TotalGroups > 0) { ?>
</tbody>
<tfoot>
<?php if (($Fulfilment_summary->StopGroup - $Fulfilment_summary->StartGroup + 1) != $Fulfilment_summary->TotalGroups) { ?>
<?php
	$Fulfilment_summary->resetAttributes();
	$Fulfilment_summary->RowType = ROWTYPE_TOTAL;
	$Fulfilment_summary->RowTotalType = ROWTOTAL_PAGE;
	$Fulfilment_summary->RowTotalSubType = ROWTOTAL_FOOTER;
	$Fulfilment_summary->RowAttrs["class"] = "ew-rpt-page-summary";
	$Fulfilment_summary->renderRow();
?>
<?php if ($Fulfilment_summary->Branch->ShowCompactSummaryFooter) { ?>
	<tr<?php echo $Fulfilment_summary->rowAttributes(); ?>><td colspan="<?php echo ($Fulfilment_summary->GroupColumnCount + $Fulfilment_summary->DetailColumnCount) ?>"><?php echo $Language->phrase("RptPageSummary") ?> <span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($Fulfilment_summary->PageTotalCount, 0); ?></span>)</span></td></tr>
	<tr<?php echo $Fulfilment_summary->rowAttributes(); ?>>
<?php if ($Fulfilment_summary->GroupColumnCount > 0) { ?>
		<td colspan="<?php echo $Fulfilment_summary->GroupColumnCount ?>" class="ew-rpt-grp-aggregate">&nbsp;</td>
<?php } ?>
<?php if ($Fulfilment_summary->MPP->Visible) { ?>
		<td data-field="MPP"<?php echo $Fulfilment_summary->MPP->cellAttributes() ?>><span class="ew-aggregate-caption"><?php echo $Language->phrase("RptSum") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><span<?php echo $Fulfilment_summary->MPP->viewAttributes() ?>><?php echo $Fulfilment_summary->MPP->SumViewValue ?></span></span></td>
<?php } ?>
<?php if ($Fulfilment_summary->Current->Visible) { ?>
		<td data-field="Current"<?php echo $Fulfilment_summary->Current->cellAttributes() ?>><span class="ew-aggregate-caption"><?php echo $Language->phrase("RptSum") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><span<?php echo $Fulfilment_summary->Current->viewAttributes() ?>><?php if ($Fulfilment_summary->Current->linkAttributes() != "") { ?><a<?php echo $Fulfilment_summary->Current->linkAttributes() ?>><?php echo $Fulfilment_summary->Current->SumViewValue ?></a><?php } else { ?><?php echo $Fulfilment_summary->Current->SumViewValue ?><?php } ?></span></span></td>
<?php } ?>
<?php if ($Fulfilment_summary->Lack->Visible) { ?>
		<td data-field="Lack"<?php echo $Fulfilment_summary->Lack->cellAttributes() ?>><span class="ew-aggregate-caption"><?php echo $Language->phrase("RptSum") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><span<?php echo $Fulfilment_summary->Lack->viewAttributes() ?>><?php echo $Fulfilment_summary->Lack->SumViewValue ?></span></span></td>
<?php } ?>
	</tr>
<?php } else { ?>
	<tr<?php echo $Fulfilment_summary->rowAttributes(); ?>><td colspan="<?php echo ($Fulfilment_summary->GroupColumnCount + $Fulfilment_summary->DetailColumnCount) ?>"><?php echo $Language->phrase("RptPageSummary") ?> <span class="ew-summary-count">(<?php echo FormatNumber($Fulfilment_summary->PageTotalCount, 0); ?><?php echo $Language->phrase("RptDtlRec") ?>)</span></td></tr>
	<tr<?php echo $Fulfilment_summary->rowAttributes(); ?>>
<?php if ($Fulfilment_summary->GroupColumnCount > 0) { ?>
		<td colspan="<?php echo $Fulfilment_summary->GroupColumnCount ?>" class="ew-rpt-grp-aggregate"><?php echo $Language->phrase("RptSum") ?></td>
<?php } ?>
<?php if ($Fulfilment_summary->MPP->Visible) { ?>
		<td data-field="MPP"<?php echo $Fulfilment_summary->MPP->cellAttributes() ?>>
<span<?php echo $Fulfilment_summary->MPP->viewAttributes() ?>><?php echo $Fulfilment_summary->MPP->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Fulfilment_summary->Current->Visible) { ?>
		<td data-field="Current"<?php echo $Fulfilment_summary->Current->cellAttributes() ?>>
<span<?php echo $Fulfilment_summary->Current->viewAttributes() ?>><?php if ($Fulfilment_summary->Current->linkAttributes() != "") { ?>
<a<?php echo $Fulfilment_summary->Current->linkAttributes() ?>><?php echo $Fulfilment_summary->Current->SumViewValue ?></a>
<?php } else { ?>
<?php echo $Fulfilment_summary->Current->SumViewValue ?>
<?php } ?></span>
</td>
<?php } ?>
<?php if ($Fulfilment_summary->Lack->Visible) { ?>
		<td data-field="Lack"<?php echo $Fulfilment_summary->Lack->cellAttributes() ?>>
<span<?php echo $Fulfilment_summary->Lack->viewAttributes() ?>><?php echo $Fulfilment_summary->Lack->SumViewValue ?></span>
</td>
<?php } ?>
	</tr>
<?php } ?>
<?php } ?>
<?php
	$Fulfilment_summary->resetAttributes();
	$Fulfilment_summary->RowType = ROWTYPE_TOTAL;
	$Fulfilment_summary->RowTotalType = ROWTOTAL_GRAND;
	$Fulfilment_summary->RowTotalSubType = ROWTOTAL_FOOTER;
	$Fulfilment_summary->RowAttrs["class"] = "ew-rpt-grand-summary";
	$Fulfilment_summary->renderRow();
?>
<?php if ($Fulfilment_summary->Branch->ShowCompactSummaryFooter) { ?>
	<tr<?php echo $Fulfilment_summary->rowAttributes() ?>><td colspan="<?php echo ($Fulfilment_summary->GroupColumnCount + $Fulfilment_summary->DetailColumnCount) ?>"><?php echo $Language->phrase("RptGrandSummary") ?> <span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($Fulfilment_summary->TotalCount, 0); ?></span>)</span></td></tr>
	<tr<?php echo $Fulfilment_summary->rowAttributes() ?>>
<?php if ($Fulfilment_summary->GroupColumnCount > 0) { ?>
		<td colspan="<?php echo $Fulfilment_summary->GroupColumnCount ?>" class="ew-rpt-grp-aggregate">&nbsp;</td>
<?php } ?>
<?php if ($Fulfilment_summary->MPP->Visible) { ?>
		<td data-field="MPP"<?php echo $Fulfilment_summary->MPP->cellAttributes() ?>><span class="ew-aggregate-caption"><?php echo $Language->phrase("RptSum") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><span<?php echo $Fulfilment_summary->MPP->viewAttributes() ?>><?php echo $Fulfilment_summary->MPP->SumViewValue ?></span></span></td>
<?php } ?>
<?php if ($Fulfilment_summary->Current->Visible) { ?>
		<td data-field="Current"<?php echo $Fulfilment_summary->Current->cellAttributes() ?>><span class="ew-aggregate-caption"><?php echo $Language->phrase("RptSum") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><span<?php echo $Fulfilment_summary->Current->viewAttributes() ?>><?php if ($Fulfilment_summary->Current->linkAttributes() != "") { ?><a<?php echo $Fulfilment_summary->Current->linkAttributes() ?>><?php echo $Fulfilment_summary->Current->SumViewValue ?></a><?php } else { ?><?php echo $Fulfilment_summary->Current->SumViewValue ?><?php } ?></span></span></td>
<?php } ?>
<?php if ($Fulfilment_summary->Lack->Visible) { ?>
		<td data-field="Lack"<?php echo $Fulfilment_summary->Lack->cellAttributes() ?>><span class="ew-aggregate-caption"><?php echo $Language->phrase("RptSum") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><span<?php echo $Fulfilment_summary->Lack->viewAttributes() ?>><?php echo $Fulfilment_summary->Lack->SumViewValue ?></span></span></td>
<?php } ?>
	</tr>
<?php } else { ?>
	<tr<?php echo $Fulfilment_summary->rowAttributes() ?>><td colspan="<?php echo ($Fulfilment_summary->GroupColumnCount + $Fulfilment_summary->DetailColumnCount) ?>"><?php echo $Language->phrase("RptGrandSummary") ?> <span class="ew-summary-count">(<?php echo FormatNumber($Fulfilment_summary->TotalCount, 0); ?><?php echo $Language->phrase("RptDtlRec") ?>)</span></td></tr>
	<tr<?php echo $Fulfilment_summary->rowAttributes() ?>>
<?php if ($Fulfilment_summary->GroupColumnCount > 0) { ?>
		<td colspan="<?php echo $Fulfilment_summary->GroupColumnCount ?>" class="ew-rpt-grp-aggregate"><?php echo $Language->phrase("RptSum") ?></td>
<?php } ?>
<?php if ($Fulfilment_summary->MPP->Visible) { ?>
		<td data-field="MPP"<?php echo $Fulfilment_summary->MPP->cellAttributes() ?>>
<span<?php echo $Fulfilment_summary->MPP->viewAttributes() ?>><?php echo $Fulfilment_summary->MPP->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Fulfilment_summary->Current->Visible) { ?>
		<td data-field="Current"<?php echo $Fulfilment_summary->Current->cellAttributes() ?>>
<span<?php echo $Fulfilment_summary->Current->viewAttributes() ?>><?php if ($Fulfilment_summary->Current->linkAttributes() != "") { ?>
<a<?php echo $Fulfilment_summary->Current->linkAttributes() ?>><?php echo $Fulfilment_summary->Current->SumViewValue ?></a>
<?php } else { ?>
<?php echo $Fulfilment_summary->Current->SumViewValue ?>
<?php } ?></span>
</td>
<?php } ?>
<?php if ($Fulfilment_summary->Lack->Visible) { ?>
		<td data-field="Lack"<?php echo $Fulfilment_summary->Lack->cellAttributes() ?>>
<span<?php echo $Fulfilment_summary->Lack->viewAttributes() ?>><?php echo $Fulfilment_summary->Lack->SumViewValue ?></span>
</td>
<?php } ?>
	</tr>
<?php } ?>
</tfoot>
</table>
</div>
<!-- /.ew-grid-middle-panel -->
<!-- Report grid (end) -->
<?php if ($Fulfilment_summary->TotalGroups > 0) { ?>
<?php if (!$Fulfilment_summary->isExport() && !($Fulfilment_summary->DrillDown && $Fulfilment_summary->TotalGroups > 0)) { ?>
<!-- Bottom pager -->
<div class="card-footer ew-grid-lower-panel">
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $Fulfilment_summary->Pager->render() ?>
</form>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php } ?>
</div>
<!-- /.ew-grid -->
<?php } ?>
</div>
<!-- /#report-summary -->
<!-- Summary report (end) -->
<?php if ((!$Fulfilment_summary->isExport() || $Fulfilment_summary->isExport("print")) && !$DashboardReport) { ?>
</div>
<!-- /#ew-center -->
<?php } ?>
<?php if ((!$Fulfilment_summary->isExport() || $Fulfilment_summary->isExport("print")) && !$DashboardReport) { ?>
</div>
<!-- /.row -->
<?php } ?>
<?php if ((!$Fulfilment_summary->isExport() || $Fulfilment_summary->isExport("print")) && !$DashboardReport) { ?>
</div>
<!-- /.ew-report -->
<?php } ?>
<?php
$Fulfilment_summary->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$Fulfilment_summary->isExport() && !$Fulfilment_summary->DrillDown && !$DashboardReport) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php if (!$DashboardReport) { ?>
<?php include_once "footer.php"; ?>
<?php } ?>
<?php
$Fulfilment_summary->terminate();
?>