<?php
namespace PHPMaker2020\mpp;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$level_edit = new level_edit();

// Run the page
$level_edit->run();

// Setup login status
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$level_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fleveledit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	fleveledit = currentForm = new ew.Form("fleveledit", "edit");

	// Validate form
	fleveledit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "F")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($level_edit->Level->Required) { ?>
				elm = this.getElements("x" + infix + "_Level");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $level_edit->Level->caption(), $level_edit->Level->RequiredErrorMessage)) ?>");
			<?php } ?>

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fleveledit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fleveledit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fleveledit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $level_edit->showPageHeader(); ?>
<?php
$level_edit->showMessage();
?>
<?php if (!$level_edit->IsModal) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $level_edit->Pager->render() ?>
<div class="clearfix"></div>
</form>
<?php } ?>
<form name="fleveledit" id="fleveledit" class="<?php echo $level_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="level">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$level_edit->IsModal ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($level_edit->Level->Visible) { // Level ?>
	<div id="r_Level" class="form-group row">
		<label id="elh_level_Level" for="x_Level" class="<?php echo $level_edit->LeftColumnClass ?>"><?php echo $level_edit->Level->caption() ?><?php echo $level_edit->Level->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $level_edit->RightColumnClass ?>"><div <?php echo $level_edit->Level->cellAttributes() ?>>
<span id="el_level_Level">
<input type="text" data-table="level" data-field="x_Level" name="x_Level" id="x_Level" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($level_edit->Level->getPlaceHolder()) ?>" value="<?php echo $level_edit->Level->EditValue ?>"<?php echo $level_edit->Level->editAttributes() ?>>
</span>
<?php echo $level_edit->Level->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
	<input type="hidden" data-table="level" data-field="x_levelID" name="x_levelID" id="x_levelID" value="<?php echo HtmlEncode($level_edit->levelID->CurrentValue) ?>">
<?php if (!$level_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $level_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $level_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
<?php if (!$level_edit->IsModal) { ?>
<?php echo $level_edit->Pager->render() ?>
<div class="clearfix"></div>
<?php } ?>
</form>
<?php
$level_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$level_edit->terminate();
?>