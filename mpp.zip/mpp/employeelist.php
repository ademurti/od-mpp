<?php
namespace PHPMaker2020\mpp;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$employee_list = new employee_list();

// Run the page
$employee_list->run();

// Setup login status
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$employee_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$employee_list->isExport()) { ?>
<script>
var femployeelist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	femployeelist = currentForm = new ew.Form("femployeelist", "list");
	femployeelist.formKeyCountName = '<?php echo $employee_list->FormKeyCountName ?>';
	loadjs.done("femployeelist");
});
var femployeelistsrch;
loadjs.ready("head", function() {

	// Form object for search
	femployeelistsrch = currentSearchForm = new ew.Form("femployeelistsrch");

	// Dynamic selection lists
	// Filters

	femployeelistsrch.filterList = <?php echo $employee_list->getFilterList() ?>;
	loadjs.done("femployeelistsrch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$employee_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($employee_list->TotalRecords > 0 && $employee_list->ExportOptions->visible()) { ?>
<?php $employee_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($employee_list->ImportOptions->visible()) { ?>
<?php $employee_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($employee_list->SearchOptions->visible()) { ?>
<?php $employee_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($employee_list->FilterOptions->visible()) { ?>
<?php $employee_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$employee_list->renderOtherOptions();
?>
<?php if (!$employee_list->isExport() && !$employee->CurrentAction) { ?>
<form name="femployeelistsrch" id="femployeelistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="femployeelistsrch-search-panel" class="<?php echo $employee_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="employee">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $employee_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($employee_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($employee_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $employee_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($employee_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($employee_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($employee_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($employee_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php $employee_list->showPageHeader(); ?>
<?php
$employee_list->showMessage();
?>
<?php if ($employee_list->TotalRecords > 0 || $employee->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($employee_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> employee">
<?php if (!$employee_list->isExport()) { ?>
<div class="card-header ew-grid-upper-panel">
<?php if (!$employee_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $employee_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $employee_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
<form name="femployeelist" id="femployeelist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="employee">
<div id="gmp_employee" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($employee_list->TotalRecords > 0 || $employee_list->isGridEdit()) { ?>
<table id="tbl_employeelist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$employee->RowType = ROWTYPE_HEADER;

// Render list options
$employee_list->renderListOptions();

// Render list options (header, left)
$employee_list->ListOptions->render("header", "left");
?>
<?php if ($employee_list->Location->Visible) { // Location ?>
	<?php if ($employee_list->SortUrl($employee_list->Location) == "") { ?>
		<th data-name="Location" class="<?php echo $employee_list->Location->headerCellClass() ?>"><div id="elh_employee_Location" class="employee_Location"><div class="ew-table-header-caption"><?php echo $employee_list->Location->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Location" class="<?php echo $employee_list->Location->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $employee_list->SortUrl($employee_list->Location) ?>', 1);"><div id="elh_employee_Location" class="employee_Location">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $employee_list->Location->caption() ?></span><span class="ew-table-header-sort"><?php if ($employee_list->Location->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($employee_list->Location->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($employee_list->Branch->Visible) { // Branch ?>
	<?php if ($employee_list->SortUrl($employee_list->Branch) == "") { ?>
		<th data-name="Branch" class="<?php echo $employee_list->Branch->headerCellClass() ?>"><div id="elh_employee_Branch" class="employee_Branch"><div class="ew-table-header-caption"><?php echo $employee_list->Branch->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Branch" class="<?php echo $employee_list->Branch->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $employee_list->SortUrl($employee_list->Branch) ?>', 1);"><div id="elh_employee_Branch" class="employee_Branch">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $employee_list->Branch->caption() ?></span><span class="ew-table-header-sort"><?php if ($employee_list->Branch->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($employee_list->Branch->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($employee_list->Position->Visible) { // Position ?>
	<?php if ($employee_list->SortUrl($employee_list->Position) == "") { ?>
		<th data-name="Position" class="<?php echo $employee_list->Position->headerCellClass() ?>"><div id="elh_employee_Position" class="employee_Position"><div class="ew-table-header-caption"><?php echo $employee_list->Position->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Position" class="<?php echo $employee_list->Position->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $employee_list->SortUrl($employee_list->Position) ?>', 1);"><div id="elh_employee_Position" class="employee_Position">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $employee_list->Position->caption() ?></span><span class="ew-table-header-sort"><?php if ($employee_list->Position->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($employee_list->Position->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($employee_list->Status->Visible) { // Status ?>
	<?php if ($employee_list->SortUrl($employee_list->Status) == "") { ?>
		<th data-name="Status" class="<?php echo $employee_list->Status->headerCellClass() ?>"><div id="elh_employee_Status" class="employee_Status"><div class="ew-table-header-caption"><?php echo $employee_list->Status->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Status" class="<?php echo $employee_list->Status->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $employee_list->SortUrl($employee_list->Status) ?>', 1);"><div id="elh_employee_Status" class="employee_Status">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $employee_list->Status->caption() ?></span><span class="ew-table-header-sort"><?php if ($employee_list->Status->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($employee_list->Status->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($employee_list->Name->Visible) { // Name ?>
	<?php if ($employee_list->SortUrl($employee_list->Name) == "") { ?>
		<th data-name="Name" class="<?php echo $employee_list->Name->headerCellClass() ?>"><div id="elh_employee_Name" class="employee_Name"><div class="ew-table-header-caption"><?php echo $employee_list->Name->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Name" class="<?php echo $employee_list->Name->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $employee_list->SortUrl($employee_list->Name) ?>', 1);"><div id="elh_employee_Name" class="employee_Name">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $employee_list->Name->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($employee_list->Name->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($employee_list->Name->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($employee_list->Education->Visible) { // Education ?>
	<?php if ($employee_list->SortUrl($employee_list->Education) == "") { ?>
		<th data-name="Education" class="<?php echo $employee_list->Education->headerCellClass() ?>"><div id="elh_employee_Education" class="employee_Education"><div class="ew-table-header-caption"><?php echo $employee_list->Education->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Education" class="<?php echo $employee_list->Education->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $employee_list->SortUrl($employee_list->Education) ?>', 1);"><div id="elh_employee_Education" class="employee_Education">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $employee_list->Education->caption() ?></span><span class="ew-table-header-sort"><?php if ($employee_list->Education->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($employee_list->Education->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($employee_list->Join->Visible) { // Join ?>
	<?php if ($employee_list->SortUrl($employee_list->Join) == "") { ?>
		<th data-name="Join" class="<?php echo $employee_list->Join->headerCellClass() ?>"><div id="elh_employee_Join" class="employee_Join"><div class="ew-table-header-caption"><?php echo $employee_list->Join->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Join" class="<?php echo $employee_list->Join->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $employee_list->SortUrl($employee_list->Join) ?>', 1);"><div id="elh_employee_Join" class="employee_Join">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $employee_list->Join->caption() ?></span><span class="ew-table-header-sort"><?php if ($employee_list->Join->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($employee_list->Join->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($employee_list->Resign->Visible) { // Resign ?>
	<?php if ($employee_list->SortUrl($employee_list->Resign) == "") { ?>
		<th data-name="Resign" class="<?php echo $employee_list->Resign->headerCellClass() ?>"><div id="elh_employee_Resign" class="employee_Resign"><div class="ew-table-header-caption"><?php echo $employee_list->Resign->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Resign" class="<?php echo $employee_list->Resign->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $employee_list->SortUrl($employee_list->Resign) ?>', 1);"><div id="elh_employee_Resign" class="employee_Resign">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $employee_list->Resign->caption() ?></span><span class="ew-table-header-sort"><?php if ($employee_list->Resign->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($employee_list->Resign->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($employee_list->Product->Visible) { // Product ?>
	<?php if ($employee_list->SortUrl($employee_list->Product) == "") { ?>
		<th data-name="Product" class="<?php echo $employee_list->Product->headerCellClass() ?>"><div id="elh_employee_Product" class="employee_Product"><div class="ew-table-header-caption"><?php echo $employee_list->Product->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Product" class="<?php echo $employee_list->Product->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $employee_list->SortUrl($employee_list->Product) ?>', 1);"><div id="elh_employee_Product" class="employee_Product">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $employee_list->Product->caption() ?></span><span class="ew-table-header-sort"><?php if ($employee_list->Product->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($employee_list->Product->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$employee_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($employee_list->ExportAll && $employee_list->isExport()) {
	$employee_list->StopRecord = $employee_list->TotalRecords;
} else {

	// Set the last record to display
	if ($employee_list->TotalRecords > $employee_list->StartRecord + $employee_list->DisplayRecords - 1)
		$employee_list->StopRecord = $employee_list->StartRecord + $employee_list->DisplayRecords - 1;
	else
		$employee_list->StopRecord = $employee_list->TotalRecords;
}
$employee_list->RecordCount = $employee_list->StartRecord - 1;
if ($employee_list->Recordset && !$employee_list->Recordset->EOF) {
	$employee_list->Recordset->moveFirst();
	$selectLimit = $employee_list->UseSelectLimit;
	if (!$selectLimit && $employee_list->StartRecord > 1)
		$employee_list->Recordset->move($employee_list->StartRecord - 1);
} elseif (!$employee->AllowAddDeleteRow && $employee_list->StopRecord == 0) {
	$employee_list->StopRecord = $employee->GridAddRowCount;
}

// Initialize aggregate
$employee->RowType = ROWTYPE_AGGREGATEINIT;
$employee->resetAttributes();
$employee_list->renderRow();
while ($employee_list->RecordCount < $employee_list->StopRecord) {
	$employee_list->RecordCount++;
	if ($employee_list->RecordCount >= $employee_list->StartRecord) {
		$employee_list->RowCount++;

		// Set up key count
		$employee_list->KeyCount = $employee_list->RowIndex;

		// Init row class and style
		$employee->resetAttributes();
		$employee->CssClass = "";
		if ($employee_list->isGridAdd()) {
		} else {
			$employee_list->loadRowValues($employee_list->Recordset); // Load row values
		}
		$employee->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$employee->RowAttrs->merge(["data-rowindex" => $employee_list->RowCount, "id" => "r" . $employee_list->RowCount . "_employee", "data-rowtype" => $employee->RowType]);

		// Render row
		$employee_list->renderRow();

		// Render list options
		$employee_list->renderListOptions();
?>
	<tr <?php echo $employee->rowAttributes() ?>>
<?php

// Render list options (body, left)
$employee_list->ListOptions->render("body", "left", $employee_list->RowCount);
?>
	<?php if ($employee_list->Location->Visible) { // Location ?>
		<td data-name="Location" <?php echo $employee_list->Location->cellAttributes() ?>>
<span id="el<?php echo $employee_list->RowCount ?>_employee_Location">
<span<?php echo $employee_list->Location->viewAttributes() ?>><?php echo $employee_list->Location->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($employee_list->Branch->Visible) { // Branch ?>
		<td data-name="Branch" <?php echo $employee_list->Branch->cellAttributes() ?>>
<span id="el<?php echo $employee_list->RowCount ?>_employee_Branch">
<span<?php echo $employee_list->Branch->viewAttributes() ?>><?php echo $employee_list->Branch->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($employee_list->Position->Visible) { // Position ?>
		<td data-name="Position" <?php echo $employee_list->Position->cellAttributes() ?>>
<span id="el<?php echo $employee_list->RowCount ?>_employee_Position">
<span<?php echo $employee_list->Position->viewAttributes() ?>><?php echo $employee_list->Position->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($employee_list->Status->Visible) { // Status ?>
		<td data-name="Status" <?php echo $employee_list->Status->cellAttributes() ?>>
<span id="el<?php echo $employee_list->RowCount ?>_employee_Status">
<span<?php echo $employee_list->Status->viewAttributes() ?>><?php echo $employee_list->Status->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($employee_list->Name->Visible) { // Name ?>
		<td data-name="Name" <?php echo $employee_list->Name->cellAttributes() ?>>
<span id="el<?php echo $employee_list->RowCount ?>_employee_Name">
<span<?php echo $employee_list->Name->viewAttributes() ?>><?php echo $employee_list->Name->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($employee_list->Education->Visible) { // Education ?>
		<td data-name="Education" <?php echo $employee_list->Education->cellAttributes() ?>>
<span id="el<?php echo $employee_list->RowCount ?>_employee_Education">
<span<?php echo $employee_list->Education->viewAttributes() ?>><?php echo $employee_list->Education->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($employee_list->Join->Visible) { // Join ?>
		<td data-name="Join" <?php echo $employee_list->Join->cellAttributes() ?>>
<span id="el<?php echo $employee_list->RowCount ?>_employee_Join">
<span<?php echo $employee_list->Join->viewAttributes() ?>><?php echo $employee_list->Join->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($employee_list->Resign->Visible) { // Resign ?>
		<td data-name="Resign" <?php echo $employee_list->Resign->cellAttributes() ?>>
<span id="el<?php echo $employee_list->RowCount ?>_employee_Resign">
<span<?php echo $employee_list->Resign->viewAttributes() ?>><?php echo $employee_list->Resign->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($employee_list->Product->Visible) { // Product ?>
		<td data-name="Product" <?php echo $employee_list->Product->cellAttributes() ?>>
<span id="el<?php echo $employee_list->RowCount ?>_employee_Product">
<span<?php echo $employee_list->Product->viewAttributes() ?>><?php echo $employee_list->Product->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$employee_list->ListOptions->render("body", "right", $employee_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$employee_list->isGridAdd())
		$employee_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$employee->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($employee_list->Recordset)
	$employee_list->Recordset->Close();
?>
<?php if (!$employee_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$employee_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $employee_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $employee_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($employee_list->TotalRecords == 0 && !$employee->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $employee_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$employee_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$employee_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$employee_list->terminate();
?>