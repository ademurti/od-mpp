<?php
namespace PHPMaker2020\mpp;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$level_view = new level_view();

// Run the page
$level_view->run();

// Setup login status
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$level_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$level_view->isExport()) { ?>
<script>
var flevelview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	flevelview = currentForm = new ew.Form("flevelview", "view");
	loadjs.done("flevelview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$level_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $level_view->ExportOptions->render("body") ?>
<?php $level_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $level_view->showPageHeader(); ?>
<?php
$level_view->showMessage();
?>
<?php if (!$level_view->IsModal) { ?>
<?php if (!$level_view->isExport()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $level_view->Pager->render() ?>
<div class="clearfix"></div>
</form>
<?php } ?>
<?php } ?>
<form name="flevelview" id="flevelview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="level">
<input type="hidden" name="modal" value="<?php echo (int)$level_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($level_view->Level->Visible) { // Level ?>
	<tr id="r_Level">
		<td class="<?php echo $level_view->TableLeftColumnClass ?>"><span id="elh_level_Level"><?php echo $level_view->Level->caption() ?></span></td>
		<td data-name="Level" <?php echo $level_view->Level->cellAttributes() ?>>
<span id="el_level_Level">
<span<?php echo $level_view->Level->viewAttributes() ?>><?php echo $level_view->Level->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
<?php if (!$level_view->IsModal) { ?>
<?php if (!$level_view->isExport()) { ?>
<?php echo $level_view->Pager->render() ?>
<div class="clearfix"></div>
<?php } ?>
<?php } ?>
</form>
<?php
$level_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$level_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$level_view->terminate();
?>