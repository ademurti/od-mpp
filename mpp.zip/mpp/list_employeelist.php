<?php
namespace PHPMaker2020\mpp;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$list_employee_list = new list_employee_list();

// Run the page
$list_employee_list->run();

// Setup login status
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$list_employee_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$list_employee_list->isExport()) { ?>
<script>
var flist_employeelist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	flist_employeelist = currentForm = new ew.Form("flist_employeelist", "list");
	flist_employeelist.formKeyCountName = '<?php echo $list_employee_list->FormKeyCountName ?>';
	loadjs.done("flist_employeelist");
});
var flist_employeelistsrch;
loadjs.ready("head", function() {

	// Form object for search
	flist_employeelistsrch = currentSearchForm = new ew.Form("flist_employeelistsrch");

	// Dynamic selection lists
	// Filters

	flist_employeelistsrch.filterList = <?php echo $list_employee_list->getFilterList() ?>;
	loadjs.done("flist_employeelistsrch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$list_employee_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($list_employee_list->TotalRecords > 0 && $list_employee_list->ExportOptions->visible()) { ?>
<?php $list_employee_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($list_employee_list->ImportOptions->visible()) { ?>
<?php $list_employee_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($list_employee_list->SearchOptions->visible()) { ?>
<?php $list_employee_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($list_employee_list->FilterOptions->visible()) { ?>
<?php $list_employee_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$list_employee_list->renderOtherOptions();
?>
<?php if (!$list_employee_list->isExport() && !$list_employee->CurrentAction) { ?>
<form name="flist_employeelistsrch" id="flist_employeelistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="flist_employeelistsrch-search-panel" class="<?php echo $list_employee_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="list_employee">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $list_employee_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($list_employee_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($list_employee_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $list_employee_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($list_employee_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($list_employee_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($list_employee_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($list_employee_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php $list_employee_list->showPageHeader(); ?>
<?php
$list_employee_list->showMessage();
?>
<?php if ($list_employee_list->TotalRecords > 0 || $list_employee->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($list_employee_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> list_employee">
<?php if (!$list_employee_list->isExport()) { ?>
<div class="card-header ew-grid-upper-panel">
<?php if (!$list_employee_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $list_employee_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $list_employee_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
<form name="flist_employeelist" id="flist_employeelist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="list_employee">
<div id="gmp_list_employee" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($list_employee_list->TotalRecords > 0 || $list_employee_list->isGridEdit()) { ?>
<table id="tbl_list_employeelist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$list_employee->RowType = ROWTYPE_HEADER;

// Render list options
$list_employee_list->renderListOptions();

// Render list options (header, left)
$list_employee_list->ListOptions->render("header", "left");
?>
<?php if ($list_employee_list->Branch->Visible) { // Branch ?>
	<?php if ($list_employee_list->SortUrl($list_employee_list->Branch) == "") { ?>
		<th data-name="Branch" class="<?php echo $list_employee_list->Branch->headerCellClass() ?>"><div id="elh_list_employee_Branch" class="list_employee_Branch"><div class="ew-table-header-caption"><?php echo $list_employee_list->Branch->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Branch" class="<?php echo $list_employee_list->Branch->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $list_employee_list->SortUrl($list_employee_list->Branch) ?>', 1);"><div id="elh_list_employee_Branch" class="list_employee_Branch">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $list_employee_list->Branch->caption() ?></span><span class="ew-table-header-sort"><?php if ($list_employee_list->Branch->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($list_employee_list->Branch->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($list_employee_list->Position->Visible) { // Position ?>
	<?php if ($list_employee_list->SortUrl($list_employee_list->Position) == "") { ?>
		<th data-name="Position" class="<?php echo $list_employee_list->Position->headerCellClass() ?>"><div id="elh_list_employee_Position" class="list_employee_Position"><div class="ew-table-header-caption"><?php echo $list_employee_list->Position->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Position" class="<?php echo $list_employee_list->Position->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $list_employee_list->SortUrl($list_employee_list->Position) ?>', 1);"><div id="elh_list_employee_Position" class="list_employee_Position">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $list_employee_list->Position->caption() ?></span><span class="ew-table-header-sort"><?php if ($list_employee_list->Position->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($list_employee_list->Position->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($list_employee_list->Status->Visible) { // Status ?>
	<?php if ($list_employee_list->SortUrl($list_employee_list->Status) == "") { ?>
		<th data-name="Status" class="<?php echo $list_employee_list->Status->headerCellClass() ?>"><div id="elh_list_employee_Status" class="list_employee_Status"><div class="ew-table-header-caption"><?php echo $list_employee_list->Status->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Status" class="<?php echo $list_employee_list->Status->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $list_employee_list->SortUrl($list_employee_list->Status) ?>', 1);"><div id="elh_list_employee_Status" class="list_employee_Status">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $list_employee_list->Status->caption() ?></span><span class="ew-table-header-sort"><?php if ($list_employee_list->Status->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($list_employee_list->Status->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($list_employee_list->Name->Visible) { // Name ?>
	<?php if ($list_employee_list->SortUrl($list_employee_list->Name) == "") { ?>
		<th data-name="Name" class="<?php echo $list_employee_list->Name->headerCellClass() ?>"><div id="elh_list_employee_Name" class="list_employee_Name"><div class="ew-table-header-caption"><?php echo $list_employee_list->Name->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Name" class="<?php echo $list_employee_list->Name->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $list_employee_list->SortUrl($list_employee_list->Name) ?>', 1);"><div id="elh_list_employee_Name" class="list_employee_Name">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $list_employee_list->Name->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($list_employee_list->Name->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($list_employee_list->Name->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$list_employee_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($list_employee_list->ExportAll && $list_employee_list->isExport()) {
	$list_employee_list->StopRecord = $list_employee_list->TotalRecords;
} else {

	// Set the last record to display
	if ($list_employee_list->TotalRecords > $list_employee_list->StartRecord + $list_employee_list->DisplayRecords - 1)
		$list_employee_list->StopRecord = $list_employee_list->StartRecord + $list_employee_list->DisplayRecords - 1;
	else
		$list_employee_list->StopRecord = $list_employee_list->TotalRecords;
}
$list_employee_list->RecordCount = $list_employee_list->StartRecord - 1;
if ($list_employee_list->Recordset && !$list_employee_list->Recordset->EOF) {
	$list_employee_list->Recordset->moveFirst();
	$selectLimit = $list_employee_list->UseSelectLimit;
	if (!$selectLimit && $list_employee_list->StartRecord > 1)
		$list_employee_list->Recordset->move($list_employee_list->StartRecord - 1);
} elseif (!$list_employee->AllowAddDeleteRow && $list_employee_list->StopRecord == 0) {
	$list_employee_list->StopRecord = $list_employee->GridAddRowCount;
}

// Initialize aggregate
$list_employee->RowType = ROWTYPE_AGGREGATEINIT;
$list_employee->resetAttributes();
$list_employee_list->renderRow();
while ($list_employee_list->RecordCount < $list_employee_list->StopRecord) {
	$list_employee_list->RecordCount++;
	if ($list_employee_list->RecordCount >= $list_employee_list->StartRecord) {
		$list_employee_list->RowCount++;

		// Set up key count
		$list_employee_list->KeyCount = $list_employee_list->RowIndex;

		// Init row class and style
		$list_employee->resetAttributes();
		$list_employee->CssClass = "";
		if ($list_employee_list->isGridAdd()) {
		} else {
			$list_employee_list->loadRowValues($list_employee_list->Recordset); // Load row values
		}
		$list_employee->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$list_employee->RowAttrs->merge(["data-rowindex" => $list_employee_list->RowCount, "id" => "r" . $list_employee_list->RowCount . "_list_employee", "data-rowtype" => $list_employee->RowType]);

		// Render row
		$list_employee_list->renderRow();

		// Render list options
		$list_employee_list->renderListOptions();
?>
	<tr <?php echo $list_employee->rowAttributes() ?>>
<?php

// Render list options (body, left)
$list_employee_list->ListOptions->render("body", "left", $list_employee_list->RowCount);
?>
	<?php if ($list_employee_list->Branch->Visible) { // Branch ?>
		<td data-name="Branch" <?php echo $list_employee_list->Branch->cellAttributes() ?>>
<span id="el<?php echo $list_employee_list->RowCount ?>_list_employee_Branch">
<span<?php echo $list_employee_list->Branch->viewAttributes() ?>><?php echo $list_employee_list->Branch->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($list_employee_list->Position->Visible) { // Position ?>
		<td data-name="Position" <?php echo $list_employee_list->Position->cellAttributes() ?>>
<span id="el<?php echo $list_employee_list->RowCount ?>_list_employee_Position">
<span<?php echo $list_employee_list->Position->viewAttributes() ?>><?php echo $list_employee_list->Position->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($list_employee_list->Status->Visible) { // Status ?>
		<td data-name="Status" <?php echo $list_employee_list->Status->cellAttributes() ?>>
<span id="el<?php echo $list_employee_list->RowCount ?>_list_employee_Status">
<span<?php echo $list_employee_list->Status->viewAttributes() ?>><?php echo $list_employee_list->Status->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($list_employee_list->Name->Visible) { // Name ?>
		<td data-name="Name" <?php echo $list_employee_list->Name->cellAttributes() ?>>
<span id="el<?php echo $list_employee_list->RowCount ?>_list_employee_Name">
<span<?php echo $list_employee_list->Name->viewAttributes() ?>><?php echo $list_employee_list->Name->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$list_employee_list->ListOptions->render("body", "right", $list_employee_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$list_employee_list->isGridAdd())
		$list_employee_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$list_employee->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($list_employee_list->Recordset)
	$list_employee_list->Recordset->Close();
?>
<?php if (!$list_employee_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$list_employee_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $list_employee_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $list_employee_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($list_employee_list->TotalRecords == 0 && !$list_employee->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $list_employee_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$list_employee_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$list_employee_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$list_employee_list->terminate();
?>