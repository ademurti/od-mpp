<?php
namespace PHPMaker2020\mpp;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$fulfilment_list = new fulfilment_list();

// Run the page
$fulfilment_list->run();

// Setup login status
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$fulfilment_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$fulfilment_list->isExport()) { ?>
<script>
var ffulfilmentlist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	ffulfilmentlist = currentForm = new ew.Form("ffulfilmentlist", "list");
	ffulfilmentlist.formKeyCountName = '<?php echo $fulfilment_list->FormKeyCountName ?>';
	loadjs.done("ffulfilmentlist");
});
var ffulfilmentlistsrch;
loadjs.ready("head", function() {

	// Form object for search
	ffulfilmentlistsrch = currentSearchForm = new ew.Form("ffulfilmentlistsrch");

	// Validate function for search
	ffulfilmentlistsrch.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	ffulfilmentlistsrch.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	ffulfilmentlistsrch.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	ffulfilmentlistsrch.lists["x_Branch"] = <?php echo $fulfilment_list->Branch->Lookup->toClientList($fulfilment_list) ?>;
	ffulfilmentlistsrch.lists["x_Branch"].options = <?php echo JsonEncode($fulfilment_list->Branch->lookupOptions()) ?>;
	ffulfilmentlistsrch.lists["x_Position"] = <?php echo $fulfilment_list->Position->Lookup->toClientList($fulfilment_list) ?>;
	ffulfilmentlistsrch.lists["x_Position"].options = <?php echo JsonEncode($fulfilment_list->Position->lookupOptions()) ?>;
	ffulfilmentlistsrch.lists["x_Status[]"] = <?php echo $fulfilment_list->Status->Lookup->toClientList($fulfilment_list) ?>;
	ffulfilmentlistsrch.lists["x_Status[]"].options = <?php echo JsonEncode($fulfilment_list->Status->lookupOptions()) ?>;

	// Filters
	ffulfilmentlistsrch.filterList = <?php echo $fulfilment_list->getFilterList() ?>;
	loadjs.done("ffulfilmentlistsrch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$fulfilment_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($fulfilment_list->TotalRecords > 0 && $fulfilment_list->ExportOptions->visible()) { ?>
<?php $fulfilment_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($fulfilment_list->ImportOptions->visible()) { ?>
<?php $fulfilment_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($fulfilment_list->SearchOptions->visible()) { ?>
<?php $fulfilment_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($fulfilment_list->FilterOptions->visible()) { ?>
<?php $fulfilment_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$fulfilment_list->renderOtherOptions();
?>
<?php if (!$fulfilment_list->isExport() && !$fulfilment->CurrentAction) { ?>
<form name="ffulfilmentlistsrch" id="ffulfilmentlistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="ffulfilmentlistsrch-search-panel" class="<?php echo $fulfilment_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="fulfilment">
	<div class="ew-extended-search">
<?php

// Render search row
$fulfilment->RowType = ROWTYPE_SEARCH;
$fulfilment->resetAttributes();
$fulfilment_list->renderRow();
?>
<?php if ($fulfilment_list->Branch->Visible) { // Branch ?>
	<?php
		$fulfilment_list->SearchColumnCount++;
		if (($fulfilment_list->SearchColumnCount - 1) % $fulfilment_list->SearchFieldsPerRow == 0) {
			$fulfilment_list->SearchRowCount++;
	?>
<div id="xsr_<?php echo $fulfilment_list->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_Branch" class="ew-cell form-group">
		<label for="x_Branch" class="ew-search-caption ew-label"><?php echo $fulfilment_list->Branch->caption() ?></label>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_Branch" id="z_Branch" value="LIKE">
</span>
		<span id="el_fulfilment_Branch" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="fulfilment" data-field="x_Branch" data-value-separator="<?php echo $fulfilment_list->Branch->displayValueSeparatorAttribute() ?>" id="x_Branch" name="x_Branch"<?php echo $fulfilment_list->Branch->editAttributes() ?>>
			<?php echo $fulfilment_list->Branch->selectOptionListHtml("x_Branch") ?>
		</select>
</div>
<?php echo $fulfilment_list->Branch->Lookup->getParamTag($fulfilment_list, "p_x_Branch") ?>
</span>
	</div>
	<?php if ($fulfilment_list->SearchColumnCount % $fulfilment_list->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($fulfilment_list->Position->Visible) { // Position ?>
	<?php
		$fulfilment_list->SearchColumnCount++;
		if (($fulfilment_list->SearchColumnCount - 1) % $fulfilment_list->SearchFieldsPerRow == 0) {
			$fulfilment_list->SearchRowCount++;
	?>
<div id="xsr_<?php echo $fulfilment_list->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_Position" class="ew-cell form-group">
		<label for="x_Position" class="ew-search-caption ew-label"><?php echo $fulfilment_list->Position->caption() ?></label>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_Position" id="z_Position" value="LIKE">
</span>
		<span id="el_fulfilment_Position" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="fulfilment" data-field="x_Position" data-value-separator="<?php echo $fulfilment_list->Position->displayValueSeparatorAttribute() ?>" id="x_Position" name="x_Position"<?php echo $fulfilment_list->Position->editAttributes() ?>>
			<?php echo $fulfilment_list->Position->selectOptionListHtml("x_Position") ?>
		</select>
</div>
<?php echo $fulfilment_list->Position->Lookup->getParamTag($fulfilment_list, "p_x_Position") ?>
</span>
	</div>
	<?php if ($fulfilment_list->SearchColumnCount % $fulfilment_list->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($fulfilment_list->Status->Visible) { // Status ?>
	<?php
		$fulfilment_list->SearchColumnCount++;
		if (($fulfilment_list->SearchColumnCount - 1) % $fulfilment_list->SearchFieldsPerRow == 0) {
			$fulfilment_list->SearchRowCount++;
	?>
<div id="xsr_<?php echo $fulfilment_list->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_Status" class="ew-cell form-group">
		<label class="ew-search-caption ew-label"><?php echo $fulfilment_list->Status->caption() ?></label>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_Status" id="z_Status" value="LIKE">
</span>
		<span id="el_fulfilment_Status" class="ew-search-field">
<div id="tp_x_Status" class="ew-template"><input type="checkbox" class="custom-control-input" data-table="fulfilment" data-field="x_Status" data-value-separator="<?php echo $fulfilment_list->Status->displayValueSeparatorAttribute() ?>" name="x_Status[]" id="x_Status[]" value="{value}"<?php echo $fulfilment_list->Status->editAttributes() ?>></div>
<div id="dsl_x_Status" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $fulfilment_list->Status->checkBoxListHtml(FALSE, "x_Status[]") ?>
</div></div>
<?php echo $fulfilment_list->Status->Lookup->getParamTag($fulfilment_list, "p_x_Status") ?>
</span>
	</div>
	<?php if ($fulfilment_list->SearchColumnCount % $fulfilment_list->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
	<?php if ($fulfilment_list->SearchColumnCount % $fulfilment_list->SearchFieldsPerRow > 0) { ?>
</div>
	<?php } ?>
<div id="xsr_<?php echo $fulfilment_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($fulfilment_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($fulfilment_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $fulfilment_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($fulfilment_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($fulfilment_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($fulfilment_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($fulfilment_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php $fulfilment_list->showPageHeader(); ?>
<?php
$fulfilment_list->showMessage();
?>
<?php if ($fulfilment_list->TotalRecords > 0 || $fulfilment->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($fulfilment_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> fulfilment">
<?php if (!$fulfilment_list->isExport()) { ?>
<div class="card-header ew-grid-upper-panel">
<?php if (!$fulfilment_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $fulfilment_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $fulfilment_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
<form name="ffulfilmentlist" id="ffulfilmentlist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="fulfilment">
<div id="gmp_fulfilment" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($fulfilment_list->TotalRecords > 0 || $fulfilment_list->isGridEdit()) { ?>
<table id="tbl_fulfilmentlist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$fulfilment->RowType = ROWTYPE_HEADER;

// Render list options
$fulfilment_list->renderListOptions();

// Render list options (header, left)
$fulfilment_list->ListOptions->render("header", "left");
?>
<?php if ($fulfilment_list->Branch->Visible) { // Branch ?>
	<?php if ($fulfilment_list->SortUrl($fulfilment_list->Branch) == "") { ?>
		<th data-name="Branch" class="<?php echo $fulfilment_list->Branch->headerCellClass() ?>"><div id="elh_fulfilment_Branch" class="fulfilment_Branch"><div class="ew-table-header-caption"><?php echo $fulfilment_list->Branch->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Branch" class="<?php echo $fulfilment_list->Branch->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $fulfilment_list->SortUrl($fulfilment_list->Branch) ?>', 1);"><div id="elh_fulfilment_Branch" class="fulfilment_Branch">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $fulfilment_list->Branch->caption() ?></span><span class="ew-table-header-sort"><?php if ($fulfilment_list->Branch->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($fulfilment_list->Branch->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($fulfilment_list->Position->Visible) { // Position ?>
	<?php if ($fulfilment_list->SortUrl($fulfilment_list->Position) == "") { ?>
		<th data-name="Position" class="<?php echo $fulfilment_list->Position->headerCellClass() ?>"><div id="elh_fulfilment_Position" class="fulfilment_Position"><div class="ew-table-header-caption"><?php echo $fulfilment_list->Position->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Position" class="<?php echo $fulfilment_list->Position->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $fulfilment_list->SortUrl($fulfilment_list->Position) ?>', 1);"><div id="elh_fulfilment_Position" class="fulfilment_Position">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $fulfilment_list->Position->caption() ?></span><span class="ew-table-header-sort"><?php if ($fulfilment_list->Position->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($fulfilment_list->Position->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($fulfilment_list->Status->Visible) { // Status ?>
	<?php if ($fulfilment_list->SortUrl($fulfilment_list->Status) == "") { ?>
		<th data-name="Status" class="<?php echo $fulfilment_list->Status->headerCellClass() ?>"><div id="elh_fulfilment_Status" class="fulfilment_Status"><div class="ew-table-header-caption"><?php echo $fulfilment_list->Status->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Status" class="<?php echo $fulfilment_list->Status->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $fulfilment_list->SortUrl($fulfilment_list->Status) ?>', 1);"><div id="elh_fulfilment_Status" class="fulfilment_Status">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $fulfilment_list->Status->caption() ?></span><span class="ew-table-header-sort"><?php if ($fulfilment_list->Status->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($fulfilment_list->Status->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($fulfilment_list->MPP->Visible) { // MPP ?>
	<?php if ($fulfilment_list->SortUrl($fulfilment_list->MPP) == "") { ?>
		<th data-name="MPP" class="<?php echo $fulfilment_list->MPP->headerCellClass() ?>"><div id="elh_fulfilment_MPP" class="fulfilment_MPP"><div class="ew-table-header-caption"><?php echo $fulfilment_list->MPP->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="MPP" class="<?php echo $fulfilment_list->MPP->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $fulfilment_list->SortUrl($fulfilment_list->MPP) ?>', 1);"><div id="elh_fulfilment_MPP" class="fulfilment_MPP">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $fulfilment_list->MPP->caption() ?></span><span class="ew-table-header-sort"><?php if ($fulfilment_list->MPP->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($fulfilment_list->MPP->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($fulfilment_list->Current->Visible) { // Current ?>
	<?php if ($fulfilment_list->SortUrl($fulfilment_list->Current) == "") { ?>
		<th data-name="Current" class="<?php echo $fulfilment_list->Current->headerCellClass() ?>"><div id="elh_fulfilment_Current" class="fulfilment_Current"><div class="ew-table-header-caption"><?php echo $fulfilment_list->Current->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Current" class="<?php echo $fulfilment_list->Current->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $fulfilment_list->SortUrl($fulfilment_list->Current) ?>', 1);"><div id="elh_fulfilment_Current" class="fulfilment_Current">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $fulfilment_list->Current->caption() ?></span><span class="ew-table-header-sort"><?php if ($fulfilment_list->Current->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($fulfilment_list->Current->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($fulfilment_list->Lack->Visible) { // Lack ?>
	<?php if ($fulfilment_list->SortUrl($fulfilment_list->Lack) == "") { ?>
		<th data-name="Lack" class="<?php echo $fulfilment_list->Lack->headerCellClass() ?>"><div id="elh_fulfilment_Lack" class="fulfilment_Lack"><div class="ew-table-header-caption"><?php echo $fulfilment_list->Lack->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Lack" class="<?php echo $fulfilment_list->Lack->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $fulfilment_list->SortUrl($fulfilment_list->Lack) ?>', 1);"><div id="elh_fulfilment_Lack" class="fulfilment_Lack">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $fulfilment_list->Lack->caption() ?></span><span class="ew-table-header-sort"><?php if ($fulfilment_list->Lack->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($fulfilment_list->Lack->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$fulfilment_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($fulfilment_list->ExportAll && $fulfilment_list->isExport()) {
	$fulfilment_list->StopRecord = $fulfilment_list->TotalRecords;
} else {

	// Set the last record to display
	if ($fulfilment_list->TotalRecords > $fulfilment_list->StartRecord + $fulfilment_list->DisplayRecords - 1)
		$fulfilment_list->StopRecord = $fulfilment_list->StartRecord + $fulfilment_list->DisplayRecords - 1;
	else
		$fulfilment_list->StopRecord = $fulfilment_list->TotalRecords;
}
$fulfilment_list->RecordCount = $fulfilment_list->StartRecord - 1;
if ($fulfilment_list->Recordset && !$fulfilment_list->Recordset->EOF) {
	$fulfilment_list->Recordset->moveFirst();
	$selectLimit = $fulfilment_list->UseSelectLimit;
	if (!$selectLimit && $fulfilment_list->StartRecord > 1)
		$fulfilment_list->Recordset->move($fulfilment_list->StartRecord - 1);
} elseif (!$fulfilment->AllowAddDeleteRow && $fulfilment_list->StopRecord == 0) {
	$fulfilment_list->StopRecord = $fulfilment->GridAddRowCount;
}

// Initialize aggregate
$fulfilment->RowType = ROWTYPE_AGGREGATEINIT;
$fulfilment->resetAttributes();
$fulfilment_list->renderRow();
while ($fulfilment_list->RecordCount < $fulfilment_list->StopRecord) {
	$fulfilment_list->RecordCount++;
	if ($fulfilment_list->RecordCount >= $fulfilment_list->StartRecord) {
		$fulfilment_list->RowCount++;

		// Set up key count
		$fulfilment_list->KeyCount = $fulfilment_list->RowIndex;

		// Init row class and style
		$fulfilment->resetAttributes();
		$fulfilment->CssClass = "";
		if ($fulfilment_list->isGridAdd()) {
		} else {
			$fulfilment_list->loadRowValues($fulfilment_list->Recordset); // Load row values
		}
		$fulfilment->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$fulfilment->RowAttrs->merge(["data-rowindex" => $fulfilment_list->RowCount, "id" => "r" . $fulfilment_list->RowCount . "_fulfilment", "data-rowtype" => $fulfilment->RowType]);

		// Render row
		$fulfilment_list->renderRow();

		// Render list options
		$fulfilment_list->renderListOptions();
?>
	<tr <?php echo $fulfilment->rowAttributes() ?>>
<?php

// Render list options (body, left)
$fulfilment_list->ListOptions->render("body", "left", $fulfilment_list->RowCount);
?>
	<?php if ($fulfilment_list->Branch->Visible) { // Branch ?>
		<td data-name="Branch" <?php echo $fulfilment_list->Branch->cellAttributes() ?>>
<span id="el<?php echo $fulfilment_list->RowCount ?>_fulfilment_Branch">
<span<?php echo $fulfilment_list->Branch->viewAttributes() ?>><?php echo $fulfilment_list->Branch->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($fulfilment_list->Position->Visible) { // Position ?>
		<td data-name="Position" <?php echo $fulfilment_list->Position->cellAttributes() ?>>
<span id="el<?php echo $fulfilment_list->RowCount ?>_fulfilment_Position">
<span<?php echo $fulfilment_list->Position->viewAttributes() ?>><?php echo $fulfilment_list->Position->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($fulfilment_list->Status->Visible) { // Status ?>
		<td data-name="Status" <?php echo $fulfilment_list->Status->cellAttributes() ?>>
<span id="el<?php echo $fulfilment_list->RowCount ?>_fulfilment_Status">
<span<?php echo $fulfilment_list->Status->viewAttributes() ?>><?php echo $fulfilment_list->Status->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($fulfilment_list->MPP->Visible) { // MPP ?>
		<td data-name="MPP" <?php echo $fulfilment_list->MPP->cellAttributes() ?>>
<span id="el<?php echo $fulfilment_list->RowCount ?>_fulfilment_MPP">
<span<?php echo $fulfilment_list->MPP->viewAttributes() ?>><?php echo $fulfilment_list->MPP->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($fulfilment_list->Current->Visible) { // Current ?>
		<td data-name="Current" <?php echo $fulfilment_list->Current->cellAttributes() ?>>
<span id="el<?php echo $fulfilment_list->RowCount ?>_fulfilment_Current">
<span<?php echo $fulfilment_list->Current->viewAttributes() ?>><?php echo $fulfilment_list->Current->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($fulfilment_list->Lack->Visible) { // Lack ?>
		<td data-name="Lack" <?php echo $fulfilment_list->Lack->cellAttributes() ?>>
<span id="el<?php echo $fulfilment_list->RowCount ?>_fulfilment_Lack">
<span<?php echo $fulfilment_list->Lack->viewAttributes() ?>><?php echo $fulfilment_list->Lack->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$fulfilment_list->ListOptions->render("body", "right", $fulfilment_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$fulfilment_list->isGridAdd())
		$fulfilment_list->Recordset->moveNext();
}
?>
</tbody>
<?php

// Render aggregate row
$fulfilment->RowType = ROWTYPE_AGGREGATE;
$fulfilment->resetAttributes();
$fulfilment_list->renderRow();
?>
<?php if ($fulfilment_list->TotalRecords > 0 && !$fulfilment_list->isGridAdd() && !$fulfilment_list->isGridEdit()) { ?>
<tfoot><!-- Table footer -->
	<tr class="ew-table-footer">
<?php

// Render list options
$fulfilment_list->renderListOptions();

// Render list options (footer, left)
$fulfilment_list->ListOptions->render("footer", "left");
?>
	<?php if ($fulfilment_list->Branch->Visible) { // Branch ?>
		<td data-name="Branch" class="<?php echo $fulfilment_list->Branch->footerCellClass() ?>"><span id="elf_fulfilment_Branch" class="fulfilment_Branch">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($fulfilment_list->Position->Visible) { // Position ?>
		<td data-name="Position" class="<?php echo $fulfilment_list->Position->footerCellClass() ?>"><span id="elf_fulfilment_Position" class="fulfilment_Position">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($fulfilment_list->Status->Visible) { // Status ?>
		<td data-name="Status" class="<?php echo $fulfilment_list->Status->footerCellClass() ?>"><span id="elf_fulfilment_Status" class="fulfilment_Status">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($fulfilment_list->MPP->Visible) { // MPP ?>
		<td data-name="MPP" class="<?php echo $fulfilment_list->MPP->footerCellClass() ?>"><span id="elf_fulfilment_MPP" class="fulfilment_MPP">
		<span class="ew-aggregate"><?php echo $Language->phrase("TOTAL") ?></span><span class="ew-aggregate-value">
		<?php echo $fulfilment_list->MPP->ViewValue ?></span>
		</span></td>
	<?php } ?>
	<?php if ($fulfilment_list->Current->Visible) { // Current ?>
		<td data-name="Current" class="<?php echo $fulfilment_list->Current->footerCellClass() ?>"><span id="elf_fulfilment_Current" class="fulfilment_Current">
		<span class="ew-aggregate"><?php echo $Language->phrase("TOTAL") ?></span><span class="ew-aggregate-value">
		<?php echo $fulfilment_list->Current->ViewValue ?></span>
		</span></td>
	<?php } ?>
	<?php if ($fulfilment_list->Lack->Visible) { // Lack ?>
		<td data-name="Lack" class="<?php echo $fulfilment_list->Lack->footerCellClass() ?>"><span id="elf_fulfilment_Lack" class="fulfilment_Lack">
		<span class="ew-aggregate"><?php echo $Language->phrase("TOTAL") ?></span><span class="ew-aggregate-value">
		<?php echo $fulfilment_list->Lack->ViewValue ?></span>
		</span></td>
	<?php } ?>
<?php

// Render list options (footer, right)
$fulfilment_list->ListOptions->render("footer", "right");
?>
	</tr>
</tfoot>
<?php } ?>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$fulfilment->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($fulfilment_list->Recordset)
	$fulfilment_list->Recordset->Close();
?>
<?php if (!$fulfilment_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$fulfilment_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $fulfilment_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $fulfilment_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($fulfilment_list->TotalRecords == 0 && !$fulfilment->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $fulfilment_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$fulfilment_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$fulfilment_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$fulfilment_list->terminate();
?>