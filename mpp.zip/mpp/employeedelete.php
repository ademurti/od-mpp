<?php
namespace PHPMaker2020\mpp;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$employee_delete = new employee_delete();

// Run the page
$employee_delete->run();

// Setup login status
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$employee_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var femployeedelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	femployeedelete = currentForm = new ew.Form("femployeedelete", "delete");
	loadjs.done("femployeedelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $employee_delete->showPageHeader(); ?>
<?php
$employee_delete->showMessage();
?>
<form name="femployeedelete" id="femployeedelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="employee">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($employee_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($employee_delete->Location->Visible) { // Location ?>
		<th class="<?php echo $employee_delete->Location->headerCellClass() ?>"><span id="elh_employee_Location" class="employee_Location"><?php echo $employee_delete->Location->caption() ?></span></th>
<?php } ?>
<?php if ($employee_delete->Branch->Visible) { // Branch ?>
		<th class="<?php echo $employee_delete->Branch->headerCellClass() ?>"><span id="elh_employee_Branch" class="employee_Branch"><?php echo $employee_delete->Branch->caption() ?></span></th>
<?php } ?>
<?php if ($employee_delete->Position->Visible) { // Position ?>
		<th class="<?php echo $employee_delete->Position->headerCellClass() ?>"><span id="elh_employee_Position" class="employee_Position"><?php echo $employee_delete->Position->caption() ?></span></th>
<?php } ?>
<?php if ($employee_delete->Status->Visible) { // Status ?>
		<th class="<?php echo $employee_delete->Status->headerCellClass() ?>"><span id="elh_employee_Status" class="employee_Status"><?php echo $employee_delete->Status->caption() ?></span></th>
<?php } ?>
<?php if ($employee_delete->Name->Visible) { // Name ?>
		<th class="<?php echo $employee_delete->Name->headerCellClass() ?>"><span id="elh_employee_Name" class="employee_Name"><?php echo $employee_delete->Name->caption() ?></span></th>
<?php } ?>
<?php if ($employee_delete->Education->Visible) { // Education ?>
		<th class="<?php echo $employee_delete->Education->headerCellClass() ?>"><span id="elh_employee_Education" class="employee_Education"><?php echo $employee_delete->Education->caption() ?></span></th>
<?php } ?>
<?php if ($employee_delete->Join->Visible) { // Join ?>
		<th class="<?php echo $employee_delete->Join->headerCellClass() ?>"><span id="elh_employee_Join" class="employee_Join"><?php echo $employee_delete->Join->caption() ?></span></th>
<?php } ?>
<?php if ($employee_delete->Resign->Visible) { // Resign ?>
		<th class="<?php echo $employee_delete->Resign->headerCellClass() ?>"><span id="elh_employee_Resign" class="employee_Resign"><?php echo $employee_delete->Resign->caption() ?></span></th>
<?php } ?>
<?php if ($employee_delete->Product->Visible) { // Product ?>
		<th class="<?php echo $employee_delete->Product->headerCellClass() ?>"><span id="elh_employee_Product" class="employee_Product"><?php echo $employee_delete->Product->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$employee_delete->RecordCount = 0;
$i = 0;
while (!$employee_delete->Recordset->EOF) {
	$employee_delete->RecordCount++;
	$employee_delete->RowCount++;

	// Set row properties
	$employee->resetAttributes();
	$employee->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$employee_delete->loadRowValues($employee_delete->Recordset);

	// Render row
	$employee_delete->renderRow();
?>
	<tr <?php echo $employee->rowAttributes() ?>>
<?php if ($employee_delete->Location->Visible) { // Location ?>
		<td <?php echo $employee_delete->Location->cellAttributes() ?>>
<span id="el<?php echo $employee_delete->RowCount ?>_employee_Location" class="employee_Location">
<span<?php echo $employee_delete->Location->viewAttributes() ?>><?php echo $employee_delete->Location->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($employee_delete->Branch->Visible) { // Branch ?>
		<td <?php echo $employee_delete->Branch->cellAttributes() ?>>
<span id="el<?php echo $employee_delete->RowCount ?>_employee_Branch" class="employee_Branch">
<span<?php echo $employee_delete->Branch->viewAttributes() ?>><?php echo $employee_delete->Branch->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($employee_delete->Position->Visible) { // Position ?>
		<td <?php echo $employee_delete->Position->cellAttributes() ?>>
<span id="el<?php echo $employee_delete->RowCount ?>_employee_Position" class="employee_Position">
<span<?php echo $employee_delete->Position->viewAttributes() ?>><?php echo $employee_delete->Position->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($employee_delete->Status->Visible) { // Status ?>
		<td <?php echo $employee_delete->Status->cellAttributes() ?>>
<span id="el<?php echo $employee_delete->RowCount ?>_employee_Status" class="employee_Status">
<span<?php echo $employee_delete->Status->viewAttributes() ?>><?php echo $employee_delete->Status->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($employee_delete->Name->Visible) { // Name ?>
		<td <?php echo $employee_delete->Name->cellAttributes() ?>>
<span id="el<?php echo $employee_delete->RowCount ?>_employee_Name" class="employee_Name">
<span<?php echo $employee_delete->Name->viewAttributes() ?>><?php echo $employee_delete->Name->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($employee_delete->Education->Visible) { // Education ?>
		<td <?php echo $employee_delete->Education->cellAttributes() ?>>
<span id="el<?php echo $employee_delete->RowCount ?>_employee_Education" class="employee_Education">
<span<?php echo $employee_delete->Education->viewAttributes() ?>><?php echo $employee_delete->Education->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($employee_delete->Join->Visible) { // Join ?>
		<td <?php echo $employee_delete->Join->cellAttributes() ?>>
<span id="el<?php echo $employee_delete->RowCount ?>_employee_Join" class="employee_Join">
<span<?php echo $employee_delete->Join->viewAttributes() ?>><?php echo $employee_delete->Join->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($employee_delete->Resign->Visible) { // Resign ?>
		<td <?php echo $employee_delete->Resign->cellAttributes() ?>>
<span id="el<?php echo $employee_delete->RowCount ?>_employee_Resign" class="employee_Resign">
<span<?php echo $employee_delete->Resign->viewAttributes() ?>><?php echo $employee_delete->Resign->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($employee_delete->Product->Visible) { // Product ?>
		<td <?php echo $employee_delete->Product->cellAttributes() ?>>
<span id="el<?php echo $employee_delete->RowCount ?>_employee_Product" class="employee_Product">
<span<?php echo $employee_delete->Product->viewAttributes() ?>><?php echo $employee_delete->Product->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$employee_delete->Recordset->moveNext();
}
$employee_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $employee_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$employee_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$employee_delete->terminate();
?>