<?php
namespace PHPMaker2020\mpp;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$employee_edit = new employee_edit();

// Run the page
$employee_edit->run();

// Setup login status
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$employee_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var femployeeedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	femployeeedit = currentForm = new ew.Form("femployeeedit", "edit");

	// Validate form
	femployeeedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "F")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($employee_edit->Location->Required) { ?>
				elm = this.getElements("x" + infix + "_Location");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $employee_edit->Location->caption(), $employee_edit->Location->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($employee_edit->Branch->Required) { ?>
				elm = this.getElements("x" + infix + "_Branch");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $employee_edit->Branch->caption(), $employee_edit->Branch->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($employee_edit->Position->Required) { ?>
				elm = this.getElements("x" + infix + "_Position");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $employee_edit->Position->caption(), $employee_edit->Position->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($employee_edit->Status->Required) { ?>
				elm = this.getElements("x" + infix + "_Status");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $employee_edit->Status->caption(), $employee_edit->Status->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($employee_edit->Name->Required) { ?>
				elm = this.getElements("x" + infix + "_Name");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $employee_edit->Name->caption(), $employee_edit->Name->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($employee_edit->Education->Required) { ?>
				elm = this.getElements("x" + infix + "_Education");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $employee_edit->Education->caption(), $employee_edit->Education->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($employee_edit->Join->Required) { ?>
				elm = this.getElements("x" + infix + "_Join");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $employee_edit->Join->caption(), $employee_edit->Join->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_Join");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($employee_edit->Join->errorMessage()) ?>");
			<?php if ($employee_edit->Resign->Required) { ?>
				elm = this.getElements("x" + infix + "_Resign");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $employee_edit->Resign->caption(), $employee_edit->Resign->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_Resign");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($employee_edit->Resign->errorMessage()) ?>");
			<?php if ($employee_edit->Product->Required) { ?>
				elm = this.getElements("x" + infix + "_Product[]");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $employee_edit->Product->caption(), $employee_edit->Product->RequiredErrorMessage)) ?>");
			<?php } ?>

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	femployeeedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	femployeeedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	femployeeedit.lists["x_Location"] = <?php echo $employee_edit->Location->Lookup->toClientList($employee_edit) ?>;
	femployeeedit.lists["x_Location"].options = <?php echo JsonEncode($employee_edit->Location->lookupOptions()) ?>;
	femployeeedit.lists["x_Branch"] = <?php echo $employee_edit->Branch->Lookup->toClientList($employee_edit) ?>;
	femployeeedit.lists["x_Branch"].options = <?php echo JsonEncode($employee_edit->Branch->lookupOptions()) ?>;
	femployeeedit.lists["x_Position"] = <?php echo $employee_edit->Position->Lookup->toClientList($employee_edit) ?>;
	femployeeedit.lists["x_Position"].options = <?php echo JsonEncode($employee_edit->Position->lookupOptions()) ?>;
	femployeeedit.lists["x_Status"] = <?php echo $employee_edit->Status->Lookup->toClientList($employee_edit) ?>;
	femployeeedit.lists["x_Status"].options = <?php echo JsonEncode($employee_edit->Status->lookupOptions()) ?>;
	femployeeedit.lists["x_Education"] = <?php echo $employee_edit->Education->Lookup->toClientList($employee_edit) ?>;
	femployeeedit.lists["x_Education"].options = <?php echo JsonEncode($employee_edit->Education->lookupOptions()) ?>;
	femployeeedit.lists["x_Product[]"] = <?php echo $employee_edit->Product->Lookup->toClientList($employee_edit) ?>;
	femployeeedit.lists["x_Product[]"].options = <?php echo JsonEncode($employee_edit->Product->lookupOptions()) ?>;
	loadjs.done("femployeeedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $employee_edit->showPageHeader(); ?>
<?php
$employee_edit->showMessage();
?>
<?php if (!$employee_edit->IsModal) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $employee_edit->Pager->render() ?>
<div class="clearfix"></div>
</form>
<?php } ?>
<form name="femployeeedit" id="femployeeedit" class="<?php echo $employee_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="employee">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$employee_edit->IsModal ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($employee_edit->Location->Visible) { // Location ?>
	<div id="r_Location" class="form-group row">
		<label id="elh_employee_Location" for="x_Location" class="<?php echo $employee_edit->LeftColumnClass ?>"><?php echo $employee_edit->Location->caption() ?><?php echo $employee_edit->Location->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $employee_edit->RightColumnClass ?>"><div <?php echo $employee_edit->Location->cellAttributes() ?>>
<span id="el_employee_Location">
<?php $employee_edit->Location->EditAttrs->prepend("onchange", "ew.updateOptions.call(this);"); ?>
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="employee" data-field="x_Location" data-value-separator="<?php echo $employee_edit->Location->displayValueSeparatorAttribute() ?>" id="x_Location" name="x_Location"<?php echo $employee_edit->Location->editAttributes() ?>>
			<?php echo $employee_edit->Location->selectOptionListHtml("x_Location") ?>
		</select>
	<div class="input-group-append"><button type="button" class="btn btn-default ew-add-opt-btn" id="aol_x_Location" title="<?php echo HtmlTitle($Language->phrase("AddLink")) . "&nbsp;" . $employee_edit->Location->caption() ?>" data-title="<?php echo $employee_edit->Location->caption() ?>" onclick="ew.addOptionDialogShow({lnk:this,el:'x_Location',url:'mppaddopt.php'});"><i class="fas fa-plus ew-icon"></i></button></div>
</div>
<?php echo $employee_edit->Location->Lookup->getParamTag($employee_edit, "p_x_Location") ?>
</span>
<?php echo $employee_edit->Location->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($employee_edit->Branch->Visible) { // Branch ?>
	<div id="r_Branch" class="form-group row">
		<label id="elh_employee_Branch" for="x_Branch" class="<?php echo $employee_edit->LeftColumnClass ?>"><?php echo $employee_edit->Branch->caption() ?><?php echo $employee_edit->Branch->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $employee_edit->RightColumnClass ?>"><div <?php echo $employee_edit->Branch->cellAttributes() ?>>
<span id="el_employee_Branch">
<?php $employee_edit->Branch->EditAttrs->prepend("onchange", "ew.updateOptions.call(this);"); ?>
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="employee" data-field="x_Branch" data-value-separator="<?php echo $employee_edit->Branch->displayValueSeparatorAttribute() ?>" id="x_Branch" name="x_Branch"<?php echo $employee_edit->Branch->editAttributes() ?>>
			<?php echo $employee_edit->Branch->selectOptionListHtml("x_Branch") ?>
		</select>
</div>
<?php echo $employee_edit->Branch->Lookup->getParamTag($employee_edit, "p_x_Branch") ?>
</span>
<?php echo $employee_edit->Branch->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($employee_edit->Position->Visible) { // Position ?>
	<div id="r_Position" class="form-group row">
		<label id="elh_employee_Position" for="x_Position" class="<?php echo $employee_edit->LeftColumnClass ?>"><?php echo $employee_edit->Position->caption() ?><?php echo $employee_edit->Position->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $employee_edit->RightColumnClass ?>"><div <?php echo $employee_edit->Position->cellAttributes() ?>>
<span id="el_employee_Position">
<?php $employee_edit->Position->EditAttrs->prepend("onchange", "ew.updateOptions.call(this);"); ?>
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="employee" data-field="x_Position" data-value-separator="<?php echo $employee_edit->Position->displayValueSeparatorAttribute() ?>" id="x_Position" name="x_Position"<?php echo $employee_edit->Position->editAttributes() ?>>
			<?php echo $employee_edit->Position->selectOptionListHtml("x_Position") ?>
		</select>
</div>
<?php echo $employee_edit->Position->Lookup->getParamTag($employee_edit, "p_x_Position") ?>
</span>
<?php echo $employee_edit->Position->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($employee_edit->Status->Visible) { // Status ?>
	<div id="r_Status" class="form-group row">
		<label id="elh_employee_Status" for="x_Status" class="<?php echo $employee_edit->LeftColumnClass ?>"><?php echo $employee_edit->Status->caption() ?><?php echo $employee_edit->Status->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $employee_edit->RightColumnClass ?>"><div <?php echo $employee_edit->Status->cellAttributes() ?>>
<span id="el_employee_Status">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="employee" data-field="x_Status" data-value-separator="<?php echo $employee_edit->Status->displayValueSeparatorAttribute() ?>" id="x_Status" name="x_Status"<?php echo $employee_edit->Status->editAttributes() ?>>
			<?php echo $employee_edit->Status->selectOptionListHtml("x_Status") ?>
		</select>
</div>
<?php echo $employee_edit->Status->Lookup->getParamTag($employee_edit, "p_x_Status") ?>
</span>
<?php echo $employee_edit->Status->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($employee_edit->Name->Visible) { // Name ?>
	<div id="r_Name" class="form-group row">
		<label id="elh_employee_Name" for="x_Name" class="<?php echo $employee_edit->LeftColumnClass ?>"><?php echo $employee_edit->Name->caption() ?><?php echo $employee_edit->Name->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $employee_edit->RightColumnClass ?>"><div <?php echo $employee_edit->Name->cellAttributes() ?>>
<span id="el_employee_Name">
<input type="text" data-table="employee" data-field="x_Name" name="x_Name" id="x_Name" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($employee_edit->Name->getPlaceHolder()) ?>" value="<?php echo $employee_edit->Name->EditValue ?>"<?php echo $employee_edit->Name->editAttributes() ?>>
</span>
<?php echo $employee_edit->Name->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($employee_edit->Education->Visible) { // Education ?>
	<div id="r_Education" class="form-group row">
		<label id="elh_employee_Education" class="<?php echo $employee_edit->LeftColumnClass ?>"><?php echo $employee_edit->Education->caption() ?><?php echo $employee_edit->Education->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $employee_edit->RightColumnClass ?>"><div <?php echo $employee_edit->Education->cellAttributes() ?>>
<span id="el_employee_Education">
<div id="tp_x_Education" class="ew-template"><input type="radio" class="custom-control-input" data-table="employee" data-field="x_Education" data-value-separator="<?php echo $employee_edit->Education->displayValueSeparatorAttribute() ?>" name="x_Education" id="x_Education" value="{value}"<?php echo $employee_edit->Education->editAttributes() ?>></div>
<div id="dsl_x_Education" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $employee_edit->Education->radioButtonListHtml(FALSE, "x_Education") ?>
</div></div>
<?php echo $employee_edit->Education->Lookup->getParamTag($employee_edit, "p_x_Education") ?>
</span>
<?php echo $employee_edit->Education->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($employee_edit->Join->Visible) { // Join ?>
	<div id="r_Join" class="form-group row">
		<label id="elh_employee_Join" for="x_Join" class="<?php echo $employee_edit->LeftColumnClass ?>"><?php echo $employee_edit->Join->caption() ?><?php echo $employee_edit->Join->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $employee_edit->RightColumnClass ?>"><div <?php echo $employee_edit->Join->cellAttributes() ?>>
<span id="el_employee_Join">
<input type="text" data-table="employee" data-field="x_Join" name="x_Join" id="x_Join" maxlength="10" placeholder="<?php echo HtmlEncode($employee_edit->Join->getPlaceHolder()) ?>" value="<?php echo $employee_edit->Join->EditValue ?>"<?php echo $employee_edit->Join->editAttributes() ?>>
<?php if (!$employee_edit->Join->ReadOnly && !$employee_edit->Join->Disabled && !isset($employee_edit->Join->EditAttrs["readonly"]) && !isset($employee_edit->Join->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["femployeeedit", "datetimepicker"], function() {
	ew.createDateTimePicker("femployeeedit", "x_Join", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $employee_edit->Join->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($employee_edit->Resign->Visible) { // Resign ?>
	<div id="r_Resign" class="form-group row">
		<label id="elh_employee_Resign" for="x_Resign" class="<?php echo $employee_edit->LeftColumnClass ?>"><?php echo $employee_edit->Resign->caption() ?><?php echo $employee_edit->Resign->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $employee_edit->RightColumnClass ?>"><div <?php echo $employee_edit->Resign->cellAttributes() ?>>
<span id="el_employee_Resign">
<input type="text" data-table="employee" data-field="x_Resign" name="x_Resign" id="x_Resign" maxlength="10" placeholder="<?php echo HtmlEncode($employee_edit->Resign->getPlaceHolder()) ?>" value="<?php echo $employee_edit->Resign->EditValue ?>"<?php echo $employee_edit->Resign->editAttributes() ?>>
<?php if (!$employee_edit->Resign->ReadOnly && !$employee_edit->Resign->Disabled && !isset($employee_edit->Resign->EditAttrs["readonly"]) && !isset($employee_edit->Resign->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["femployeeedit", "datetimepicker"], function() {
	ew.createDateTimePicker("femployeeedit", "x_Resign", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $employee_edit->Resign->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($employee_edit->Product->Visible) { // Product ?>
	<div id="r_Product" class="form-group row">
		<label id="elh_employee_Product" class="<?php echo $employee_edit->LeftColumnClass ?>"><?php echo $employee_edit->Product->caption() ?><?php echo $employee_edit->Product->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $employee_edit->RightColumnClass ?>"><div <?php echo $employee_edit->Product->cellAttributes() ?>>
<span id="el_employee_Product">
<div id="tp_x_Product" class="ew-template"><input type="checkbox" class="custom-control-input" data-table="employee" data-field="x_Product" data-value-separator="<?php echo $employee_edit->Product->displayValueSeparatorAttribute() ?>" name="x_Product[]" id="x_Product[]" value="{value}"<?php echo $employee_edit->Product->editAttributes() ?>></div>
<div id="dsl_x_Product" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $employee_edit->Product->checkBoxListHtml(FALSE, "x_Product[]") ?>
</div></div>
<?php echo $employee_edit->Product->Lookup->getParamTag($employee_edit, "p_x_Product") ?>
</span>
<?php echo $employee_edit->Product->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
	<input type="hidden" data-table="employee" data-field="x_empID" name="x_empID" id="x_empID" value="<?php echo HtmlEncode($employee_edit->empID->CurrentValue) ?>">
<?php if (!$employee_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $employee_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $employee_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
<?php if (!$employee_edit->IsModal) { ?>
<?php echo $employee_edit->Pager->render() ?>
<div class="clearfix"></div>
<?php } ?>
</form>
<?php
$employee_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$employee_edit->terminate();
?>