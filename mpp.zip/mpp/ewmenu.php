<?php
namespace PHPMaker2020\mpp;

// Menu Language
if ($Language && function_exists(PROJECT_NAMESPACE . "Config") && $Language->LanguageFolder == Config("LANGUAGE_FOLDER")) {
	$MenuRelativePath = "";
	$MenuLanguage = &$Language;
} else { // Compat reports
	$LANGUAGE_FOLDER = "../lang/";
	$MenuRelativePath = "../";
	$MenuLanguage = new Language();
}

// Navbar menu
$topMenu = new Menu("navbar", TRUE, TRUE);
$topMenu->addMenuItem(1, "mi_mpp", $MenuLanguage->MenuPhrase("1", "MenuText"), $MenuRelativePath . "mpplist.php", -1, "", TRUE, FALSE, FALSE, "", "", TRUE);
$topMenu->addMenuItem(24, "mi_employee", $MenuLanguage->MenuPhrase("24", "MenuText"), $MenuRelativePath . "employeelist.php", -1, "", TRUE, FALSE, FALSE, "", "", TRUE);
$topMenu->addMenuItem(22, "mci_Report", $MenuLanguage->MenuPhrase("22", "MenuText"), "", -1, "", TRUE, FALSE, TRUE, "", "", TRUE);
$topMenu->addMenuItem(23, "mi_Branch_MPP", $MenuLanguage->MenuPhrase("23", "MenuText"), $MenuRelativePath . "Branch_MPPctb.php", 22, "", TRUE, FALSE, FALSE, "", "", TRUE);
$topMenu->addMenuItem(8, "mi__MPP_List", $MenuLanguage->MenuPhrase("8", "MenuText"), $MenuRelativePath . "_MPP_Listsmry.php", 22, "", TRUE, FALSE, FALSE, "", "", TRUE);
$topMenu->addMenuItem(12, "mi_MPP_Position", $MenuLanguage->MenuPhrase("12", "MenuText"), $MenuRelativePath . "MPP_Positionctb.php", 22, "", TRUE, FALSE, FALSE, "", "", TRUE);
$topMenu->addMenuItem(30, "mi_Fulfilment", $MenuLanguage->MenuPhrase("30", "MenuText"), $MenuRelativePath . "Fulfilmentsmry.php", 22, "", TRUE, FALSE, FALSE, "", "", TRUE);
$topMenu->addMenuItem(6, "mci_Master", $MenuLanguage->MenuPhrase("6", "MenuText"), "", -1, "", TRUE, FALSE, TRUE, "", "", TRUE);
$topMenu->addMenuItem(3, "mi_branch", $MenuLanguage->MenuPhrase("3", "MenuText"), $MenuRelativePath . "branchlist.php", 6, "", TRUE, FALSE, FALSE, "", "", TRUE);
$topMenu->addMenuItem(27, "mi_education", $MenuLanguage->MenuPhrase("27", "MenuText"), $MenuRelativePath . "educationlist.php", 6, "", TRUE, FALSE, FALSE, "", "", TRUE);
$topMenu->addMenuItem(25, "mi_level", $MenuLanguage->MenuPhrase("25", "MenuText"), $MenuRelativePath . "levellist.php", 6, "", TRUE, FALSE, FALSE, "", "", TRUE);
$topMenu->addMenuItem(4, "mi_position", $MenuLanguage->MenuPhrase("4", "MenuText"), $MenuRelativePath . "positionlist.php", 6, "", TRUE, FALSE, FALSE, "", "", TRUE);
$topMenu->addMenuItem(26, "mi_product", $MenuLanguage->MenuPhrase("26", "MenuText"), $MenuRelativePath . "productlist.php", 6, "", TRUE, FALSE, FALSE, "", "", TRUE);
$topMenu->addMenuItem(5, "mi_status", $MenuLanguage->MenuPhrase("5", "MenuText"), $MenuRelativePath . "statuslist.php", 6, "", TRUE, FALSE, FALSE, "", "", TRUE);
echo $topMenu->toScript();

// Sidebar menu
$sideMenu = new Menu("menu", TRUE, FALSE);
$sideMenu->addMenuItem(1, "mi_mpp", $MenuLanguage->MenuPhrase("1", "MenuText"), $MenuRelativePath . "mpplist.php", -1, "", TRUE, FALSE, FALSE, "", "", TRUE);
$sideMenu->addMenuItem(24, "mi_employee", $MenuLanguage->MenuPhrase("24", "MenuText"), $MenuRelativePath . "employeelist.php", -1, "", TRUE, FALSE, FALSE, "", "", TRUE);
$sideMenu->addMenuItem(22, "mci_Report", $MenuLanguage->MenuPhrase("22", "MenuText"), "", -1, "", TRUE, FALSE, TRUE, "", "", TRUE);
$sideMenu->addMenuItem(23, "mi_Branch_MPP", $MenuLanguage->MenuPhrase("23", "MenuText"), $MenuRelativePath . "Branch_MPPctb.php", 22, "", TRUE, FALSE, FALSE, "", "", TRUE);
$sideMenu->addMenuItem(8, "mi__MPP_List", $MenuLanguage->MenuPhrase("8", "MenuText"), $MenuRelativePath . "_MPP_Listsmry.php", 22, "", TRUE, FALSE, FALSE, "", "", TRUE);
$sideMenu->addMenuItem(12, "mi_MPP_Position", $MenuLanguage->MenuPhrase("12", "MenuText"), $MenuRelativePath . "MPP_Positionctb.php", 22, "", TRUE, FALSE, FALSE, "", "", TRUE);
$sideMenu->addMenuItem(30, "mi_Fulfilment", $MenuLanguage->MenuPhrase("30", "MenuText"), $MenuRelativePath . "Fulfilmentsmry.php", 22, "", TRUE, FALSE, FALSE, "", "", TRUE);
$sideMenu->addMenuItem(6, "mci_Master", $MenuLanguage->MenuPhrase("6", "MenuText"), "", -1, "", TRUE, FALSE, TRUE, "", "", TRUE);
$sideMenu->addMenuItem(3, "mi_branch", $MenuLanguage->MenuPhrase("3", "MenuText"), $MenuRelativePath . "branchlist.php", 6, "", TRUE, FALSE, FALSE, "", "", TRUE);
$sideMenu->addMenuItem(27, "mi_education", $MenuLanguage->MenuPhrase("27", "MenuText"), $MenuRelativePath . "educationlist.php", 6, "", TRUE, FALSE, FALSE, "", "", TRUE);
$sideMenu->addMenuItem(25, "mi_level", $MenuLanguage->MenuPhrase("25", "MenuText"), $MenuRelativePath . "levellist.php", 6, "", TRUE, FALSE, FALSE, "", "", TRUE);
$sideMenu->addMenuItem(4, "mi_position", $MenuLanguage->MenuPhrase("4", "MenuText"), $MenuRelativePath . "positionlist.php", 6, "", TRUE, FALSE, FALSE, "", "", TRUE);
$sideMenu->addMenuItem(26, "mi_product", $MenuLanguage->MenuPhrase("26", "MenuText"), $MenuRelativePath . "productlist.php", 6, "", TRUE, FALSE, FALSE, "", "", TRUE);
$sideMenu->addMenuItem(5, "mi_status", $MenuLanguage->MenuPhrase("5", "MenuText"), $MenuRelativePath . "statuslist.php", 6, "", TRUE, FALSE, FALSE, "", "", TRUE);
echo $sideMenu->toScript();
?>