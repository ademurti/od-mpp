<?php
namespace PHPMaker2020\mpp;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$branch_delete = new branch_delete();

// Run the page
$branch_delete->run();

// Setup login status
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$branch_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fbranchdelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	fbranchdelete = currentForm = new ew.Form("fbranchdelete", "delete");
	loadjs.done("fbranchdelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $branch_delete->showPageHeader(); ?>
<?php
$branch_delete->showMessage();
?>
<form name="fbranchdelete" id="fbranchdelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="branch">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($branch_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($branch_delete->Location->Visible) { // Location ?>
		<th class="<?php echo $branch_delete->Location->headerCellClass() ?>"><span id="elh_branch_Location" class="branch_Location"><?php echo $branch_delete->Location->caption() ?></span></th>
<?php } ?>
<?php if ($branch_delete->Branch->Visible) { // Branch ?>
		<th class="<?php echo $branch_delete->Branch->headerCellClass() ?>"><span id="elh_branch_Branch" class="branch_Branch"><?php echo $branch_delete->Branch->caption() ?></span></th>
<?php } ?>
<?php if ($branch_delete->Region->Visible) { // Region ?>
		<th class="<?php echo $branch_delete->Region->headerCellClass() ?>"><span id="elh_branch_Region" class="branch_Region"><?php echo $branch_delete->Region->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$branch_delete->RecordCount = 0;
$i = 0;
while (!$branch_delete->Recordset->EOF) {
	$branch_delete->RecordCount++;
	$branch_delete->RowCount++;

	// Set row properties
	$branch->resetAttributes();
	$branch->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$branch_delete->loadRowValues($branch_delete->Recordset);

	// Render row
	$branch_delete->renderRow();
?>
	<tr <?php echo $branch->rowAttributes() ?>>
<?php if ($branch_delete->Location->Visible) { // Location ?>
		<td <?php echo $branch_delete->Location->cellAttributes() ?>>
<span id="el<?php echo $branch_delete->RowCount ?>_branch_Location" class="branch_Location">
<span<?php echo $branch_delete->Location->viewAttributes() ?>><?php echo $branch_delete->Location->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($branch_delete->Branch->Visible) { // Branch ?>
		<td <?php echo $branch_delete->Branch->cellAttributes() ?>>
<span id="el<?php echo $branch_delete->RowCount ?>_branch_Branch" class="branch_Branch">
<span<?php echo $branch_delete->Branch->viewAttributes() ?>><?php echo $branch_delete->Branch->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($branch_delete->Region->Visible) { // Region ?>
		<td <?php echo $branch_delete->Region->cellAttributes() ?>>
<span id="el<?php echo $branch_delete->RowCount ?>_branch_Region" class="branch_Region">
<span<?php echo $branch_delete->Region->viewAttributes() ?>><?php echo $branch_delete->Region->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$branch_delete->Recordset->moveNext();
}
$branch_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $branch_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$branch_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$branch_delete->terminate();
?>