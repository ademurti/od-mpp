<?php
namespace PHPMaker2020\mpp;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$education_view = new education_view();

// Run the page
$education_view->run();

// Setup login status
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$education_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$education_view->isExport()) { ?>
<script>
var feducationview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	feducationview = currentForm = new ew.Form("feducationview", "view");
	loadjs.done("feducationview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$education_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $education_view->ExportOptions->render("body") ?>
<?php $education_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $education_view->showPageHeader(); ?>
<?php
$education_view->showMessage();
?>
<?php if (!$education_view->IsModal) { ?>
<?php if (!$education_view->isExport()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $education_view->Pager->render() ?>
<div class="clearfix"></div>
</form>
<?php } ?>
<?php } ?>
<form name="feducationview" id="feducationview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="education">
<input type="hidden" name="modal" value="<?php echo (int)$education_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($education_view->Education->Visible) { // Education ?>
	<tr id="r_Education">
		<td class="<?php echo $education_view->TableLeftColumnClass ?>"><span id="elh_education_Education"><?php echo $education_view->Education->caption() ?></span></td>
		<td data-name="Education" <?php echo $education_view->Education->cellAttributes() ?>>
<span id="el_education_Education">
<span<?php echo $education_view->Education->viewAttributes() ?>><?php echo $education_view->Education->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
<?php if (!$education_view->IsModal) { ?>
<?php if (!$education_view->isExport()) { ?>
<?php echo $education_view->Pager->render() ?>
<div class="clearfix"></div>
<?php } ?>
<?php } ?>
</form>
<?php
$education_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$education_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$education_view->terminate();
?>