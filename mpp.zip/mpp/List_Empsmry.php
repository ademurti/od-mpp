<?php
namespace PHPMaker2020\mpp;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$List_Emp_summary = new List_Emp_summary();

// Run the page
$List_Emp_summary->run();

// Setup login status
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$List_Emp_summary->Page_Render();
?>
<?php if (!$DashboardReport) { ?>
<?php include_once "header.php"; ?>
<?php } ?>
<?php if (!$List_Emp_summary->isExport() && !$List_Emp_summary->DrillDown && !$DashboardReport) { ?>
<script>
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<a id="top"></a>
<?php if ((!$List_Emp_summary->isExport() || $List_Emp_summary->isExport("print")) && !$DashboardReport) { ?>
<!-- Content Container -->
<div id="ew-report" class="ew-report container-fluid">
<?php } ?>
<div class="btn-toolbar ew-toolbar">
<?php
if (!$List_Emp_summary->DrillDownInPanel) {
	$List_Emp_summary->ExportOptions->render("body");
	$List_Emp_summary->SearchOptions->render("body");
	$List_Emp_summary->FilterOptions->render("body");
}
?>
</div>
<?php $List_Emp_summary->showPageHeader(); ?>
<?php
$List_Emp_summary->showMessage();
?>
<?php if ((!$List_Emp_summary->isExport() || $List_Emp_summary->isExport("print")) && !$DashboardReport) { ?>
<div class="row">
<?php } ?>
<?php if ((!$List_Emp_summary->isExport() || $List_Emp_summary->isExport("print")) && !$DashboardReport) { ?>
<!-- Center Container -->
<div id="ew-center" class="<?php echo $List_Emp_summary->CenterContentClass ?>">
<?php } ?>
<?php if ($List_Emp_summary->ShowDrillDownFilter) { ?>
<?php $List_Emp_summary->showDrillDownList() ?>
<?php } ?>
<!-- Summary report (begin) -->
<div id="report_summary">
<?php if (!$List_Emp_summary->isExport() && !$List_Emp_summary->DrillDown && !$DashboardReport) { ?>
<?php } ?>
<?php
while ($List_Emp_summary->GroupCount <= count($List_Emp_summary->GroupRecords) && $List_Emp_summary->GroupCount <= $List_Emp_summary->DisplayGroups) {
?>
<?php

	// Show header
	if ($List_Emp_summary->ShowHeader) {
?>
<?php if ($List_Emp_summary->GroupCount > 1) { ?>
</tbody>
</table>
</div>
<!-- /.ew-grid-middle-panel -->
<!-- Report grid (end) -->
<?php if ($List_Emp_summary->TotalGroups > 0) { ?>
<?php if (!$List_Emp_summary->isExport() && !($List_Emp_summary->DrillDown && $List_Emp_summary->TotalGroups > 0)) { ?>
<!-- Bottom pager -->
<div class="card-footer ew-grid-lower-panel">
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $List_Emp_summary->Pager->render() ?>
</form>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php } ?>
</div>
<!-- /.ew-grid -->
<?php echo $List_Emp_summary->PageBreakContent ?>
<?php } ?>
<div class="<?php if (!$List_Emp_summary->isExport("word") && !$List_Emp_summary->isExport("excel")) { ?>card ew-card <?php } ?>ew-grid"<?php echo $List_Emp_summary->ReportTableStyle ?>>
<?php if (!$List_Emp_summary->isExport() && !($List_Emp_summary->DrillDown && $List_Emp_summary->TotalGroups > 0)) { ?>
<!-- Top pager -->
<div class="card-header ew-grid-upper-panel">
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $List_Emp_summary->Pager->render() ?>
</form>
<div class="clearfix"></div>
</div>
<?php } ?>
<!-- Report grid (begin) -->
<div id="gmp_List_Emp" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="<?php echo $List_Emp_summary->ReportTableClass ?>">
<thead>
	<!-- Table header -->
	<tr class="ew-table-header">
<?php if ($List_Emp_summary->Branch->Visible) { ?>
	<?php if ($List_Emp_summary->Branch->ShowGroupHeaderAsRow) { ?>
	<th data-name="Branch">&nbsp;</th>
	<?php } else { ?>
		<?php if ($List_Emp_summary->sortUrl($List_Emp_summary->Branch) == "") { ?>
	<th data-name="Branch" class="<?php echo $List_Emp_summary->Branch->headerCellClass() ?>"><div class="List_Emp_Branch"><div class="ew-table-header-caption"><?php echo $List_Emp_summary->Branch->caption() ?></div></div></th>
		<?php } else { ?>
	<th data-name="Branch" class="<?php echo $List_Emp_summary->Branch->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $List_Emp_summary->sortUrl($List_Emp_summary->Branch) ?>', 1);"><div class="List_Emp_Branch">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $List_Emp_summary->Branch->caption() ?></span><span class="ew-table-header-sort"><?php if ($List_Emp_summary->Branch->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($List_Emp_summary->Branch->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
		<?php } ?>
	<?php } ?>
<?php } ?>
<?php if ($List_Emp_summary->Position->Visible) { ?>
	<?php if ($List_Emp_summary->Position->ShowGroupHeaderAsRow) { ?>
	<th data-name="Position">&nbsp;</th>
	<?php } else { ?>
		<?php if ($List_Emp_summary->sortUrl($List_Emp_summary->Position) == "") { ?>
	<th data-name="Position" class="<?php echo $List_Emp_summary->Position->headerCellClass() ?>"><div class="List_Emp_Position"><div class="ew-table-header-caption"><?php echo $List_Emp_summary->Position->caption() ?></div></div></th>
		<?php } else { ?>
	<th data-name="Position" class="<?php echo $List_Emp_summary->Position->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $List_Emp_summary->sortUrl($List_Emp_summary->Position) ?>', 1);"><div class="List_Emp_Position">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $List_Emp_summary->Position->caption() ?></span><span class="ew-table-header-sort"><?php if ($List_Emp_summary->Position->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($List_Emp_summary->Position->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
		<?php } ?>
	<?php } ?>
<?php } ?>
<?php if ($List_Emp_summary->Name->Visible) { ?>
	<?php if ($List_Emp_summary->Name->ShowGroupHeaderAsRow) { ?>
	<th data-name="Name">&nbsp;</th>
	<?php } else { ?>
		<?php if ($List_Emp_summary->sortUrl($List_Emp_summary->Name) == "") { ?>
	<th data-name="Name" class="<?php echo $List_Emp_summary->Name->headerCellClass() ?>"><div class="List_Emp_Name"><div class="ew-table-header-caption"><?php echo $List_Emp_summary->Name->caption() ?></div></div></th>
		<?php } else { ?>
	<th data-name="Name" class="<?php echo $List_Emp_summary->Name->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $List_Emp_summary->sortUrl($List_Emp_summary->Name) ?>', 1);"><div class="List_Emp_Name">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $List_Emp_summary->Name->caption() ?></span><span class="ew-table-header-sort"><?php if ($List_Emp_summary->Name->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($List_Emp_summary->Name->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
		<?php } ?>
	<?php } ?>
<?php } ?>
<?php if ($List_Emp_summary->Status->Visible) { ?>
	<?php if ($List_Emp_summary->Status->ShowGroupHeaderAsRow) { ?>
	<th data-name="Status">&nbsp;</th>
	<?php } else { ?>
		<?php if ($List_Emp_summary->sortUrl($List_Emp_summary->Status) == "") { ?>
	<th data-name="Status" class="<?php echo $List_Emp_summary->Status->headerCellClass() ?>"><div class="List_Emp_Status"><div class="ew-table-header-caption"><?php echo $List_Emp_summary->Status->caption() ?></div></div></th>
		<?php } else { ?>
	<th data-name="Status" class="<?php echo $List_Emp_summary->Status->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $List_Emp_summary->sortUrl($List_Emp_summary->Status) ?>', 1);"><div class="List_Emp_Status">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $List_Emp_summary->Status->caption() ?></span><span class="ew-table-header-sort"><?php if ($List_Emp_summary->Status->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($List_Emp_summary->Status->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
		<?php } ?>
	<?php } ?>
<?php } ?>
	</tr>
</thead>
<tbody>
<?php
		if ($List_Emp_summary->TotalGroups == 0)
			break; // Show header only
		$List_Emp_summary->ShowHeader = FALSE;
	} // End show header
?>
<?php

	// Build detail SQL
	$where = DetailFilterSql($List_Emp_summary->Branch, $List_Emp_summary->getSqlFirstGroupField(), $List_Emp_summary->Branch->groupValue(), $List_Emp_summary->Dbid);
	if ($List_Emp_summary->PageFirstGroupFilter != "") $List_Emp_summary->PageFirstGroupFilter .= " OR ";
	$List_Emp_summary->PageFirstGroupFilter .= $where;
	if ($List_Emp_summary->Filter != "")
		$where = "($List_Emp_summary->Filter) AND ($where)";
	$sql = BuildReportSql($List_Emp_summary->getSqlSelect(), $List_Emp_summary->getSqlWhere(), $List_Emp_summary->getSqlGroupBy(), $List_Emp_summary->getSqlHaving(), $List_Emp_summary->getSqlOrderBy(), $where, $List_Emp_summary->Sort);
	$rs = $List_Emp_summary->getRecordset($sql);
	$List_Emp_summary->DetailRecords = $rs ? $rs->getRows() : [];
	$List_Emp_summary->DetailRecordCount = count($List_Emp_summary->DetailRecords);

	// Load detail records
	$List_Emp_summary->Branch->Records = &$List_Emp_summary->DetailRecords;
	$List_Emp_summary->Branch->LevelBreak = TRUE; // Set field level break
		$List_Emp_summary->GroupCounter[1] = $List_Emp_summary->GroupCount;
		$List_Emp_summary->Branch->getCnt($List_Emp_summary->Branch->Records); // Get record count
?>
<?php if ($List_Emp_summary->Branch->Visible && $List_Emp_summary->Branch->ShowGroupHeaderAsRow) { ?>
<?php

		// Render header row
		$List_Emp_summary->resetAttributes();
		$List_Emp_summary->RowType = ROWTYPE_TOTAL;
		$List_Emp_summary->RowTotalType = ROWTOTAL_GROUP;
		$List_Emp_summary->RowTotalSubType = ROWTOTAL_HEADER;
		$List_Emp_summary->RowGroupLevel = 1;
		$List_Emp_summary->renderRow();
?>
	<tr<?php echo $List_Emp_summary->rowAttributes(); ?>>
<?php if ($List_Emp_summary->Branch->Visible) { ?>
		<td data-field="Branch"<?php echo $List_Emp_summary->Branch->cellAttributes(); ?>><span class="ew-group-toggle icon-collapse"></span></td>
<?php } ?>
		<td data-field="Branch" colspan="<?php echo ($Page->GroupColumnCount + $Page->DetailColumnCount - 1) ?>"<?php echo $List_Emp_summary->Branch->cellAttributes() ?>>
<?php if ($List_Emp_summary->sortUrl($List_Emp_summary->Branch) == "") { ?>
		<span class="ew-summary-caption List_Emp_Branch"><span class="ew-table-header-caption"><?php echo $List_Emp_summary->Branch->caption() ?></span></span>
<?php } else { ?>
		<span class="ew-table-header-btn ew-pointer ew-summary-caption List_Emp_Branch" onclick="ew.sort(event, '<?php echo $List_Emp_summary->sortUrl($List_Emp_summary->Branch) ?>', 1);">
			<span class="ew-table-header-caption"><?php echo $List_Emp_summary->Branch->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($List_Emp_summary->Branch->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($List_Emp_summary->Branch->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span>
		</span>
<?php } ?>
		<?php echo $Language->phrase("SummaryColon") ?><span<?php echo $List_Emp_summary->Branch->viewAttributes() ?>><?php echo $List_Emp_summary->Branch->GroupViewValue ?></span>
		<span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($List_Emp_summary->Branch->Count, 0); ?></span>)</span>
		</td>
	</tr>
<?php } ?>
<?php
	$List_Emp_summary->Position->getDistinctValues($List_Emp_summary->Branch->Records);
	$List_Emp_summary->setGroupCount(count($List_Emp_summary->Position->DistinctValues), $List_Emp_summary->GroupCounter[1]);
	$List_Emp_summary->GroupCounter[2] = 0; // Init group count index
	foreach ($List_Emp_summary->Position->DistinctValues as $Position) { // Load records for this distinct value
		$List_Emp_summary->Position->setGroupValue($Position); // Set group value
		$List_Emp_summary->Position->getDistinctRecords($List_Emp_summary->Branch->Records, $List_Emp_summary->Position->groupValue());
		$List_Emp_summary->Position->LevelBreak = TRUE; // Set field level break
		$List_Emp_summary->GroupCounter[2]++;
		$List_Emp_summary->Position->getCnt($List_Emp_summary->Position->Records); // Get record count
?>
<?php if ($List_Emp_summary->Position->Visible && $List_Emp_summary->Position->ShowGroupHeaderAsRow) { ?>
<?php

		// Render header row
		$List_Emp_summary->Position->setDbValue($Position); // Set current value for Position
		$List_Emp_summary->resetAttributes();
		$List_Emp_summary->RowType = ROWTYPE_TOTAL;
		$List_Emp_summary->RowTotalType = ROWTOTAL_GROUP;
		$List_Emp_summary->RowTotalSubType = ROWTOTAL_HEADER;
		$List_Emp_summary->RowGroupLevel = 2;
		$List_Emp_summary->renderRow();
?>
	<tr<?php echo $List_Emp_summary->rowAttributes(); ?>>
<?php if ($List_Emp_summary->Branch->Visible) { ?>
		<td data-field="Branch"<?php echo $List_Emp_summary->Branch->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($List_Emp_summary->Position->Visible) { ?>
		<td data-field="Position"<?php echo $List_Emp_summary->Position->cellAttributes(); ?>><span class="ew-group-toggle icon-collapse"></span></td>
<?php } ?>
		<td data-field="Position" colspan="<?php echo ($Page->GroupColumnCount + $Page->DetailColumnCount - 2) ?>"<?php echo $List_Emp_summary->Position->cellAttributes() ?>>
<?php if ($List_Emp_summary->sortUrl($List_Emp_summary->Position) == "") { ?>
		<span class="ew-summary-caption List_Emp_Position"><span class="ew-table-header-caption"><?php echo $List_Emp_summary->Position->caption() ?></span></span>
<?php } else { ?>
		<span class="ew-table-header-btn ew-pointer ew-summary-caption List_Emp_Position" onclick="ew.sort(event, '<?php echo $List_Emp_summary->sortUrl($List_Emp_summary->Position) ?>', 1);">
			<span class="ew-table-header-caption"><?php echo $List_Emp_summary->Position->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($List_Emp_summary->Position->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($List_Emp_summary->Position->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span>
		</span>
<?php } ?>
		<?php echo $Language->phrase("SummaryColon") ?><span<?php echo $List_Emp_summary->Position->viewAttributes() ?>><?php echo $List_Emp_summary->Position->GroupViewValue ?></span>
		<span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($List_Emp_summary->Position->Count, 0); ?></span>)</span>
		</td>
	</tr>
<?php } ?>
<?php
	$List_Emp_summary->Name->getDistinctValues($List_Emp_summary->Position->Records);
	$List_Emp_summary->setGroupCount(count($List_Emp_summary->Name->DistinctValues), $List_Emp_summary->GroupCounter[1], $List_Emp_summary->GroupCounter[2]);
	$List_Emp_summary->GroupCounter[3] = 0; // Init group count index
	foreach ($List_Emp_summary->Name->DistinctValues as $Name) { // Load records for this distinct value
		$List_Emp_summary->Name->setGroupValue($Name); // Set group value
		$List_Emp_summary->Name->getDistinctRecords($List_Emp_summary->Position->Records, $List_Emp_summary->Name->groupValue());
		$List_Emp_summary->Name->LevelBreak = TRUE; // Set field level break
		$List_Emp_summary->GroupCounter[3]++;
		$List_Emp_summary->Name->getCnt($List_Emp_summary->Name->Records); // Get record count
?>
<?php if ($List_Emp_summary->Name->Visible && $List_Emp_summary->Name->ShowGroupHeaderAsRow) { ?>
<?php

		// Render header row
		$List_Emp_summary->Name->setDbValue($Name); // Set current value for Name
		$List_Emp_summary->resetAttributes();
		$List_Emp_summary->RowType = ROWTYPE_TOTAL;
		$List_Emp_summary->RowTotalType = ROWTOTAL_GROUP;
		$List_Emp_summary->RowTotalSubType = ROWTOTAL_HEADER;
		$List_Emp_summary->RowGroupLevel = 3;
		$List_Emp_summary->renderRow();
?>
	<tr<?php echo $List_Emp_summary->rowAttributes(); ?>>
<?php if ($List_Emp_summary->Branch->Visible) { ?>
		<td data-field="Branch"<?php echo $List_Emp_summary->Branch->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($List_Emp_summary->Position->Visible) { ?>
		<td data-field="Position"<?php echo $List_Emp_summary->Position->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($List_Emp_summary->Name->Visible) { ?>
		<td data-field="Name"<?php echo $List_Emp_summary->Name->cellAttributes(); ?>><span class="ew-group-toggle icon-collapse"></span></td>
<?php } ?>
		<td data-field="Name" colspan="<?php echo ($Page->GroupColumnCount + $Page->DetailColumnCount - 3) ?>"<?php echo $List_Emp_summary->Name->cellAttributes() ?>>
<?php if ($List_Emp_summary->sortUrl($List_Emp_summary->Name) == "") { ?>
		<span class="ew-summary-caption List_Emp_Name"><span class="ew-table-header-caption"><?php echo $List_Emp_summary->Name->caption() ?></span></span>
<?php } else { ?>
		<span class="ew-table-header-btn ew-pointer ew-summary-caption List_Emp_Name" onclick="ew.sort(event, '<?php echo $List_Emp_summary->sortUrl($List_Emp_summary->Name) ?>', 1);">
			<span class="ew-table-header-caption"><?php echo $List_Emp_summary->Name->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($List_Emp_summary->Name->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($List_Emp_summary->Name->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span>
		</span>
<?php } ?>
		<?php echo $Language->phrase("SummaryColon") ?><span<?php echo $List_Emp_summary->Name->viewAttributes() ?>><?php echo $List_Emp_summary->Name->GroupViewValue ?></span>
		<span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($List_Emp_summary->Name->Count, 0); ?></span>)</span>
		</td>
	</tr>
<?php } ?>
<?php
	$List_Emp_summary->Status->getDistinctValues($List_Emp_summary->Name->Records);
	$List_Emp_summary->setGroupCount(count($List_Emp_summary->Status->DistinctValues), $List_Emp_summary->GroupCounter[1], $List_Emp_summary->GroupCounter[2], $List_Emp_summary->GroupCounter[3]);
	$List_Emp_summary->GroupCounter[4] = 0; // Init group count index
	foreach ($List_Emp_summary->Status->DistinctValues as $Status) { // Load records for this distinct value
		$List_Emp_summary->Status->setGroupValue($Status); // Set group value
		$List_Emp_summary->Status->getDistinctRecords($List_Emp_summary->Name->Records, $List_Emp_summary->Status->groupValue());
		$List_Emp_summary->Status->LevelBreak = TRUE; // Set field level break
		$List_Emp_summary->GroupCounter[4]++;
		$List_Emp_summary->Status->getCnt($List_Emp_summary->Status->Records); // Get record count
		$List_Emp_summary->setGroupCount($List_Emp_summary->Status->Count, $List_Emp_summary->GroupCounter[1], $List_Emp_summary->GroupCounter[2], $List_Emp_summary->GroupCounter[3], $List_Emp_summary->GroupCounter[4]);
?>
<?php if ($List_Emp_summary->Status->Visible && $List_Emp_summary->Status->ShowGroupHeaderAsRow) { ?>
<?php

		// Render header row
		$List_Emp_summary->Status->setDbValue($Status); // Set current value for Status
		$List_Emp_summary->resetAttributes();
		$List_Emp_summary->RowType = ROWTYPE_TOTAL;
		$List_Emp_summary->RowTotalType = ROWTOTAL_GROUP;
		$List_Emp_summary->RowTotalSubType = ROWTOTAL_HEADER;
		$List_Emp_summary->RowGroupLevel = 4;
		$List_Emp_summary->renderRow();
?>
	<tr<?php echo $List_Emp_summary->rowAttributes(); ?>>
<?php if ($List_Emp_summary->Branch->Visible) { ?>
		<td data-field="Branch"<?php echo $List_Emp_summary->Branch->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($List_Emp_summary->Position->Visible) { ?>
		<td data-field="Position"<?php echo $List_Emp_summary->Position->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($List_Emp_summary->Name->Visible) { ?>
		<td data-field="Name"<?php echo $List_Emp_summary->Name->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($List_Emp_summary->Status->Visible) { ?>
		<td data-field="Status"<?php echo $List_Emp_summary->Status->cellAttributes(); ?>><span class="ew-group-toggle icon-collapse"></span></td>
<?php } ?>
		<td data-field="Status" colspan="<?php echo ($Page->GroupColumnCount + $Page->DetailColumnCount - 4) ?>"<?php echo $List_Emp_summary->Status->cellAttributes() ?>>
<?php if ($List_Emp_summary->sortUrl($List_Emp_summary->Status) == "") { ?>
		<span class="ew-summary-caption List_Emp_Status"><span class="ew-table-header-caption"><?php echo $List_Emp_summary->Status->caption() ?></span></span>
<?php } else { ?>
		<span class="ew-table-header-btn ew-pointer ew-summary-caption List_Emp_Status" onclick="ew.sort(event, '<?php echo $List_Emp_summary->sortUrl($List_Emp_summary->Status) ?>', 1);">
			<span class="ew-table-header-caption"><?php echo $List_Emp_summary->Status->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($List_Emp_summary->Status->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($List_Emp_summary->Status->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span>
		</span>
<?php } ?>
		<?php echo $Language->phrase("SummaryColon") ?><span<?php echo $List_Emp_summary->Status->viewAttributes() ?>><?php echo $List_Emp_summary->Status->GroupViewValue ?></span>
		<span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($List_Emp_summary->Status->Count, 0); ?></span>)</span>
		</td>
	</tr>
<?php } ?>
<?php
	$List_Emp_summary->RecordCount = 0; // Reset record count
	foreach ($List_Emp_summary->Status->Records as $record) {
		$List_Emp_summary->RecordCount++;
		$List_Emp_summary->RecordIndex++;
		$List_Emp_summary->loadRowValues($record);
?>
<?php

		// Render detail row
		$List_Emp_summary->resetAttributes();
		$List_Emp_summary->RowType = ROWTYPE_DETAIL;
		$List_Emp_summary->renderRow();
?>
	<tr<?php echo $List_Emp_summary->rowAttributes(); ?>>
<?php if ($List_Emp_summary->Branch->Visible) { ?>
	<?php if ($List_Emp_summary->Branch->ShowGroupHeaderAsRow) { ?>
		<td data-field="Branch"<?php echo $List_Emp_summary->Branch->cellAttributes(); ?>>&nbsp;</td>
	<?php } else { ?>
		<td data-field="Branch"<?php echo $List_Emp_summary->Branch->cellAttributes(); ?>><span<?php echo $List_Emp_summary->Branch->viewAttributes() ?>><?php echo $List_Emp_summary->Branch->GroupViewValue ?></span></td>
	<?php } ?>
<?php } ?>
<?php if ($List_Emp_summary->Position->Visible) { ?>
	<?php if ($List_Emp_summary->Position->ShowGroupHeaderAsRow) { ?>
		<td data-field="Position"<?php echo $List_Emp_summary->Position->cellAttributes(); ?>>&nbsp;</td>
	<?php } else { ?>
		<td data-field="Position"<?php echo $List_Emp_summary->Position->cellAttributes(); ?>><span<?php echo $List_Emp_summary->Position->viewAttributes() ?>><?php echo $List_Emp_summary->Position->GroupViewValue ?></span></td>
	<?php } ?>
<?php } ?>
<?php if ($List_Emp_summary->Name->Visible) { ?>
	<?php if ($List_Emp_summary->Name->ShowGroupHeaderAsRow) { ?>
		<td data-field="Name"<?php echo $List_Emp_summary->Name->cellAttributes(); ?>>&nbsp;</td>
	<?php } else { ?>
		<td data-field="Name"<?php echo $List_Emp_summary->Name->cellAttributes(); ?>><span<?php echo $List_Emp_summary->Name->viewAttributes() ?>><?php echo $List_Emp_summary->Name->GroupViewValue ?></span></td>
	<?php } ?>
<?php } ?>
<?php if ($List_Emp_summary->Status->Visible) { ?>
	<?php if ($List_Emp_summary->Status->ShowGroupHeaderAsRow) { ?>
		<td data-field="Status"<?php echo $List_Emp_summary->Status->cellAttributes(); ?>>&nbsp;</td>
	<?php } else { ?>
		<td data-field="Status"<?php echo $List_Emp_summary->Status->cellAttributes(); ?>><span<?php echo $List_Emp_summary->Status->viewAttributes() ?>><?php echo $List_Emp_summary->Status->GroupViewValue ?></span></td>
	<?php } ?>
<?php } ?>
	</tr>
<?php
	}
	} // End group level 3
	} // End group level 2
	} // End group level 1
?>
<?php

	// Next group
	$List_Emp_summary->loadGroupRowValues();

	// Show header if page break
	if ($List_Emp_summary->isExport())
		$List_Emp_summary->ShowHeader = ($List_Emp_summary->ExportPageBreakCount == 0) ? FALSE : ($List_Emp_summary->GroupCount % $List_Emp_summary->ExportPageBreakCount == 0);

	// Page_Breaking server event
	if ($List_Emp_summary->ShowHeader)
		$List_Emp_summary->Page_Breaking($List_Emp_summary->ShowHeader, $List_Emp_summary->PageBreakContent);
	$List_Emp_summary->GroupCount++;
} // End while
?>
<?php if ($List_Emp_summary->TotalGroups > 0) { ?>
</tbody>
<tfoot>
<?php
	$List_Emp_summary->resetAttributes();
	$List_Emp_summary->RowType = ROWTYPE_TOTAL;
	$List_Emp_summary->RowTotalType = ROWTOTAL_GRAND;
	$List_Emp_summary->RowTotalSubType = ROWTOTAL_FOOTER;
	$List_Emp_summary->RowAttrs["class"] = "ew-rpt-grand-summary";
	$List_Emp_summary->renderRow();
?>
<?php if ($List_Emp_summary->Branch->ShowCompactSummaryFooter) { ?>
	<tr<?php echo $List_Emp_summary->rowAttributes() ?>><td colspan="<?php echo ($List_Emp_summary->GroupColumnCount + $List_Emp_summary->DetailColumnCount) ?>"><?php echo $Language->phrase("RptGrandSummary") ?> <span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($List_Emp_summary->TotalCount, 0); ?></span>)</span></td></tr>
<?php } else { ?>
	<tr<?php echo $List_Emp_summary->rowAttributes() ?>><td colspan="<?php echo ($List_Emp_summary->GroupColumnCount + $List_Emp_summary->DetailColumnCount) ?>"><?php echo $Language->phrase("RptGrandSummary") ?> <span class="ew-summary-count">(<?php echo FormatNumber($List_Emp_summary->TotalCount, 0); ?><?php echo $Language->phrase("RptDtlRec") ?>)</span></td></tr>
<?php } ?>
</tfoot>
</table>
</div>
<!-- /.ew-grid-middle-panel -->
<!-- Report grid (end) -->
<?php if ($List_Emp_summary->TotalGroups > 0) { ?>
<?php if (!$List_Emp_summary->isExport() && !($List_Emp_summary->DrillDown && $List_Emp_summary->TotalGroups > 0)) { ?>
<!-- Bottom pager -->
<div class="card-footer ew-grid-lower-panel">
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $List_Emp_summary->Pager->render() ?>
</form>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php } ?>
</div>
<!-- /.ew-grid -->
<?php } ?>
</div>
<!-- /#report-summary -->
<!-- Summary report (end) -->
<?php if ((!$List_Emp_summary->isExport() || $List_Emp_summary->isExport("print")) && !$DashboardReport) { ?>
</div>
<!-- /#ew-center -->
<?php } ?>
<?php if ((!$List_Emp_summary->isExport() || $List_Emp_summary->isExport("print")) && !$DashboardReport) { ?>
</div>
<!-- /.row -->
<?php } ?>
<?php if ((!$List_Emp_summary->isExport() || $List_Emp_summary->isExport("print")) && !$DashboardReport) { ?>
</div>
<!-- /.ew-report -->
<?php } ?>
<?php
$List_Emp_summary->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$List_Emp_summary->isExport() && !$List_Emp_summary->DrillDown && !$DashboardReport) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php if (!$DashboardReport) { ?>
<?php include_once "footer.php"; ?>
<?php } ?>
<?php
$List_Emp_summary->terminate();
?>