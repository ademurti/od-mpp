<?php
namespace PHPMaker2020\mpp;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$education_list = new education_list();

// Run the page
$education_list->run();

// Setup login status
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$education_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$education_list->isExport()) { ?>
<script>
var feducationlist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	feducationlist = currentForm = new ew.Form("feducationlist", "list");
	feducationlist.formKeyCountName = '<?php echo $education_list->FormKeyCountName ?>';
	loadjs.done("feducationlist");
});
var feducationlistsrch;
loadjs.ready("head", function() {

	// Form object for search
	feducationlistsrch = currentSearchForm = new ew.Form("feducationlistsrch");

	// Dynamic selection lists
	// Filters

	feducationlistsrch.filterList = <?php echo $education_list->getFilterList() ?>;
	loadjs.done("feducationlistsrch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$education_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($education_list->TotalRecords > 0 && $education_list->ExportOptions->visible()) { ?>
<?php $education_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($education_list->ImportOptions->visible()) { ?>
<?php $education_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($education_list->SearchOptions->visible()) { ?>
<?php $education_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($education_list->FilterOptions->visible()) { ?>
<?php $education_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$education_list->renderOtherOptions();
?>
<?php if (!$education_list->isExport() && !$education->CurrentAction) { ?>
<form name="feducationlistsrch" id="feducationlistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="feducationlistsrch-search-panel" class="<?php echo $education_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="education">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $education_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($education_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($education_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $education_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($education_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($education_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($education_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($education_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php $education_list->showPageHeader(); ?>
<?php
$education_list->showMessage();
?>
<?php if ($education_list->TotalRecords > 0 || $education->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($education_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> education">
<?php if (!$education_list->isExport()) { ?>
<div class="card-header ew-grid-upper-panel">
<?php if (!$education_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $education_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $education_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
<form name="feducationlist" id="feducationlist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="education">
<div id="gmp_education" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($education_list->TotalRecords > 0 || $education_list->isGridEdit()) { ?>
<table id="tbl_educationlist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$education->RowType = ROWTYPE_HEADER;

// Render list options
$education_list->renderListOptions();

// Render list options (header, left)
$education_list->ListOptions->render("header", "left");
?>
<?php if ($education_list->Education->Visible) { // Education ?>
	<?php if ($education_list->SortUrl($education_list->Education) == "") { ?>
		<th data-name="Education" class="<?php echo $education_list->Education->headerCellClass() ?>"><div id="elh_education_Education" class="education_Education"><div class="ew-table-header-caption"><?php echo $education_list->Education->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Education" class="<?php echo $education_list->Education->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $education_list->SortUrl($education_list->Education) ?>', 1);"><div id="elh_education_Education" class="education_Education">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $education_list->Education->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($education_list->Education->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($education_list->Education->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$education_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($education_list->ExportAll && $education_list->isExport()) {
	$education_list->StopRecord = $education_list->TotalRecords;
} else {

	// Set the last record to display
	if ($education_list->TotalRecords > $education_list->StartRecord + $education_list->DisplayRecords - 1)
		$education_list->StopRecord = $education_list->StartRecord + $education_list->DisplayRecords - 1;
	else
		$education_list->StopRecord = $education_list->TotalRecords;
}
$education_list->RecordCount = $education_list->StartRecord - 1;
if ($education_list->Recordset && !$education_list->Recordset->EOF) {
	$education_list->Recordset->moveFirst();
	$selectLimit = $education_list->UseSelectLimit;
	if (!$selectLimit && $education_list->StartRecord > 1)
		$education_list->Recordset->move($education_list->StartRecord - 1);
} elseif (!$education->AllowAddDeleteRow && $education_list->StopRecord == 0) {
	$education_list->StopRecord = $education->GridAddRowCount;
}

// Initialize aggregate
$education->RowType = ROWTYPE_AGGREGATEINIT;
$education->resetAttributes();
$education_list->renderRow();
while ($education_list->RecordCount < $education_list->StopRecord) {
	$education_list->RecordCount++;
	if ($education_list->RecordCount >= $education_list->StartRecord) {
		$education_list->RowCount++;

		// Set up key count
		$education_list->KeyCount = $education_list->RowIndex;

		// Init row class and style
		$education->resetAttributes();
		$education->CssClass = "";
		if ($education_list->isGridAdd()) {
		} else {
			$education_list->loadRowValues($education_list->Recordset); // Load row values
		}
		$education->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$education->RowAttrs->merge(["data-rowindex" => $education_list->RowCount, "id" => "r" . $education_list->RowCount . "_education", "data-rowtype" => $education->RowType]);

		// Render row
		$education_list->renderRow();

		// Render list options
		$education_list->renderListOptions();
?>
	<tr <?php echo $education->rowAttributes() ?>>
<?php

// Render list options (body, left)
$education_list->ListOptions->render("body", "left", $education_list->RowCount);
?>
	<?php if ($education_list->Education->Visible) { // Education ?>
		<td data-name="Education" <?php echo $education_list->Education->cellAttributes() ?>>
<span id="el<?php echo $education_list->RowCount ?>_education_Education">
<span<?php echo $education_list->Education->viewAttributes() ?>><?php echo $education_list->Education->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$education_list->ListOptions->render("body", "right", $education_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$education_list->isGridAdd())
		$education_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$education->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($education_list->Recordset)
	$education_list->Recordset->Close();
?>
<?php if (!$education_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$education_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $education_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $education_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($education_list->TotalRecords == 0 && !$education->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $education_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$education_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$education_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$education_list->terminate();
?>