<?php
namespace PHPMaker2020\mpp;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$level_list = new level_list();

// Run the page
$level_list->run();

// Setup login status
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$level_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$level_list->isExport()) { ?>
<script>
var flevellist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	flevellist = currentForm = new ew.Form("flevellist", "list");
	flevellist.formKeyCountName = '<?php echo $level_list->FormKeyCountName ?>';
	loadjs.done("flevellist");
});
var flevellistsrch;
loadjs.ready("head", function() {

	// Form object for search
	flevellistsrch = currentSearchForm = new ew.Form("flevellistsrch");

	// Dynamic selection lists
	// Filters

	flevellistsrch.filterList = <?php echo $level_list->getFilterList() ?>;
	loadjs.done("flevellistsrch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$level_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($level_list->TotalRecords > 0 && $level_list->ExportOptions->visible()) { ?>
<?php $level_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($level_list->ImportOptions->visible()) { ?>
<?php $level_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($level_list->SearchOptions->visible()) { ?>
<?php $level_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($level_list->FilterOptions->visible()) { ?>
<?php $level_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$level_list->renderOtherOptions();
?>
<?php if (!$level_list->isExport() && !$level->CurrentAction) { ?>
<form name="flevellistsrch" id="flevellistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="flevellistsrch-search-panel" class="<?php echo $level_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="level">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $level_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($level_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($level_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $level_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($level_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($level_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($level_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($level_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php $level_list->showPageHeader(); ?>
<?php
$level_list->showMessage();
?>
<?php if ($level_list->TotalRecords > 0 || $level->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($level_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> level">
<?php if (!$level_list->isExport()) { ?>
<div class="card-header ew-grid-upper-panel">
<?php if (!$level_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $level_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $level_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
<form name="flevellist" id="flevellist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="level">
<div id="gmp_level" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($level_list->TotalRecords > 0 || $level_list->isGridEdit()) { ?>
<table id="tbl_levellist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$level->RowType = ROWTYPE_HEADER;

// Render list options
$level_list->renderListOptions();

// Render list options (header, left)
$level_list->ListOptions->render("header", "left");
?>
<?php if ($level_list->Level->Visible) { // Level ?>
	<?php if ($level_list->SortUrl($level_list->Level) == "") { ?>
		<th data-name="Level" class="<?php echo $level_list->Level->headerCellClass() ?>"><div id="elh_level_Level" class="level_Level"><div class="ew-table-header-caption"><?php echo $level_list->Level->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Level" class="<?php echo $level_list->Level->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $level_list->SortUrl($level_list->Level) ?>', 1);"><div id="elh_level_Level" class="level_Level">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $level_list->Level->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($level_list->Level->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($level_list->Level->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$level_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($level_list->ExportAll && $level_list->isExport()) {
	$level_list->StopRecord = $level_list->TotalRecords;
} else {

	// Set the last record to display
	if ($level_list->TotalRecords > $level_list->StartRecord + $level_list->DisplayRecords - 1)
		$level_list->StopRecord = $level_list->StartRecord + $level_list->DisplayRecords - 1;
	else
		$level_list->StopRecord = $level_list->TotalRecords;
}
$level_list->RecordCount = $level_list->StartRecord - 1;
if ($level_list->Recordset && !$level_list->Recordset->EOF) {
	$level_list->Recordset->moveFirst();
	$selectLimit = $level_list->UseSelectLimit;
	if (!$selectLimit && $level_list->StartRecord > 1)
		$level_list->Recordset->move($level_list->StartRecord - 1);
} elseif (!$level->AllowAddDeleteRow && $level_list->StopRecord == 0) {
	$level_list->StopRecord = $level->GridAddRowCount;
}

// Initialize aggregate
$level->RowType = ROWTYPE_AGGREGATEINIT;
$level->resetAttributes();
$level_list->renderRow();
while ($level_list->RecordCount < $level_list->StopRecord) {
	$level_list->RecordCount++;
	if ($level_list->RecordCount >= $level_list->StartRecord) {
		$level_list->RowCount++;

		// Set up key count
		$level_list->KeyCount = $level_list->RowIndex;

		// Init row class and style
		$level->resetAttributes();
		$level->CssClass = "";
		if ($level_list->isGridAdd()) {
		} else {
			$level_list->loadRowValues($level_list->Recordset); // Load row values
		}
		$level->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$level->RowAttrs->merge(["data-rowindex" => $level_list->RowCount, "id" => "r" . $level_list->RowCount . "_level", "data-rowtype" => $level->RowType]);

		// Render row
		$level_list->renderRow();

		// Render list options
		$level_list->renderListOptions();
?>
	<tr <?php echo $level->rowAttributes() ?>>
<?php

// Render list options (body, left)
$level_list->ListOptions->render("body", "left", $level_list->RowCount);
?>
	<?php if ($level_list->Level->Visible) { // Level ?>
		<td data-name="Level" <?php echo $level_list->Level->cellAttributes() ?>>
<span id="el<?php echo $level_list->RowCount ?>_level_Level">
<span<?php echo $level_list->Level->viewAttributes() ?>><?php echo $level_list->Level->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$level_list->ListOptions->render("body", "right", $level_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$level_list->isGridAdd())
		$level_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$level->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($level_list->Recordset)
	$level_list->Recordset->Close();
?>
<?php if (!$level_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$level_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $level_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $level_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($level_list->TotalRecords == 0 && !$level->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $level_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$level_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$level_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$level_list->terminate();
?>