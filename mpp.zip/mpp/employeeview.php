<?php
namespace PHPMaker2020\mpp;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$employee_view = new employee_view();

// Run the page
$employee_view->run();

// Setup login status
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$employee_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$employee_view->isExport()) { ?>
<script>
var femployeeview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	femployeeview = currentForm = new ew.Form("femployeeview", "view");
	loadjs.done("femployeeview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$employee_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $employee_view->ExportOptions->render("body") ?>
<?php $employee_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $employee_view->showPageHeader(); ?>
<?php
$employee_view->showMessage();
?>
<?php if (!$employee_view->IsModal) { ?>
<?php if (!$employee_view->isExport()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $employee_view->Pager->render() ?>
<div class="clearfix"></div>
</form>
<?php } ?>
<?php } ?>
<form name="femployeeview" id="femployeeview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="employee">
<input type="hidden" name="modal" value="<?php echo (int)$employee_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($employee_view->Location->Visible) { // Location ?>
	<tr id="r_Location">
		<td class="<?php echo $employee_view->TableLeftColumnClass ?>"><span id="elh_employee_Location"><?php echo $employee_view->Location->caption() ?></span></td>
		<td data-name="Location" <?php echo $employee_view->Location->cellAttributes() ?>>
<span id="el_employee_Location">
<span<?php echo $employee_view->Location->viewAttributes() ?>><?php echo $employee_view->Location->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($employee_view->Branch->Visible) { // Branch ?>
	<tr id="r_Branch">
		<td class="<?php echo $employee_view->TableLeftColumnClass ?>"><span id="elh_employee_Branch"><?php echo $employee_view->Branch->caption() ?></span></td>
		<td data-name="Branch" <?php echo $employee_view->Branch->cellAttributes() ?>>
<span id="el_employee_Branch">
<span<?php echo $employee_view->Branch->viewAttributes() ?>><?php echo $employee_view->Branch->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($employee_view->Position->Visible) { // Position ?>
	<tr id="r_Position">
		<td class="<?php echo $employee_view->TableLeftColumnClass ?>"><span id="elh_employee_Position"><?php echo $employee_view->Position->caption() ?></span></td>
		<td data-name="Position" <?php echo $employee_view->Position->cellAttributes() ?>>
<span id="el_employee_Position">
<span<?php echo $employee_view->Position->viewAttributes() ?>><?php echo $employee_view->Position->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($employee_view->Status->Visible) { // Status ?>
	<tr id="r_Status">
		<td class="<?php echo $employee_view->TableLeftColumnClass ?>"><span id="elh_employee_Status"><?php echo $employee_view->Status->caption() ?></span></td>
		<td data-name="Status" <?php echo $employee_view->Status->cellAttributes() ?>>
<span id="el_employee_Status">
<span<?php echo $employee_view->Status->viewAttributes() ?>><?php echo $employee_view->Status->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($employee_view->Name->Visible) { // Name ?>
	<tr id="r_Name">
		<td class="<?php echo $employee_view->TableLeftColumnClass ?>"><span id="elh_employee_Name"><?php echo $employee_view->Name->caption() ?></span></td>
		<td data-name="Name" <?php echo $employee_view->Name->cellAttributes() ?>>
<span id="el_employee_Name">
<span<?php echo $employee_view->Name->viewAttributes() ?>><?php echo $employee_view->Name->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($employee_view->Education->Visible) { // Education ?>
	<tr id="r_Education">
		<td class="<?php echo $employee_view->TableLeftColumnClass ?>"><span id="elh_employee_Education"><?php echo $employee_view->Education->caption() ?></span></td>
		<td data-name="Education" <?php echo $employee_view->Education->cellAttributes() ?>>
<span id="el_employee_Education">
<span<?php echo $employee_view->Education->viewAttributes() ?>><?php echo $employee_view->Education->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($employee_view->Join->Visible) { // Join ?>
	<tr id="r_Join">
		<td class="<?php echo $employee_view->TableLeftColumnClass ?>"><span id="elh_employee_Join"><?php echo $employee_view->Join->caption() ?></span></td>
		<td data-name="Join" <?php echo $employee_view->Join->cellAttributes() ?>>
<span id="el_employee_Join">
<span<?php echo $employee_view->Join->viewAttributes() ?>><?php echo $employee_view->Join->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($employee_view->Resign->Visible) { // Resign ?>
	<tr id="r_Resign">
		<td class="<?php echo $employee_view->TableLeftColumnClass ?>"><span id="elh_employee_Resign"><?php echo $employee_view->Resign->caption() ?></span></td>
		<td data-name="Resign" <?php echo $employee_view->Resign->cellAttributes() ?>>
<span id="el_employee_Resign">
<span<?php echo $employee_view->Resign->viewAttributes() ?>><?php echo $employee_view->Resign->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($employee_view->Product->Visible) { // Product ?>
	<tr id="r_Product">
		<td class="<?php echo $employee_view->TableLeftColumnClass ?>"><span id="elh_employee_Product"><?php echo $employee_view->Product->caption() ?></span></td>
		<td data-name="Product" <?php echo $employee_view->Product->cellAttributes() ?>>
<span id="el_employee_Product">
<span<?php echo $employee_view->Product->viewAttributes() ?>><?php echo $employee_view->Product->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
<?php if (!$employee_view->IsModal) { ?>
<?php if (!$employee_view->isExport()) { ?>
<?php echo $employee_view->Pager->render() ?>
<div class="clearfix"></div>
<?php } ?>
<?php } ?>
</form>
<?php
$employee_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$employee_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$employee_view->terminate();
?>